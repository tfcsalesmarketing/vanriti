<?php

namespace App\Http\Controllers;

use App\Models\Address;
use App\Models\Order;
use App\Models\ReturnItem;
use App\Models\ReturnRequest;
use App\Models\Review;
use App\Services\OrderService;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;

class AccountController extends Controller
{
    public function __construct(protected OrderService $orderService) {}

    public function dashboard(): View
    {
        $user = auth('web')->user();
        $stats = [
            'orders' => $user->orders()->count(),
            'spent' => (float) $user->orders()->whereNotIn('order_status', ['cancelled', 'failed'])->sum('grand_total'),
            'delivered' => $user->orders()->where('order_status', 'delivered')->count(),
            'pending_returns' => $user->returnRequests()->whereIn('status', ['requested', 'under_review', 'approved', 'pickup_scheduled'])->count(),
        ];
        $recentOrders = $user->orders()->with('items')->latest()->limit(5)->get();

        return view('storefront.account.dashboard', compact('stats', 'recentOrders'));
    }

    public function orders(): View
    {
        $orders = auth('web')->user()
            ->orders()
            ->with(['items', 'payments'])
            ->latest()
            ->paginate(10);

        return view('storefront.account.orders', compact('orders'));
    }

    public function orderShow(Order $order): View
    {
        abort_unless($order->user_id === auth('web')->id(), 403);

        $order->load(['items.review', 'payments', 'statusHistories', 'shipments.trackingEvents', 'returnRequests.items']);

        return view('storefront.account.order-detail', compact('order'));
    }

    public function cancelOrder(Request $request, Order $order): RedirectResponse
    {
        abort_unless($order->user_id === auth('web')->id(), 403);

        try {
            $this->orderService->cancelOrder($order, $request->input('reason'));
        } catch (\RuntimeException|\InvalidArgumentException $e) {
            return back()->with('error', $e->getMessage());
        }

        return back()->with('success', 'Your order has been cancelled and the amount will be refunded if already paid.');
    }

    public function createReturn(Request $request, Order $order): RedirectResponse
    {
        abort_unless($order->user_id === auth('web')->id(), 403);

        $request->validate([
            'reason' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:1000'],
            'items' => ['required', 'array', 'min:1'],
            'items.*' => ['required', 'integer', 'exists:order_items,id'],
        ]);

        if (! $order->isReturnable()) {
            return back()->with('error', 'This order is not eligible for a return.');
        }

        $user = auth('web')->user();

        $orderItems = $order->items()->whereIn('id', $request->items)->get();
        if ($orderItems->isEmpty()) {
            return back()->with('error', 'Please select at least one item to return.');
        }

        // Reject an item that is already part of a non-rejected return request
        // so the same order item cannot be returned (and refunded) twice.
        $activeReturnIds = $order->returnRequests()->where('status', '!=', 'rejected')->pluck('id');

        $alreadyReturning = ReturnItem::whereIn('return_request_id', $activeReturnIds)
            ->whereIn('order_item_id', $orderItems->pluck('id'))
            ->exists();

        if ($alreadyReturning) {
            return back()->with('error', 'Some of the selected items already have an active return request.');
        }

        try {
            $returnRequest = DB::transaction(function () use ($user, $order, $orderItems, $request) {
                $return = ReturnRequest::create([
                    'return_number' => 'RTR-'.now()->format('Y').'-'.strtoupper(Str::random(6)),
                    'order_id' => $order->id,
                    'user_id' => $user->id,
                    'reason' => $request->input('reason'),
                    'description' => $request->input('description'),
                    'status' => 'requested',
                    'requested_at' => now(),
                ]);

                // Coupon discounts are shared across all items, so each item's
                // refundable value is its pre-coupon line total scaled by the
                // order's payable-to-subtotal ratio. Prevents over-refunding
                // discounted orders. The refund itself is only created when an
                // admin approves the return (see Admin\ReturnController).
                $factor = (float) $order->subtotal > 0
                    ? max(0.0, min(1.0, ((float) $order->subtotal - (float) $order->coupon_discount) / (float) $order->subtotal))
                    : 1.0;

                foreach ($orderItems as $item) {
                    ReturnItem::create([
                        'return_request_id' => $return->id,
                        'order_item_id' => $item->id,
                        'quantity' => $item->quantity,
                        'refund_amount' => round((float) $item->total_price * $factor, 2),
                    ]);
                }

                return $return;
            });
        } catch (\Throwable $e) {
            report($e);

            return back()->with('error', 'Unable to submit the return request. Please try again.');
        }

        return redirect()->route('account.order', $order)
            ->with('success', 'Return request '.$returnRequest->return_number.' submitted. Our team will review it shortly.');
    }

    public function submitReview(Request $request, Order $order): RedirectResponse
    {
        abort_unless($order->user_id === auth('web')->id(), 403);

        $request->validate([
            'order_item_id' => ['required', 'exists:order_items,id'],
            'rating' => ['required', 'integer', 'between:1,5'],
            'title' => ['nullable', 'string', 'max:120'],
            'comment' => ['nullable', 'string', 'max:1500'],
            'images' => ['nullable', 'array', 'max:5'],
            'images.*' => ['image', 'mimes:jpeg,jpg,png,webp', 'max:4096'],
        ]);

        // Reviews are only for items the customer actually received. This is the
        // server-side gate: the storefront hides the form elsewhere, but the
        // request could be posted directly against an unpaid order.
        if ($order->order_status !== 'delivered') {
            return back()->with('error', 'You can review this item once the order has been delivered.');
        }

        $item = $order->items()->findOrFail($request->input('order_item_id'));

        try {
            $review = Review::create([
                'product_id' => $item->product_id,
                'user_id' => auth('web')->id(),
                'order_item_id' => $item->id,
                'rating' => $request->input('rating'),
                'title' => $request->input('title'),
                'comment' => $request->input('comment'),
                'status' => 'pending',
                // Derived from the enforced delivered-order gate above rather
                // than hardcoded. Payment is not part of this: a COD order that
                // reached the customer is a verified purchase too.
                'is_verified_purchase' => $order->order_status === 'delivered',
            ]);
        } catch (QueryException $e) {
            // SQLSTATE 23000 (integrity constraint) covers unique violations on
            // both MySQL (1062) and SQLite (19) without being driver-specific.
            if (($e->errorInfo[0] ?? null) === '23000'
                || ($e->errorInfo[1] ?? null) === 1062
                || ($e->errorInfo[1] ?? null) === 19) {
                return back()->with('error', 'You have already reviewed this item.');
            }

            throw $e;
        }

        try {
            $this->storeReviewImages($request, $review);
        } catch (\Throwable $e) {
            return back()->with('error', 'Your review could not be saved with the images. Please try again.');
        }

        return back()->with('success', 'Thank you! Your review has been submitted for approval.');
    }

    /**
     * Persist the customer's photo attachments.
     *
     * Runs only after the review row exists and the duplicate guard above has
     * passed, so a rejected submission never leaves a file behind. A partial
     * failure rolls the whole review back, including anything already written
     * to the disk, so the review and its photos are always all-or-nothing.
     */
    private function storeReviewImages(Request $request, Review $review): void
    {
        $files = $request->file('images', []);

        if (! is_array($files) || $files === []) {
            return;
        }

        $storedPaths = [];

        try {
            foreach (array_values($files) as $index => $file) {
                if (! $file) {
                    continue;
                }

                $path = $file->store('reviews/'.$review->id, 's3');
                $storedPaths[] = $path;

                $review->images()->create([
                    'path' => $path,
                    'disk' => 's3',
                    'mime_type' => $file->getClientMimeType(),
                    'size' => $file->getSize(),
                    'sort_order' => $index,
                ]);
            }
        } catch (\Throwable $e) {
            report($e);

            foreach ($storedPaths as $path) {
                try {
                    Storage::disk('s3')->delete($path);
                } catch (\Throwable $cleanupError) {
                    report($cleanupError);
                }
            }

            $review->delete();

            throw new \RuntimeException('Review images could not be stored.', 0, $e);
        }
    }

    public function addresses(): View
    {
        $addresses = auth('web')->user()->addresses()->latest()->get();

        return view('storefront.account.addresses', compact('addresses'));
    }

    public function createAddress(): View
    {
        $address = new Address;

        return view('storefront.account.address-create', compact('address'));
    }

    public function storeAddress(Request $request): RedirectResponse|JsonResponse
    {
        $data = $this->validateAddress($request);
        $user = auth('web')->user();

        $isFirst = ! $user->addresses()->exists();

        $address = $user->addresses()->create($data);

        if ($isFirst || $request->boolean('is_default')) {
            $this->setDefault($address);
        }

        if ($request->ajax()) {
            return response()->json(['success' => true, 'address' => $address]);
        }

        return redirect()->route('account.addresses')->with('success', 'Address added.');
    }

    public function editAddress(Address $address): View
    {
        abort_unless($address->user_id === auth('web')->id(), 403);

        return view('storefront.account.address-edit', compact('address'));
    }

    public function updateAddress(Request $request, Address $address): RedirectResponse|JsonResponse
    {
        abort_unless($address->user_id === auth('web')->id(), 403);

        $address->update($this->validateAddress($request));

        if ($request->boolean('is_default')) {
            $this->setDefault($address);
        }

        if ($request->ajax()) {
            return response()->json(['success' => true, 'address' => $address]);
        }

        return redirect()->route('account.addresses')->with('success', 'Address updated.');
    }

    public function destroyAddress(Address $address): RedirectResponse
    {
        abort_unless($address->user_id === auth('web')->id(), 403);

        $address->delete();

        return redirect()->route('account.addresses')->with('success', 'Address removed.');
    }

    public function makeDefaultAddress(Address $address): RedirectResponse
    {
        abort_unless($address->user_id === auth('web')->id(), 403);

        $this->setDefault($address);

        return redirect()->route('account.addresses')->with('success', 'Default address updated.');
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $user = auth('web')->user();

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:20', 'regex:/^(?:\+91[\s-]?|0)?[6-9][0-9][\s-]?[0-9]{3}[\s-]?[0-9]{5}$/'],
        ], [
            'phone.regex' => 'Please enter a valid 10-digit mobile number.',
        ]);

        $phone = canonical_phone($data['phone']);

        if ($phone === null) {
            return back()->withErrors(['phone' => 'Please enter a valid 10-digit mobile number.'])->withInput();
        }

        if ($phone !== $user->phone) {
            if (user_by_phone($phone) && user_by_phone($phone)->id !== $user->id) {
                return back()->withErrors(['phone' => 'This mobile number is already registered.'])->withInput();
            }

            if (! app(\App\Services\WhatsAppOtpService::class)->isEnabled()) {
                return back()->withErrors(['phone' => 'Phone changes need WhatsApp verification, which is not enabled.'])->withInput();
            }

            $verified = (string) session('otp_verified_phone', '');

            if ($verified !== $phone) {
                return back()->withErrors(['phone' => 'Verify this mobile number with the WhatsApp code before saving.'])->withInput();
            }
        }

        $user->update([
            'name' => $data['name'],
            'phone' => $phone,
            'phone_verified_at' => $phone !== $user->phone ? now() : $user->phone_verified_at,
        ]);

        session()->forget('otp_verified_phone');

        return back()->with('success', 'Profile updated.');
    }

    protected function validateAddress(Request $request): array
    {
        $data = $request->validate([
            'full_name' => ['required', 'string', 'max:255'],
            'mobile' => ['required', 'string', 'max:20', 'regex:/^(?:\+91[\s-]?|0)?[6-9][0-9][\s-]?[0-9]{3}[\s-]?[0-9]{5}$/'],
            'address_line1' => ['required', 'string', 'max:255'],
            'address_line2' => ['nullable', 'string', 'max:255'],
            'landmark' => ['nullable', 'string', 'max:255'],
            'city' => ['required', 'string', 'max:120'],
            'state' => ['required', 'string', 'max:120'],
            'pincode' => ['required', 'string', 'regex:/^[0-9]{6}$/'],
            'country' => ['nullable', 'string', 'max:80'],
            'type' => ['nullable', 'in:home,office,other'],
        ], [
            'pincode.regex' => 'Please enter a valid 6-digit pincode.',
            'mobile.regex' => 'Please enter a valid 10-digit mobile number.',
        ]);

        $data['mobile'] = canonical_phone($data['mobile']);

        return $data;
    }

    protected function setDefault(Address $address): void
    {
        auth('web')->user()->addresses()->update(['is_default' => false]);
        $address->update(['is_default' => true]);
    }
}
