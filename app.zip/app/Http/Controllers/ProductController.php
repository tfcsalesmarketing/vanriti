<?php

namespace App\Http\Controllers;

use App\Models\Product;

class ProductController extends Controller
{
    public function show(Product $product)
    {
        if ($product->status !== 'active') {
            abort(404);
        }

        $requested = request()->route()->originalParameter('product');
        if (is_string($requested) && $requested !== $product->slug) {
            return redirect()->route('product.show', $product, 301);
        }

        $product->load([
            'images',
            'activeVariants',
            'categories',
            'reviews' => fn ($q) => $q->where('status', 'approved')->orderByDesc('created_at'),
            'reviews.user',
            'reviews.images',
        ]);

        $categoryIds = $product->categories->pluck('id');

        $related = $categoryIds->isNotEmpty()
            ? Product::query()
                ->active()
                ->where('id', '!=', $product->id)
                ->whereHas('categories', fn ($q) => $q->whereIn('categories.id', $categoryIds))
                ->with(['images', 'categories', 'approvedReviews'])
                ->limit(4)
                ->get()
            : collect();

        return view('storefront.product', compact('product', 'related'));
    }
}
