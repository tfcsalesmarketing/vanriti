<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CheckoutRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        if ($this->filled('selected_address') && $this->input('selected_address') !== 'new') {
            $user = auth('web')->user();
            if ($user) {
                $addr = $user->addresses()->find($this->input('selected_address'));
                if ($addr) {
                    $this->merge([
                        'shipping_name' => $this->input('shipping_name') ?: $addr->full_name,
                        'shipping_mobile' => $this->input('shipping_mobile') ?: $addr->mobile,
                        'shipping_address_line1' => $this->input('shipping_address_line1') ?: $addr->address_line1,
                        'shipping_address_line2' => $this->input('shipping_address_line2') ?: $addr->address_line2,
                        'shipping_landmark' => $this->input('shipping_landmark') ?: $addr->landmark,
                        'shipping_city' => $this->input('shipping_city') ?: $addr->city,
                        'shipping_state' => $this->input('shipping_state') ?: $addr->state,
                        'shipping_pincode' => $this->input('shipping_pincode') ?: $addr->pincode,
                        'shipping_country' => $this->input('shipping_country') ?: ($addr->country ?? 'India'),
                    ]);
                }
            }
        }

        if (! $this->has('shipping_method') || blank($this->input('shipping_method'))) {
            $this->merge(['shipping_method' => 'standard']);
        }

        $shipping = canonical_phone($this->input('shipping_mobile'));
        $billing = canonical_phone($this->input('billing_mobile'));

        $this->merge(array_filter([
            'shipping_mobile' => $shipping,
            'billing_mobile' => $billing,
        ], fn ($value) => $value !== null));
    }

    public function rules(): array
    {
        return [
            'shipping_name' => 'required|string|max:255',
            'shipping_mobile' => ['required', 'string', 'max:15', 'regex:/^(?:\+91[\s-]?|0)?[6-9][0-9][\s-]?[0-9]{3}[\s-]?[0-9]{5}$/'],
            'shipping_address_line1' => 'required|string|max:255',
            'shipping_address_line2' => 'nullable|string|max:255',
            'shipping_landmark' => 'nullable|string|max:255',
            'shipping_city' => 'required|string|max:120',
            'shipping_state' => 'required|string|max:120',
            'shipping_pincode' => 'required|string|regex:/^[0-9]{6}$/',
            'shipping_country' => 'nullable|string|max:80',
            'billing_same' => 'nullable|in:1',
            'billing_name' => 'exclude_if:billing_same,1|required|string|max:255',
            'billing_mobile' => ['exclude_if:billing_same,1', 'required', 'string', 'max:15', 'regex:/^(?:\+91[\s-]?|0)?[6-9][0-9][\s-]?[0-9]{3}[\s-]?[0-9]{5}$/'],
            'billing_address_line1' => 'exclude_if:billing_same,1|required|string|max:255',
            'billing_address_line2' => 'nullable|string|max:255',
            'billing_landmark' => 'nullable|string|max:255',
            'billing_city' => 'exclude_if:billing_same,1|required|string|max:120',
            'billing_state' => 'exclude_if:billing_same,1|required|string|max:120',
            'billing_pincode' => 'exclude_if:billing_same,1|required|string|regex:/^[0-9]{6}$/',
            'billing_country' => 'nullable|string|max:80',
            'shipping_method' => 'required|in:standard,express',
            'payment_method' => 'required|in:cod,razorpay',
            'notes' => 'nullable|string|max:500',
        ];
    }

    public function messages(): array
    {
        return [
            'shipping_name.required' => 'Please enter the full name.',
            'shipping_mobile.required' => 'Please enter a mobile number.',
            'shipping_mobile.regex' => 'Please enter a valid 10-digit mobile number.',
            'shipping_address_line1.required' => 'Please enter the address.',
            'shipping_city.required' => 'Please enter the city.',
            'shipping_state.required' => 'Please enter the state.',
            'shipping_pincode.required' => 'Please enter a pincode.',
            'shipping_pincode.regex' => 'Please enter a valid 6-digit pincode.',
            'billing_name.required' => 'Please enter the billing full name.',
            'billing_mobile.required' => 'Please enter a billing mobile number.',
            'billing_mobile.regex' => 'Please enter a valid 10-digit billing mobile number.',
            'billing_address_line1.required' => 'Please enter the billing address.',
            'billing_city.required' => 'Please enter the billing city.',
            'billing_state.required' => 'Please enter the billing state.',
            'billing_pincode.required' => 'Please enter a billing pincode.',
            'billing_pincode.regex' => 'Please enter a valid 6-digit billing pincode.',
            'shipping_method.required' => 'Please select a shipping method.',
            'shipping_method.in' => 'Please select a valid shipping method.',
            'payment_method.required' => 'Please select a payment method.',
            'payment_method.in' => 'Please select a valid payment method.',
        ];
    }
}
