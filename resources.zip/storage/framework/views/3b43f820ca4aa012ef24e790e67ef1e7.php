<?php $__env->startSection('title', $query !== '' ? 'Search results for "'.$query.'"' : 'Shop'); ?>

<?php $__env->startSection('content'); ?>

<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
        {
            "@type": "ListItem",
            "position": 1,
            "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('home'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        {
            "@type": "ListItem",
            "position": 2,
            "name": "Shop",
            "item": <?php echo json_encode(route('shop.index'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }
    ]
}
</script>
<?php if($products->isNotEmpty()): ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "ItemList",
    "name": <?php if($query !== ''): ?><?php echo json_encode('Search results for "'.$query.'"', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?><?php else: ?>"All Products"<?php endif; ?>,
    "url": <?php echo json_encode(route('shop.index'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "itemListElement": [
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
            "@type": "ListItem",
            "position": <?php echo e($i + 1); ?>,
            "url": <?php echo json_encode(route('product.show', $item), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "name": <?php echo json_encode($item->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }<?php if(! $loop->last): ?>,<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
}
</script>
<?php endif; ?>

<div class="container py-4">
    <div class="mb-4">
        <h1 class="h4 fw-bold mb-1" style="color:var(--vr-green-dark);">
            <?php if($query !== ''): ?>
                Search results for '<?php echo e($query); ?>'
            <?php else: ?>
                Shop
            <?php endif; ?>
            <?php if($isFeatured): ?>
                <span class="vr-pill-badge ps-pending ms-2" style="font-size:0.7rem;">Featured</span>
            <?php endif; ?>
        </h1>
        <p class="text-muted small mb-0"><?php echo e($products->total()); ?> product<?php echo e($products->total() === 1 ? '' : 's'); ?></p>
    </div>

    <div class="row g-4">
        <aside class="col-lg-3 d-lg-block">
            <div class="offcanvas offcanvas-start" tabindex="-1" id="shopFilters" aria-labelledby="shopFiltersLabel">
                <div class="offcanvas-header">
                    <h6 class="offcanvas-title fw-bold" id="shopFiltersLabel">Filters</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <div class="vr-shop-sidebar">
                        <form method="GET" action="<?php echo e(route('shop.index')); ?>">
                            <?php if($query !== ''): ?>
                                <input type="hidden" name="q" value="<?php echo e($query); ?>">
                            <?php endif; ?>
                            <?php if($isFeatured): ?>
                                <input type="hidden" name="is_featured" value="1">
                            <?php endif; ?>

                            <div class="mb-3">
                                <label class="form-label small fw-semibold">Search</label>
                                <input type="text" name="q" value="<?php echo e($query); ?>" class="form-control form-control-sm" placeholder="Search products...">
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-semibold">Categories</label>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check small mb-1">
                                        <input class="form-check-input" type="checkbox" name="category[]" value="<?php echo e($cat->id); ?>" id="cat-<?php echo e($cat->id); ?>" <?php if(in_array($cat->id, $selectedCategories)): echo 'checked'; endif; ?>>
                                        <label class="form-check-label" for="cat-<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></label>
                                    </div>
                                    <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check small mb-1 ms-3">
                                            <input class="form-check-input" type="checkbox" name="category[]" value="<?php echo e($child->id); ?>" id="cat-<?php echo e($child->id); ?>" <?php if(in_array($child->id, $selectedCategories)): echo 'checked'; endif; ?>>
                                            <label class="form-check-label" for="cat-<?php echo e($child->id); ?>"><?php echo e($child->name); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-semibold">Price Range</label>
                                <div class="d-flex gap-2">
                                    <input type="number" name="min_price" value="<?php echo e($minPrice); ?>" class="form-control form-control-sm" placeholder="Min">
                                    <input type="number" name="max_price" value="<?php echo e($maxPrice); ?>" class="form-control form-control-sm" placeholder="Max">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-semibold">Sort By</label>
                                <select name="sort" class="form-select form-select-sm">
                                    <option value="" <?php if($sort === '' || $sort === 'newest'): echo 'selected'; endif; ?>>Newest</option>
                                    <option value="price_asc" <?php if($sort === 'price_asc'): echo 'selected'; endif; ?>>Price: Low to High</option>
                                    <option value="price_desc" <?php if($sort === 'price_desc'): echo 'selected'; endif; ?>>Price: High to Low</option>
                                    <option value="popular" <?php if($sort === 'popular'): echo 'selected'; endif; ?>>Popular</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-vr btn-sm w-100 mb-2">Apply Filters</button>
                            <a href="<?php echo e(route('shop.index')); ?>" class="btn btn-vr-outline btn-sm w-100">Clear All</a>
                        </form>
                    </div>
                </div>
            </div>
        </aside>

        <main class="col-lg-9">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <p class="small text-muted mb-0">
                    <?php echo e($products->total()); ?> product<?php echo e($products->total() === 1 ? '' : 's'); ?>

                    <?php if($query !== ''): ?>
                        matching '<?php echo e($query); ?>'
                    <?php endif; ?>
                </p>
                <div class="d-flex align-items-center gap-2">
                    <button class="btn btn-vr-outline btn-sm d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#shopFilters" aria-controls="shopFilters">
                        Filters <i class="bi bi-sliders ms-1"></i>
                    </button>
                    <form method="GET" action="<?php echo e(route('shop.index')); ?>" class="d-flex align-items-center gap-2">
                    <?php if($query !== ''): ?>
                        <input type="hidden" name="q" value="<?php echo e($query); ?>">
                    <?php endif; ?>
                    <?php if($isFeatured): ?>
                        <input type="hidden" name="is_featured" value="1">
                    <?php endif; ?>
                    <?php $__currentLoopData = $selectedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="category[]" value="<?php echo e($c); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($minPrice !== '' && $minPrice !== null): ?>
                        <input type="hidden" name="min_price" value="<?php echo e($minPrice); ?>">
                    <?php endif; ?>
                    <?php if($maxPrice !== '' && $maxPrice !== null): ?>
                        <input type="hidden" name="max_price" value="<?php echo e($maxPrice); ?>">
                    <?php endif; ?>
                    <label class="small text-muted mb-0" for="sortTop">Sort:</label>
                    <select name="sort" id="sortTop" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
                        <option value="" <?php if($sort === '' || $sort === 'newest'): echo 'selected'; endif; ?>>Newest</option>
                        <option value="price_asc" <?php if($sort === 'price_asc'): echo 'selected'; endif; ?>>Price: Low to High</option>
                        <option value="price_desc" <?php if($sort === 'price_desc'): echo 'selected'; endif; ?>>Price: High to Low</option>
                        <option value="popular" <?php if($sort === 'popular'): echo 'selected'; endif; ?>>Popular</option>
                    </select>
                </form>
                </div>
            </div>

            <?php if($products->isEmpty()): ?>
                <div class="vr-empty bg-white rounded-4" style="box-shadow:var(--vr-shadow-xs);">
                    <i class="bi bi-search"></i>
                    <p class="mt-2 mb-0">No products found. Try adjusting your filters.</p>
                </div>
            <?php else: ?>
                <div class="row g-4 vr-stagger">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-md-4 col-xl-3">
                            <?php echo $__env->make('storefront.partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-4 d-flex justify-content-center">
                    <?php echo e($products->links('storefront.partials.pagination')); ?>

                </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/shop.blade.php ENDPATH**/ ?>