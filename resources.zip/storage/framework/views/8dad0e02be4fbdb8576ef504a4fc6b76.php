<?php $__env->startSection('title', setting('meta_title') ?: (store_name() . ' - ' . setting('store_tagline', 'PURE BY NATURE'))); ?>

<?php $__env->startSection('content'); ?>

<?php if($banners->isNotEmpty()): ?>
    <section class="vr-hero">
        <div id="vrHeroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="6000">
            <div class="carousel-indicators">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-bs-target="#vrHeroCarousel" data-bs-slide-to="<?php echo e($i); ?>" class="<?php echo e($i === 0 ? 'active' : ''); ?>" aria-label="Slide <?php echo e($i + 1); ?>"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $img = $banner->image; ?>
                    <div class="carousel-item <?php echo e($i === 0 ? 'active' : ''); ?>">
                        <?php if($banner->link): ?>
                            <a href="<?php echo e($banner->link); ?>" class="d-block">
                                <div class="vr-hero-img" style="background-image:url('<?php echo e(image_url($img)); ?>');"></div>
                            </a>
                        <?php else: ?>
                            <div class="vr-hero-img" style="background-image:url('<?php echo e(image_url($img)); ?>');"></div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#vrHeroCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#vrHeroCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>
<?php else: ?>
    <section class="vr-hero">
        <div class="vr-hero-img" style="background:linear-gradient(120deg, #263D25 0%, #6F8736 100%);">
            <div class="d-flex align-items-center" style="min-height:520px;">
                <div class="container">
                    <h1 class="hero-title mb-3" style="color:#fff;"><?php echo e(store_name()); ?></h1>
                    <p class="lead mb-4" style="color:rgba(255,255,255,0.8);max-width:520px;">Handcrafted skincare, herbal teas and wellness essentials made with nature in mind.</p>
                    <a href="<?php echo e(route('shop.index')); ?>" class="btn btn-vr">
                        <i class="bi bi-bag me-2"></i>Shop Now
                    </a>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<section class="vr-trust py-4">
    <div class="container">
        <div class="row g-3 vr-stagger">
            <div class="col-6 col-lg-3">
                <div class="t-item">
                    <i class="bi bi-truck"></i>
                    <div>
                        <div class="t-title">Free Shipping</div>
                        <div class="t-sub">On orders above <?php echo e(format_price(setting('free_shipping_threshold', 499))); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="t-item">
                    <i class="bi bi-cash-coin"></i>
                    <div>
                        <div class="t-title">COD Available</div>
                        <div class="t-sub">Pay at your doorstep</div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="t-item">
                    <i class="bi bi-arrow-counterclockwise"></i>
                    <div>
                        <div class="t-title">Easy Returns</div>
                        <div class="t-sub"><?php echo e(setting('return_window_days', 7)); ?>-day returns</div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="t-item">
                    <i class="bi bi-flower1"></i>
                    <div>
                        <div class="t-title">Cruelty-Free</div>
                        <div class="t-sub">100% natural &amp; kind</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="vr-section">
    <div class="container">
        <div class="d-flex align-items-end justify-content-between mb-4 vr-animate-in">
            <div>
                <h2 class="vr-section-title mb-1">Featured</h2>
                <p class="vr-section-sub mb-0">Handpicked favourites from our collection</p>
            </div>
            <a href="<?php echo e(route('shop.index')); ?>" class="vr-link-more">View all <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="row g-4 vr-stagger">
            <?php $__empty_1 = true; $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-6 col-md-4 col-xl-3">
                    <?php echo $__env->make('storefront.partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="vr-empty bg-white rounded-4" style="box-shadow:var(--vr-shadow-xs);">
                        <i class="bi bi-box"></i>
                        <p class="mt-2 mb-0">No featured products yet.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php if($bestsellers->isNotEmpty()): ?>
    <section class="vr-section pt-0">
        <div class="container">
            <div class="d-flex align-items-end justify-content-between mb-4 vr-animate-in">
                <div>
                    <h2 class="vr-section-title mb-1">Bestsellers</h2>
                    <p class="vr-section-sub mb-0">Loved by thousands of happy customers</p>
                </div>
                <a href="<?php echo e(route('shop.index')); ?>?sort=popular" class="vr-link-more">View all <i class="bi bi-arrow-right"></i></a>
            </div>
            <div class="row g-4 vr-stagger">
                <?php $__currentLoopData = $bestsellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-4 col-xl-3">
                        <?php echo $__env->make('storefront.partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if($newArrivals->isNotEmpty()): ?>
    <section class="vr-section pt-0">
        <div class="container">
            <div class="d-flex align-items-end justify-content-between mb-4 vr-animate-in">
                <div>
                    <h2 class="vr-section-title mb-1">New Arrivals</h2>
                    <p class="vr-section-sub mb-0">Fresh from our lab to your shelf</p>
                </div>
                <a href="<?php echo e(route('shop.index')); ?>?sort=newest" class="vr-link-more">View all <i class="bi bi-arrow-right"></i></a>
            </div>
            <div class="row g-4 vr-stagger">
                <?php $__currentLoopData = $newArrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-4 col-xl-3">
                        <?php echo $__env->make('storefront.partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if($categories->isNotEmpty()): ?>
    <section class="vr-section pt-0">
        <div class="container">
            <div class="mb-4 text-center vr-animate-in">
                <h2 class="vr-section-title mb-1">Shop by Category</h2>
                <p class="vr-section-sub mb-0">Explore our collections</p>
            </div>
            <div class="row g-3 justify-content-center vr-stagger">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-4 col-md-3">
                        <a href="<?php echo e(route('shop.category', $cat->slug)); ?>" class="vr-cat-card d-block text-center">
                            <div class="vr-cat-img-wrap">
                                <?php if($cat->image): ?>
                                    <img src="<?php echo e(image_url($cat->image)); ?>" alt="<?php echo e($cat->name); ?>" loading="lazy">
                                <?php else: ?>
                                    <div class="vr-cat-placeholder"><i class="bi bi-grid-3x3-gap"></i></div>
                                <?php endif; ?>
                            </div>
                            <span class="vr-cat-name"><?php echo e($cat->name); ?></span>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<section class="vr-section pt-0">
    <div class="container">
        <div class="vr-cta-band p-4 p-md-5 text-center vr-animate-in">
            <div class="cta-inner">
                <div class="vr-kicker justify-content-center mb-2">PURE BY NATURE</div>
                <h2 class="vr-section-title mb-2">Join the <?php echo e(strtoupper(store_name())); ?> family</h2>
                <p class="vr-section-sub mx-auto mb-4" style="max-width:520px;">Get skincare tips, early access to new drops and exclusive offers straight to your inbox.</p>
                <form class="mx-auto d-flex gap-2" style="max-width:460px;" action="<?php echo e(route('newsletter.subscribe')); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="flex-grow-1">
                        <input type="email" name="email" class="form-control" placeholder="Your email address">
                        <div class="invalid-feedback"></div>
                    </div>
                    <button type="submit" class="btn btn-vr text-nowrap">
                        <i class="bi bi-send me-1"></i>Subscribe
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php
    $_logo = setting('store_logo');
    if (! $_logo) { foreach (['svg', 'png', 'webp', 'jpg'] as $_ext) { if (file_exists(public_path('images/logo.' . $_ext))) { $_logo = 'images/logo.' . $_ext; break; } } }
?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "url": <?php echo json_encode(route('home'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "logo": <?php echo json_encode(image_url($_logo, 'favicon.ico'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    <?php if(setting('store_email')): ?>"email": <?php echo json_encode(setting('store_email'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,<?php endif; ?>
    <?php if(setting('store_phone')): ?>"telephone": <?php echo json_encode(setting('store_phone'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,<?php endif; ?>
    <?php if(setting('store_address')): ?>"address": <?php echo json_encode(setting('store_address'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,<?php endif; ?>
    "sameAs": [
        <?php
            $_socials = array_filter([
                setting('facebook_url'),
                setting('instagram_url'),
                setting('twitter_url'),
                setting('youtube_url'),
                setting('linkedin_url'),
            ]);
        ?>
        <?php $__currentLoopData = $_socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo json_encode($_social, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?><?php if(! $loop->last): ?>,<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/home.blade.php ENDPATH**/ ?>