<?php $__env->startSection('title', $category->meta_title ?: $category->name); ?>
<?php $__env->startSection('meta_description', $category->meta_description ?: setting('meta_description')); ?>
<?php $__env->startSection('meta_keywords', $category->meta_keywords ?: setting('meta_keywords')); ?>
<?php $__env->startSection('og_title', $category->meta_title ?: $category->name); ?>
<?php $__env->startSection('og_description', $category->meta_description ?: setting('meta_description')); ?>

<?php $__env->startSection('content'); ?>

<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
        {
            "@type": "ListItem",
            "position": 1,
            "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('home'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        <?php if($category->parent): ?>
        {
            "@type": "ListItem",
            "position": 2,
            "name": <?php echo json_encode($category->parent->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('shop.category', $category->parent->slug), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        <?php endif; ?>
        {
            "@type": "ListItem",
            "position": <?php echo e($category->parent ? 3 : 2); ?>,
            "name": <?php echo json_encode($category->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('shop.category', $category->slug), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }
    ]
}
</script>
<?php if($products->isNotEmpty()): ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "ItemList",
    "name": <?php echo json_encode($category->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "url": <?php echo json_encode(route('shop.category', $category->slug), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "itemListElement": [
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
            "@type": "ListItem",
            "position": <?php echo e($i + 1); ?>,
            "url": <?php echo json_encode(route('product.show', $item), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "name": <?php echo json_encode($item->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }<?php if(! $loop->last): ?>,<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
}
</script>
<?php endif; ?>

<div class="container py-4">
    <nav class="vr-breadcrumb mb-3" aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
        </ol>
    </nav>

    <div class="mb-4">
        <h1 class="h4 fw-bold mb-1" style="color:var(--vr-green-dark);"><?php echo e($category->name); ?></h1>
        <?php if($category->description): ?>
            <p class="text-muted small mt-2 mb-0" style="max-width:720px;"><?php echo e($category->description); ?></p>
        <?php endif; ?>
    </div>

    <?php if($category->children->count()): ?>
        <div class="d-flex overflow-auto pb-2 mb-4 gap-2" style="scrollbar-width:thin;">
            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shop.category', $child->slug)); ?>" class="vr-chip text-nowrap">
                    <i class="bi bi-tag"></i>
                    <?php echo e($child->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="d-flex align-items-center justify-content-between mb-3">
        <p class="small text-muted mb-0"><?php echo e($products->total()); ?> product<?php echo e($products->total() === 1 ? '' : 's'); ?></p>
    </div>

    <?php if($products->isEmpty()): ?>
        <div class="vr-empty bg-white rounded-4" style="box-shadow:var(--vr-shadow-xs);">
            <i class="bi bi-box"></i>
            <p class="mt-2 mb-0">No products in this category yet.</p>
        </div>
    <?php else: ?>
        <div class="row g-4 vr-stagger">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-4 col-xl-3">
                    <?php echo $__env->make('storefront.partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-4 d-flex justify-content-center">
            <?php echo e($products->links('storefront.partials.pagination')); ?>

        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/category.blade.php ENDPATH**/ ?>