<?php $__env->startSection('title', 'My Wishlist'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-section py-4 py-lg-5">
    <div class="container">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="vr-section-title mb-1">My Wishlist</h1>
                <p class="text-muted small mb-0">Items you've saved for later</p>
            </div>
            <?php if($wishlistItems->isNotEmpty()): ?>
                <span class="vr-type-chip"><?php echo e($wishlistItems->count()); ?> <?php echo e(Str::plural('item', $wishlistItems->count())); ?></span>
            <?php endif; ?>
        </div>

        <?php if($wishlistItems->isEmpty()): ?>
            <div class="vr-guest-card text-center py-5 max-w-lg mx-auto" style="max-width: 500px;">
                <div class="vr-guest-icon-box mb-3" style="width: 72px; height: 72px; font-size: 2.5rem;">
                    <i class="ri-heart-line"></i>
                </div>
                <h4 class="fw-bold mb-2">Your Wishlist is Empty</h4>
                <p class="text-muted small mb-4">Save products you love to your wishlist and revisit them anytime.</p>
                <a href="<?php echo e(route('shop.index')); ?>" class="btn vr-app-btn px-4 py-2">
                    <i class="ri-compass-line me-2"></i> Discover Products
                </a>
            </div>
        <?php else: ?>
            <div class="row g-3 g-md-4">
                <?php $__currentLoopData = $wishlistItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="vr-wishlist-card h-100 d-flex flex-column">
                            <div class="vr-wishlist-img">
                                <a href="<?php echo e(route('product.show', $product->slug)); ?>">
                                    <img src="<?php echo e(image_url($product->getPrimaryImage()?->image_path, 'images/placeholder.png')); ?>"
                                         alt="<?php echo e($product->name); ?>">
                                </a>
                                <?php if($product->mrp > $product->selling_price): ?>
                                    <?php
                                        $discountPct = round((($product->mrp - $product->selling_price) / $product->mrp) * 100);
                                    ?>
                                    <span class="vr-dock-badge position-absolute top-2 start-2 bg-danger" style="animation:none;">-<?php echo e($discountPct); ?>%</span>
                                <?php endif; ?>
                            </div>
                            <div class="p-3 d-flex flex-column flex-grow-1">
                                <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="fw-semibold text-dark text-truncate d-block mb-1">
                                    <?php echo e($product->name); ?>

                                </a>
                                
                                <div class="vr-price mb-3">
                                    <span class="now fw-bold text-dark fs-6"><?php echo e(format_price($product->selling_price)); ?></span>
                                    <?php if($product->mrp > $product->selling_price): ?>
                                        <span class="mrp text-muted small text-decoration-line-through ms-1"><?php echo e(format_price($product->mrp)); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="mt-auto d-flex gap-2">
                                    <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST" class="flex-grow-1">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="quantity" value="1">
                                        <input type="hidden" name="remove_from_wishlist" value="1">
                                        <button type="submit" class="btn vr-app-btn btn-sm w-100 py-2">
                                            <i class="ri-shopping-bag-3-line me-1"></i> Add
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('wishlist.toggle', $product)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn vr-app-outline-btn btn-sm py-2 px-2" title="Remove from wishlist">
                                            <i class="ri-delete-bin-line text-danger"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/wishlist/index.blade.php ENDPATH**/ ?>