<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="facebook-domain-verification" content="uiy2uo8dqx16mp5h2f784kpbs4ry53" />
    <?php
        $_seoTitle = trim((string) $__env->yieldContent('title'));
        $_brandName = store_name();
        $_escapedBrand = e($_brandName);
        if ($_seoTitle === '') {
            $_seoTitle = setting('meta_title') ? e(setting('meta_title')) : $_escapedBrand;
        }
        if ($_seoTitle !== '' && $_seoTitle !== $_escapedBrand && mb_strpos($_seoTitle, $_escapedBrand) === false) {
            $_seoTitle .= ' - ' . $_escapedBrand;
        }
        $_ogTagline = (string) setting('store_tagline', 'PURE BY NATURE');
        $_ogDefault = $_brandName . ($_ogTagline !== '' ? ' - ' . $_ogTagline : '');
        if (setting('meta_title')) {
            $_ogDefault = (string) setting('meta_title');
        }
    ?>
    <title><?php echo $_seoTitle; ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', setting('meta_description')); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', setting('meta_keywords')); ?>">
    <meta name="robots" content="<?php echo $__env->yieldContent('robots', 'index, follow'); ?>">
    <link rel="canonical" href="<?php echo e(request()->url()); ?>">
    <?php
        $_brandLogo = setting('store_logo');
        if (! $_brandLogo) {
            foreach (['svg', 'png', 'webp', 'jpg', 'ico'] as $_ext) {
                if (file_exists(public_path('images/logo.' . $_ext))) {
                    $_brandLogo = 'images/logo.' . $_ext;
                    break;
                }
            }
        }
    ?>
    <meta property="og:title" content="<?php echo $__env->yieldContent('og_title', $_ogDefault); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('og_description', setting('meta_description')); ?>">
    <meta property="og:url" content="<?php echo e(request()->url()); ?>">
    <meta property="og:type" content="<?php echo $__env->yieldContent('og_type', 'website'); ?>">
    <meta property="og:site_name" content="<?php echo e(store_name()); ?>">
    <meta property="og:locale" content="en_IN">
    <meta property="og:image" content="<?php echo $__env->yieldContent('og_image', image_url($_brandLogo, 'favicon.ico')); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('og_title', $_ogDefault); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('og_description', setting('meta_description')); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('og_image', image_url($_brandLogo, 'favicon.ico')); ?>">
    <meta name="theme-color" content="#263D25">
    <link rel="icon" href="<?php echo e(image_url($_brandLogo, 'favicon.ico')); ?>" sizes="any">
    <link rel="apple-touch-icon" href="<?php echo e(image_url($_brandLogo, 'favicon.ico')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/storefront.css')); ?>?v=<?php echo e(time()); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
        "url": <?php echo json_encode(route('home'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
        "potentialAction": {
            "@type": "SearchAction",
            "target": {
                "@type": "EntryPoint",
                "urlTemplate": <?php echo json_encode(route('shop.index') . '?q={search_term_string}', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

            },
            "query-input": "required name=search_term_string"
        }
    }
    </script>
    <script>
    window.dataLayer = window.dataLayer || [];
    </script>
    <?php if(config('analytics.gtm_container_id')): ?>
        <script>
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;
        j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;
        f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','<?php echo e(config('analytics.gtm_container_id')); ?>');
        </script>
    <?php endif; ?>
    <?php if(setting('meta_pixel_id')): ?>
        <script>
        !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '<?php echo e(setting('meta_pixel_id')); ?>');
        fbq('track', 'PageView');
        </script>
        <noscript><img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=<?php echo e(setting('meta_pixel_id')); ?>&ev=PageView&noscript=1"
        /></noscript>
    <?php endif; ?>
</head>
<body class="has-mobile-bar">
    <?php if(config('analytics.gtm_container_id')): ?>
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo e(config('analytics.gtm_container_id')); ?>"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <?php endif; ?>
    <?php echo $__env->make('storefront.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main>
        <?php if(session('success')): ?>
            <div class="container mt-3">
                <div class="alert alert-success alert-dismissible fade show py-2 small" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="container mt-3">
                <div class="alert alert-danger alert-dismissible fade show py-2 small" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </div>
        <?php endif; ?>
        <?php if(! empty($errors) && $errors->any()): ?>
            <script type="application/json" id="vrValidationErrors"><?php echo json_encode($errors->getMessages()); ?></script>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('storefront.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/storefront.js')); ?>?v=<?php echo e(time()); ?>"></script>
    <script>
    (function () {
        var nav = document.getElementById('vrNavbar');
        if (nav) {
            window.addEventListener('scroll', function () {
                nav.classList.toggle('scrolled', window.scrollY > 20);
            }, { passive: true });
        }

        if ('IntersectionObserver' in window) {
            var items = document.querySelectorAll('.vr-animate-in, .vr-stagger');
            if (items.length) {
                var obs = new IntersectionObserver(function (entries) {
                    entries.forEach(function (e) {
                        if (e.isIntersecting) {
                            e.target.classList.add('vr-visible');
                            obs.unobserve(e.target);
                        }
                    });
                }, { threshold: 0.12 });
                items.forEach(function (el) { obs.observe(el); });
            }
        }
    })();
    </script>
    <script>
    (function () {
        var el = document.getElementById('vrValidationErrors');
        if (!el) return;
        try {
            var errors = JSON.parse(el.textContent);
        } catch (e) { return; }
        if (typeof window.vrInlineErrors === 'function') {
            window.vrInlineErrors(errors);
        }
    })();
    </script>
    <?php $pendingAddToCart = session()->pull('pending_add_to_cart'); ?>
    <?php if($pendingAddToCart): ?>
        <script>
        window.dataLayer.push(<?php echo json_encode($pendingAddToCart, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>);
        </script>
    <?php endif; ?>
    <?php
        $pendingRefundUserId = auth('web')->id();
        $pendingRefundEvents = $pendingRefundUserId
            ? cache()->pull(\App\Services\RefundService::PENDING_REFUND_CACHE_KEY.$pendingRefundUserId)
            : null;
    ?>
    <?php if(! empty($pendingRefundEvents) && is_array($pendingRefundEvents)): ?>
        <?php $__currentLoopData = $pendingRefundEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendingRefundEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
            window.dataLayer.push(<?php echo json_encode($pendingRefundEvent, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>);
            </script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/layouts/app.blade.php ENDPATH**/ ?>