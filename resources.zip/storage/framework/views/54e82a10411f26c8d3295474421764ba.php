<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Products</h5>
        <small class="text-muted"><?php echo e($products->total()); ?> products total</small>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Product</a>
        <a href="<?php echo e(route('admin.products.export')); ?>" class="btn btn-sm btn-outline-success"><i class="bi bi-download me-1"></i>Export CSV</a>
        <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#importModal"><i class="bi bi-upload me-1"></i>Import CSV</button>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.products.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control form-control-sm" placeholder="Search name or SKU..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Status</option>
                    <option value="draft" <?php echo e(request('status') === 'draft' ? 'selected' : ''); ?>>Draft</option>
                    <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="category_id" class="form-select form-select-sm">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->parent_id ? '— ' : ''); ?><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>SKU</th>
                    <th>Category</th>
                    <th class="text-end">Price</th>
                    <th class="text-end">Stock</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php $img = $product->images->first(); ?>
                                <?php if($img): ?>
                                    <img src="<?php echo e(image_url($img->image_path)); ?>" alt="" class="rounded" width="40" height="40" style="object-fit:cover;">
                                <?php else: ?>
                                    <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:40px;height:40px;">
                                        <i class="bi bi-image text-muted"></i>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-semibold small text-truncate" style="max-width:200px;">
                                        <a href="<?php echo e(route('admin.products.show', $product->slug)); ?>" class="text-decoration-none text-dark"><?php echo e($product->name); ?></a>
                                    </div>
                                    <div class="text-muted" style="font-size:0.75rem;"><?php echo e($product->slug); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="small"><?php echo e($product->sku ?: '—'); ?></td>
                        <td class="small">
                            <?php $pc = $product->categories->first(); ?>
                            <?php echo e($pc ? $pc->name : '—'); ?>

                        </td>
                        <td class="text-end">
                            <div class="fw-semibold small"><?php echo e(format_price($product->selling_price)); ?></div>
                            <?php if($product->mrp > $product->selling_price): ?>
                                <div><del class="text-muted small"><?php echo e(format_price($product->mrp)); ?></del> <span class="badge bg-success" style="font-size:0.65rem;"><?php echo e($product->discount_percent); ?>% off</span></div>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <?php $stock = $product->getAvailableStock(); ?>
                            <span class="small"><?php echo e($stock); ?></span>
                            <?php if($product->isOutOfStock()): ?>
                                <span class="badge bg-danger" style="font-size:0.6rem;">Out</span>
                            <?php elseif($product->isLowStock()): ?>
                                <span class="badge bg-warning text-dark" style="font-size:0.6rem;">Low</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                                $statusClasses = ['draft' => 'secondary', 'active' => 'success', 'inactive' => 'danger'];
                            ?>
                            <span class="badge bg-<?php echo e($statusClasses[$product->status] ?? 'secondary'); ?>"><?php echo e(ucfirst($product->status)); ?></span>
                        </td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <a href="<?php echo e(route('admin.products.show', $product->slug)); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="bi bi-eye"></i></a>
                                <a href="<?php echo e(route('admin.products.edit', $product->slug)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <form method="POST" action="<?php echo e(route('admin.products.destroy', $product->slug)); ?>" onsubmit="return confirm('Delete this product?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No products found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($products->links()); ?>

    </div>
</div>

<div class="modal fade" id="importModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('admin.products.import')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title fw-bold">Import Products</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="small text-muted mb-2">Upload a CSV file with columns: name, sku, mrp, selling_price, gst_rate, stock, status, category_slug</p>
                    <input type="file" name="import_file" class="form-control" accept=".csv,.txt" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm btn-primary">Import</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/products/index.blade.php ENDPATH**/ ?>