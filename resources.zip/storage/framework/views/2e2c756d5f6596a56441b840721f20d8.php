<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('meta_description', $product->meta_description ?: $product->short_description ?: setting('meta_description')); ?>
<?php $__env->startSection('meta_keywords', $product->meta_keywords ?: setting('meta_keywords')); ?>
<?php $__env->startSection('og_title', $product->name); ?>
<?php $__env->startSection('og_description', $product->short_description ?: $product->meta_description ?: setting('meta_description')); ?>
<?php $__env->startSection('og_image', $product->getPrimaryImage()
    ? image_url($product->getPrimaryImage()?->image_path, 'favicon.ico')
    : image_url(null, 'favicon.ico')); ?>

<?php $__env->startSection('content'); ?>

<?php
    $img = $product->getPrimaryImage()?->image_path;
    $gallery = $product->images;
    $available = $product->getAvailableStock();
    $out = $available <= 0;
    $low = ! $out && $product->isLowStock();
    $category = $product->categories->first();
    $reviews = $product->reviews;
    $reviewCount = $reviews->count();
    $reviewAvg = $reviewCount ? round((float) $reviews->avg('rating'), 1) : 0;
    $discount = $product->discountPercent();
    $wishlistService = app(App\Services\WishlistService::class);
    $liked = $wishlistService->has($product);
    $firstInStockVariant = $product->activeVariants->first(fn ($v) => (int) $v->stock > 0);
    $viewItemPayload = app(App\Services\Analytics\EcommerceDataService::class)->viewItem($product, $firstInStockVariant, 1);
?>

<div class="container py-4">
    <nav class="vr-breadcrumb mb-4" aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <?php if($category): ?>
                <li class="breadcrumb-item"><a href="<?php echo e(route('shop.category', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
        </ol>
    </nav>

    <div class="row g-4 g-lg-5">
        <div class="col-lg-5">
            <div class="vr-zoom-container" id="vrZoomContainer">
                <?php if($img): ?>
                    <a href="#" id="vrMainImageWrap" class="vr-zoom d-block mb-3" role="button" aria-label="Zoom product image" data-bs-toggle="modal" data-bs-target="#vrLightbox">
                        <img id="vrMainImage" src="<?php echo e(image_url($img)); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid rounded-3 w-100 vr-zoom-image" style="aspect-ratio:1/1;object-fit:cover;" fetchpriority="high">
                    </a>
                <?php else: ?>
                    <a href="#" id="vrMainImageWrap" class="vr-zoom d-block mb-3" role="button" aria-label="Zoom product image" data-bs-toggle="modal" data-bs-target="#vrLightbox">
                        <div id="vrMainImage" class="bg-light rounded-3 d-flex align-items-center justify-content-center" style="aspect-ratio:1/1;">
                            <i class="bi bi-image text-secondary display-4"></i>
                        </div>
                    </a>
                <?php endif; ?>
                <div class="vr-zoom-lens" id="vrZoomLens"></div>
                <div class="vr-zoom-result" id="vrZoomResult"></div>
            </div>

            <?php if($gallery->count() > 1): ?>
                <div class="row g-2">
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $thumb = $image->image_path; ?>
                        <div class="col-3">
                            <div class="vr-gallery-thumb <?php echo e($thumb && $thumb === $img ? 'active' : ''); ?>" data-image="<?php echo e(image_url($thumb)); ?>">
                                <img src="<?php echo e(image_url($thumb)); ?>" alt="<?php echo e($image->alt_text ?: $product->name); ?>" class="img-fluid" style="aspect-ratio:1/1;object-fit:cover;">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="col-lg-7">
            <?php if($category): ?>
                <a href="<?php echo e(route('shop.category', $category->slug)); ?>" class="cat-name text-uppercase text-decoration-none d-inline-block mb-1"><?php echo e($category->name); ?></a>
            <?php endif; ?>
            <h1 class="h3 fw-bold mb-2"><?php echo e($product->name); ?></h1>

            <?php if($reviewCount > 0): ?>
                <div class="rating-stars small mb-3">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <i class="bi bi-star<?php echo e($i <= (int) round($reviewAvg) ? '-fill filled' : ''); ?>"></i>
                    <?php endfor; ?>
                    <span class="text-muted ms-1"><?php echo e($reviewAvg); ?> · <?php echo e($reviewCount); ?> review<?php echo e($reviewCount === 1 ? '' : 's'); ?></span>
                </div>
            <?php endif; ?>

            <div class="vr-price mb-3">
                <span class="now fs-3" id="vrNowPrice"><?php echo e(format_price($product->selling_price)); ?></span>
                <span class="mrp fs-6" id="vrMrpPrice" <?php if($product->mrp <= $product->selling_price): ?> style="display:none;" <?php endif; ?>><?php echo e(format_price($product->mrp)); ?></span>
                <?php if($discount > 0): ?>
                    <span class="small fw-bold" style="color:var(--vr-green);" id="vrDiscPct"><?php echo e((int) round($discount)); ?>% OFF</span>
                <?php endif; ?>
            </div>

            <?php if($product->short_description): ?>
                <p class="text-muted mb-3"><?php echo e($product->short_description); ?></p>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('cart.add', $product)); ?>" id="addToCartForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="buy_now" value="0">

                <?php if($product->activeVariants->isNotEmpty()): ?>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Select Option</label>
                        <div class="d-grid gap-2" id="vrVariantList">
                            <?php $__currentLoopData = $product->activeVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $vOut = (int) $v->stock <= 0; ?>
                                <label class="vr-variant-option border rounded-3 p-2 d-flex align-items-center gap-2 <?php echo e($vOut ? 'is-out' : ''); ?> <?php echo e($firstInStockVariant && $firstInStockVariant->id === $v->id ? 'is-selected' : ''); ?>"
                                       data-price="<?php echo e($v->selling_price); ?>"
                                       data-price-fmt="<?php echo e(format_price($v->selling_price)); ?>"
                                       data-mrp="<?php echo e($v->mrp); ?>"
                                       data-mrp-fmt="<?php echo e(format_price($v->mrp)); ?>"
                                       data-instock="<?php echo e($vOut ? 0 : (int) $v->stock); ?>">
                                    <input type="radio" name="variant_id" value="<?php echo e($v->id); ?>" class="form-check-input mt-0"
                                           <?php if($firstInStockVariant && $firstInStockVariant->id === $v->id): echo 'checked'; endif; ?>
                                           <?php echo e($vOut ? 'disabled' : ''); ?>>
                                    <span class="small flex-grow-1"><?php echo e($v->name); ?></span>
                                    <span class="small fw-semibold"><?php echo e(format_price($v->selling_price)); ?></span>
                                    <?php if($v->mrp > $v->selling_price): ?>
                                        <span class="small text-muted text-decoration-line-through"><?php echo e(format_price($v->mrp)); ?></span>
                                    <?php endif; ?>
                                    <?php if($vOut): ?>
                                        <span class="vr-stock-label out">Out of stock</span>
                                    <?php endif; ?>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="d-flex flex-wrap align-items-center gap-3 mb-3">
                    <div class="vr-qty">
                        <button type="button" class="qty-minus" data-step="-1" aria-label="Decrease quantity"><i class="bi bi-dash"></i></button>
                        <input type="number" name="quantity" value="1" min="1" aria-label="Quantity" id="vrBuyQty">
                        <button type="button" data-step="1" aria-label="Increase quantity"><i class="bi bi-plus"></i></button>
                    </div>
                    <button type="submit" class="btn btn-vr btn-lg flex-grow-1 js-pdp-add" <?php echo e($out ? 'disabled' : ''); ?>>
                        <i class="bi bi-bag me-2"></i> Add to Cart
                    </button>
                    <button type="submit" name="buy_now" value="1" class="btn btn-vr-outline btn-lg flex-grow-1 js-pdp-buy" <?php echo e($out ? 'disabled' : ''); ?>>
                        <i class="bi bi-lightning-charge me-2"></i> Buy Now
                    </button>
                </div>
            </form>

            <form method="POST" action="<?php echo e(route('wishlist.toggle', $product)); ?>" class="mb-3">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-vr-outline btn-lg w-100">
                    <i class="bi <?php echo e($liked ? 'bi-heart-fill' : 'bi-heart'); ?> me-2"></i>
                    <?php echo e($liked ? 'In Wishlist' : 'Add to Wishlist'); ?>

                </button>
            </form>

            <div class="mb-3">
                <?php if($out): ?>
                    <span class="vr-stock-label out d-inline-block mb-2">Out of stock</span>
                <?php elseif($low): ?>
                    <span class="vr-stock-label in d-inline-block mb-2">Only <?php echo e($available); ?> left in stock</span>
                <?php endif; ?>
            </div>

            <ul class="list-unstyled d-flex flex-wrap gap-3 small text-muted mb-0">
                <li><i class="bi bi-truck me-1" style="color:var(--vr-green);"></i> Free shipping above <?php echo e(format_price(setting('free_shipping_threshold', 499))); ?></li>
                <li><i class="bi bi-cash-coin me-1" style="color:var(--vr-green);"></i> COD available</li>
                <li><i class="bi bi-arrow-counterclockwise me-1" style="color:var(--vr-green);"></i> <?php echo e(setting('return_window_days', 7)); ?>-day easy returns</li>
                <li><i class="bi bi-flower1 me-1" style="color:var(--vr-green);"></i> Cruelty-free &amp; natural</li>
            </ul>
        </div>
    </div>

    <div class="vr-accordion accordion mt-5" id="vrProductAccordion">
        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-description">Description</button>
            </h2>
            <div id="collapse-description" class="accordion-collapse collapse show" data-bs-parent="#vrProductAccordion">
                <div class="accordion-body">
                    <div><?php echo $product->description ?: 'No description available.'; ?></div>
                    <?php if($product->net_quantity || $product->country_of_origin || $product->shelf_life): ?>
                        <div class="row g-3 mt-3 small">
                            <?php if($product->net_quantity): ?>
                                <div class="col-6 col-md-3"><div class="text-muted">Net Quantity</div><div class="fw-semibold"><?php echo e($product->net_quantity); ?> <?php echo e($product->unit); ?></div></div>
                            <?php endif; ?>
                            <?php if($product->country_of_origin): ?>
                                <div class="col-6 col-md-3"><div class="text-muted">Country of Origin</div><div class="fw-semibold"><?php echo e($product->country_of_origin); ?></div></div>
                            <?php endif; ?>
                            <?php if($product->shelf_life): ?>
                                <div class="col-6 col-md-3"><div class="text-muted">Shelf Life</div><div class="fw-semibold"><?php echo e($product->shelf_life); ?></div></div>
                            <?php endif; ?>
                            <?php if($product->manufacturer): ?>
                                <div class="col-6 col-md-3"><div class="text-muted">Manufacturer</div><div class="fw-semibold"><?php echo e($product->manufacturer); ?></div></div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if($product->highlights): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-highlights">Highlights</button>
                </h2>
                <div id="collapse-highlights" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body">
                        <ul class="mb-0 ps-3">
                            <?php $__currentLoopData = preg_split('/\R/', (string) $product->highlights); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(trim($line) !== ''): ?>
                                    <li class="mb-1"><?php echo e($line); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($product->ingredients): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-ingredients">Ingredients</button>
                </h2>
                <div id="collapse-ingredients" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body"><?php echo e($product->ingredients); ?></div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($product->how_to_use): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-usage">How to Use</button>
                </h2>
                <div id="collapse-usage" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body"><?php echo e($product->how_to_use); ?></div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($product->benefits): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-benefits">Benefits</button>
                </h2>
                <div id="collapse-benefits" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body">
                        <ul class="mb-0 ps-3">
                            <?php $__currentLoopData = preg_split('/\R/', (string) $product->benefits); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(trim($line) !== ''): ?>
                                    <li class="mb-1"><?php echo e($line); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($product->warnings): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-warnings">Warnings</button>
                </h2>
                <div id="collapse-warnings" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body"><?php echo e($product->warnings); ?></div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($product->precautions): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-precautions">Precautions</button>
                </h2>
                <div id="collapse-precautions" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body"><?php echo e($product->precautions); ?></div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($product->disclaimer): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-disclaimer">Disclaimer</button>
                </h2>
                <div id="collapse-disclaimer" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body"><em class="small text-muted"><?php echo e($product->disclaimer); ?></em></div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(setting('return_policy')): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-shipping">Shipping &amp; Returns</button>
                </h2>
                <div id="collapse-shipping" class="accordion-collapse collapse" data-bs-parent="#vrProductAccordion">
                    <div class="accordion-body"><?php echo e(setting('return_policy')); ?></div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <section class="mt-5 vr-animate-in">
        <h2 class="h5 fw-bold mb-3" style="color:var(--vr-green-dark);">Customer Reviews</h2>
        <?php if($reviewCount > 0): ?>
            <div class="d-flex align-items-center gap-3 mb-4">
                <div class="text-center pe-3" style="border-right:1px solid var(--vr-border);">
                    <div class="fs-3 fw-bold" style="color:var(--vr-green-dark);"><?php echo e($reviewAvg); ?></div>
                    <div class="rating-stars small">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="bi bi-star<?php echo e($i <= (int) round($reviewAvg) ? '-fill filled' : ''); ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <div class="small text-muted mt-1"><?php echo e($reviewCount); ?> review<?php echo e($reviewCount === 1 ? '' : 's'); ?></div>
                </div>
            </div>
            <div class="d-grid gap-3">
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-3" style="border-radius:var(--vr-radius);background:#fff;box-shadow:var(--vr-shadow-xs);">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="fw-semibold small"><?php echo e($review->user?->name ?: 'Verified Buyer'); ?></span>
                            <?php if($review->is_verified_purchase): ?>
                                <span class="vr-pill-badge ps-paid" style="font-size:0.62rem;">Verified Purchase</span>
                            <?php endif; ?>
                            <span class="small text-muted ms-auto"><?php echo e($review->created_at?->format('d M Y')); ?></span>
                        </div>
                        <div class="rating-stars small mb-1">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <i class="bi bi-star<?php echo e($i <= (int) $review->rating ? '-fill filled' : ''); ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <?php if($review->title): ?>
                            <div class="fw-semibold small"><?php echo e($review->title); ?></div>
                        <?php endif; ?>
                        <?php if($review->comment): ?>
                            <p class="small text-muted mb-0 mt-1"><?php echo e($review->comment); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="vr-empty bg-white rounded-4" style="box-shadow:var(--vr-shadow-xs);">
                <i class="bi bi-chat-left-text"></i>
                <p class="mt-2 mb-0">No reviews yet. Be the first to review this product.</p>
            </div>
        <?php endif; ?>
    </section>

    <?php if($related->isNotEmpty()): ?>
        <section class="vr-section pt-3">
            <div class="d-flex align-items-end justify-content-between mb-4 vr-animate-in">
                <div>
                    <h2 class="vr-section-title mb-1">You may also like</h2>
                    <p class="vr-section-sub mb-0">More from our collection</p>
                </div>
            </div>
            <div class="row g-4 vr-stagger">
                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-4 col-xl-3">
                        <?php echo $__env->make('storefront.partials.product-card', ['product' => $relatedProduct], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
</div>

<div class="modal fade vr-lightbox" id="vrLightbox" tabindex="-1" role="dialog" aria-modal="true" aria-label="<?php echo e($product->name); ?> image">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body text-center">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <img id="vrLightboxImg" src="" alt="<?php echo e($product->name); ?>">
            </div>
        </div>
    </div>
</div>

<div class="vr-mobile-bar d-lg-none" id="vrMobileBar">
    <div class="container d-flex align-items-center gap-2">
        <div class="vr-qty flex-shrink-0">
            <button type="button" class="qty-minus" data-step="-1" aria-label="Decrease quantity"><i class="bi bi-dash"></i></button>
            <input type="number" value="1" min="1" aria-label="Quantity" id="vrBarQty">
            <button type="button" data-step="1" aria-label="Increase quantity"><i class="bi bi-plus"></i></button>
        </div>
        <button type="button" class="btn btn-vr-outline flex-grow-1 js-bar-btn js-bar-add" <?php echo e($out ? 'disabled' : ''); ?>>
            <i class="bi bi-bag-plus me-1"></i> Add
        </button>
        <button type="button" class="btn btn-vr flex-grow-1 js-bar-btn js-bar-buy" <?php echo e($out ? 'disabled' : ''); ?>>
            <i class="bi bi-lightning-charge me-1"></i> Buy Now
        </button>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
        {
            "@type": "ListItem",
            "position": 1,
            "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('home'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        <?php if($category): ?>
        {
            "@type": "ListItem",
            "position": 2,
            "name": <?php echo json_encode($category->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('shop.category', $category->slug), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        {
            "@type": "ListItem",
            "position": 3,
            "name": <?php echo json_encode($product->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('product.show', $product), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }
        <?php else: ?>
        {
            "@type": "ListItem",
            "position": 2,
            "name": <?php echo json_encode($product->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('product.show', $product), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }
        <?php endif; ?>
    ]
}
</script>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Product",
    "name": <?php echo json_encode($product->name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "image": <?php echo json_encode($img ? image_url($img) : null, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    <?php if($product->description): ?>"description": <?php echo json_encode(strip_tags((string) $product->description), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,<?php endif; ?>
    <?php if($product->sku): ?>"sku": <?php echo json_encode($product->sku, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,<?php endif; ?>
    "brand": {
        "@type": "Brand",
        "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

    },
    "offers": {
        "@type": "Offer",
        "url": <?php echo json_encode(route('product.show', $product), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
        "priceCurrency": "INR",
        "price": <?php echo json_encode(number_format((float) $product->selling_price, 2, '.', ''), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
        "availability": <?php echo json_encode($out ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
        "itemCondition": "https://schema.org/NewCondition"
    }
    <?php if($product->review_count > 0): ?>,
    "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": <?php echo json_encode((string) $product->review_rating, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
        "reviewCount": <?php echo json_encode((string) $product->review_count, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

    }
    <?php endif; ?>
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
window.dataLayer.push(<?php echo json_encode($viewItemPayload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>);
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    var form = document.getElementById('addToCartForm');
    if (!form) return;

    if (document.getElementById('vrMobileBar') && window.innerWidth < 992) {
        document.body.classList.add('has-mobile-bar');
    }

    var buyNowInput = form.querySelector('input[name="buy_now"]');
    var mainQty = document.getElementById('vrBuyQty');
    var barQty = document.getElementById('vrBarQty');

    if (mainQty && barQty) {
        [mainQty, barQty].forEach(function (input) {
            input.addEventListener('input', function () {
                var other = input === mainQty ? barQty : mainQty;
                if (other) other.value = input.value;
            });
        });
    }

    document.querySelectorAll('.js-bar-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!form.checkValidity()) { form.reportValidity(); return; }
            if (barQty) form.querySelector('input[name="quantity"]').value = barQty.value;
            if (buyNowInput) buyNowInput.value = btn.classList.contains('js-bar-buy') ? '1' : '0';
            form.submit();
        });
    });

    var list = document.getElementById('vrVariantList');
    if (list) {
        function setButtonsDisabled(disabled) {
            form.querySelectorAll('button[type="submit"]').forEach(function (b) { b.disabled = disabled; });
            document.querySelectorAll('.js-bar-btn').forEach(function (b) { b.disabled = disabled; });
        }
        list.addEventListener('change', function (e) {
            var radio = e.target;
            if (!radio || radio.type !== 'radio') return;
            var label = radio.closest('.vr-variant-option');
            if (!label) return;
            list.querySelectorAll('.vr-variant-option').forEach(function (l) { l.classList.remove('is-selected'); });
            label.classList.add('is-selected');
            var nowEl = document.getElementById('vrNowPrice');
            var mrpEl = document.getElementById('vrMrpPrice');
            var instock = parseInt(label.dataset.instock || '1', 10) > 0;
            if (nowEl) nowEl.textContent = label.dataset.priceFmt;
            if (mrpEl) {
                if (parseFloat(label.dataset.mrp) > parseFloat(label.dataset.price)) {
                    mrpEl.textContent = label.dataset.mrpFmt;
                    mrpEl.style.display = '';
                } else {
                    mrpEl.style.display = 'none';
                }
            }
            setButtonsDisabled(!instock);
        });
    }
})();
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    if (window.innerWidth < 992) return;

    var container = document.getElementById('vrZoomContainer');
    var img = document.getElementById('vrMainImage');
    var lens = document.getElementById('vrZoomLens');
    var result = document.getElementById('vrZoomResult');
    if (!container || !img || !lens || !result || img.tagName !== 'IMG') return;

    var zoomFactor = 2.5;

    function activateZoom() {
        var src = img.src;
        if (!src) return;

        result.style.backgroundImage = 'url(' + src + ')';
        var bgW = img.offsetWidth * zoomFactor;
        var bgH = img.offsetHeight * zoomFactor;
        result.style.backgroundSize = bgW + 'px ' + bgH + 'px';

        lens.style.display = 'block';
        result.style.display = 'block';
    }

    function deactivateZoom() {
        lens.style.display = 'none';
        result.style.display = 'none';
    }

    function moveLens(e) {
        var rect = img.getBoundingClientRect();
        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;

        var lensW = lens.offsetWidth / 2;
        var lensH = lens.offsetHeight / 2;

        var left = x - lensW;
        var top = y - lensH;

        if (left < 0) left = 0;
        if (top < 0) top = 0;
        if (left > img.offsetWidth - lens.offsetWidth) left = img.offsetWidth - lens.offsetWidth;
        if (top > img.offsetHeight - lens.offsetHeight) top = img.offsetHeight - lens.offsetHeight;

        lens.style.left = left + 'px';
        lens.style.top = top + 'px';

        var ratioX = left / (img.offsetWidth - lens.offsetWidth);
        var ratioY = top / (img.offsetHeight - lens.offsetHeight);

        var bgW = img.offsetWidth * zoomFactor;
        var bgH = img.offsetHeight * zoomFactor;
        var bgX = -(ratioX * (bgW - result.offsetWidth));
        var bgY = -(ratioY * (bgH - result.offsetHeight));

        result.style.backgroundPosition = bgX + 'px ' + bgY + 'px';
    }

    container.addEventListener('mouseenter', activateZoom);
    container.addEventListener('mouseleave', deactivateZoom);
    container.addEventListener('mousemove', moveLens);
})();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/product.blade.php ENDPATH**/ ?>