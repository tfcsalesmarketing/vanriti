<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - <?php echo e(store_name()); ?> Admin</title>
    <meta name="theme-color" content="#263D25">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" sizes="any">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <?php
                $_adminLogo = setting('store_logo');
                if (! $_adminLogo) { foreach (['svg', 'png', 'webp', 'jpg'] as $_e) { if (file_exists(public_path('images/logo.' . $_e))) { $_adminLogo = 'images/logo.' . $_e; break; } } }
            ?>
            <div class="sidebar-brand">
                <?php if($_adminLogo): ?>
                    <img src="<?php echo e(asset($_adminLogo)); ?>" alt="<?php echo e(store_name()); ?>" class="brand-logo">
                <?php else: ?>
                    <span class="brand-text" style="color:var(--vanriti-green);"><?php echo e(strtoupper(store_name())); ?></span>
                <?php endif; ?>
            </div>
            <nav class="sidebar-nav">
                <?php echo $__env->make('admin.partials.sidebar-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </nav>
        </aside>

        <div class="admin-main">
            <header class="admin-topbar">
                <button class="btn btn-link d-lg-none text-dark" id="sidebarToggle" type="button">
                    <i class="bi bi-list fs-3"></i>
                </button>
                <div class="topbar-title">
                    <h5 class="mb-0 fw-bold" style="font-family:'Inter',sans-serif;"><?php echo $__env->yieldContent('title', 'Dashboard'); ?></h5>
                </div>
                <div class="ms-auto d-flex align-items-center gap-3">
                    <div class="dropdown">
                        <button class="btn btn-light-sm dropdown-toggle d-flex align-items-center gap-2" type="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="avatar-circle"><?php echo e(strtoupper(substr(auth('admin')->user()->name, 0, 1))); ?></span>
                            <span class="d-none d-sm-inline fw-semibold small"><?php echo e(auth('admin')->user()->name); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text small text-muted"><?php echo e(auth('admin')->user()->email); ?></span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right me-2"></i>Logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </header>

            <main class="admin-content">
                <?php if(session('success')): ?>
                    <div class="vr-toast-container" id="vrToasts">
                        <div class="vr-toast vr-toast-success show" role="alert">
                            <div class="vr-toast-icon"><i class="bi bi-check-circle-fill"></i></div>
                            <div class="vr-toast-body"><?php echo e(session('success')); ?></div>
                            <button type="button" class="vr-toast-close" data-bs-dismiss="alert" aria-label="Close">&times;</button>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="vr-toast-container" id="vrToasts">
                        <div class="vr-toast vr-toast-error show" role="alert">
                            <div class="vr-toast-icon"><i class="bi bi-exclamation-circle-fill"></i></div>
                            <div class="vr-toast-body"><?php echo e(session('error')); ?></div>
                            <button type="button" class="vr-toast-close" data-bs-dismiss="alert" aria-label="Close">&times;</button>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="vr-toast-container" id="vrToasts">
                        <div class="vr-toast vr-toast-error show" role="alert">
                            <div class="vr-toast-icon"><i class="bi bi-exclamation-circle-fill"></i></div>
                            <div class="vr-toast-body">
                                <strong>Please fix the following:</strong>
                                <ul class="mb-0 mt-1 ps-3">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <button type="button" class="vr-toast-close" data-bs-dismiss="alert" aria-label="Close">&times;</button>
                        </div>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <div class="admin-sidebar-backdrop" id="sidebarBackdrop"></div>

    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>