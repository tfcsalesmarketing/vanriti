<?php $__env->startSection('title', 'Media Library'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Media Library</h5>
        <small class="text-muted"><?php echo e($media->total()); ?> images total</small>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <h6 class="fw-bold mb-3"><i class="bi bi-upload me-1"></i>Upload Image</h6>
        <form method="POST" action="<?php echo e(route('admin.media.store')); ?>" enctype="multipart/form-data" class="row g-2 align-items-end">
            <?php echo csrf_field(); ?>
            <div class="col-md-4">
                <label for="name" class="form-label small text-muted">Image Name</label>
                <input type="text" name="name" id="name" class="form-control form-control-sm" placeholder="e.g. Hero banner flower" maxlength="150" required>
            </div>
            <div class="col-md-5">
                <label for="image" class="form-label small text-muted">Image File</label>
                <input type="file" name="image" id="image" class="form-control form-control-sm" accept="image/jpeg,image/png,image/webp,image/gif" required>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-sm btn-primary w-100"><i class="bi bi-cloud-arrow-up me-1"></i>Upload</button>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="card-body pb-0">
        <form method="GET" action="<?php echo e(route('admin.media.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search by image name..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.media.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">Clear</a>
            </div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Preview</th>
                    <th>Name</th>
                    <th>File</th>
                    <th>Type</th>
                    <th>Size</th>
                    <th>Uploaded By</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <img src="<?php echo e($item->url); ?>" alt="<?php echo e($item->name); ?>" class="img-thumb" loading="lazy">
                        </td>
                        <td class="fw-semibold small"><?php echo e($item->name); ?></td>
                        <td class="small text-muted text-truncate" style="max-width:220px;" title="<?php echo e($item->file_name); ?>"><?php echo e($item->file_name); ?></td>
                        <td class="small"><?php echo e($item->mime_type); ?></td>
                        <td class="small"><?php echo e($item->size_label); ?></td>
                        <td class="small text-muted">
                            <?php echo e($item->admin?->name ?? '—'); ?>

                            <div class="text-muted"><?php echo e($item->created_at?->format('d M Y')); ?></div>
                        </td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <button type="button"
                                        class="btn btn-sm btn-outline-success copy-link"
                                        data-url="<?php echo e($item->url); ?>"
                                        title="Copy link">
                                    <i class="bi bi-link-45deg me-1"></i><span class="copy-label">Copy Link</span>
                                </button>
                                <form method="POST" action="<?php echo e(route('admin.media.destroy', $item)); ?>" onsubmit="return confirm('Delete this image? This cannot be undone.')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No images found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($media->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    document.querySelectorAll('.copy-link').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var url = btn.getAttribute('data-url');
            var label = btn.querySelector('.copy-label');

            function done() {
                if (label) {
                    label.textContent = 'Copied!';
                    setTimeout(function () { label.textContent = 'Copy Link'; }, 1500);
                }
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(done, done);
                return;
            }

            var textarea = document.createElement('textarea');
            textarea.value = url;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(textarea);
            done();
        });
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/media/index.blade.php ENDPATH**/ ?>