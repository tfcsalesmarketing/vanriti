<?php $__env->startSection('title', 'Forgot Password'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-auth-shell">
    <div class="card vr-auth-card">
        <div class="card-body p-4 p-md-5">
            <div class="text-center mb-4">
                <div class="vr-kicker justify-content-center mb-2">PURE BY NATURE</div>
                <div class="vr-brand mb-1"><?php echo e(strtoupper(store_name())); ?></div>
                <p class="text-muted small mb-0">We'll email you a password reset link.</p>
            </div>

            <form method="POST" action="<?php echo e(route('password.email')); ?>" id="vrForgotForm" novalidate>
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label class="form-label small fw-semibold">Email</label>
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control form-control-lg" autocomplete="email" autofocus>
                    <div class="invalid-feedback"></div>
                </div>
                <button type="submit" class="btn btn-vr w-100 py-2">Send Reset Link</button>
            </form>

            <p class="text-center small mt-4 mb-0">
                <a href="<?php echo e(route('login')); ?>" class="vr-link-underline">Back to login</a>
            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var form = document.getElementById('vrForgotForm');
        if (form && typeof window.vrLiveServerValidation === 'function') {
            window.vrLiveServerValidation(form, '<?php echo e(route('auth.validate')); ?>', {
                context: 'forgot',
                live: ['email']
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/auth/forgot-password.blade.php ENDPATH**/ ?>