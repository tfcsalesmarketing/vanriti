<?php
    use App\Services\CartService;
    use App\Services\WishlistService;
    $cartService = app(CartService::class);
    $wishlistService = app(WishlistService::class);
    $cartCount = $cartService->count();
    $wishCount = $wishlistService->count();
    $navCategories = App\Models\Category::with(['children'])->whereNull('parent_id')->where('status', 'active')->orderBy('sort_order')->get();

    $logo = setting('store_logo');
    if (! $logo) {
        foreach (['svg', 'png', 'webp', 'jpg'] as $ext) {
            if (file_exists(public_path('images/logo.' . $ext))) {
                $logo = 'images/logo.' . $ext;
                break;
            }
        }
    }
?>

<div class="vr-announce">
    Free shipping above <?php echo e(setting('free_shipping_threshold', 499)); ?> &middot; <strong>WELCOME10</strong> for 10% off your first order
</div>

<nav class="vr-navbar" id="vrNavbar">
    <div class="container">
        <div class="row align-items-center py-3 g-0">
            
            <div class="col-12 d-flex d-lg-none align-items-center justify-content-between px-2">
                <button type="button" class="vr-mobile-header-btn" data-bs-toggle="offcanvas" data-bs-target="#vrCategoryPanel" aria-controls="vrCategoryPanel" aria-label="Open Categories">
                    <i class="ri-menu-line"></i>
                </button>

                <a class="vr-brand mx-auto text-center" href="<?php echo e(route('home')); ?>">
                    <?php if($logo): ?>
                        <img src="<?php echo e(image_url($logo, 'favicon.ico')); ?>" alt="<?php echo e(store_name()); ?>" height="50" class="vr-logo">
                    <?php else: ?>
                        <?php echo e(strtoupper(store_name())); ?><span class="dot">.</span>
                    <?php endif; ?>
                </a>

                <?php if(auth()->guard('web')->check()): ?>
                    <button type="button" class="vr-mobile-header-btn <?php echo e(request()->routeIs('account.*') ? 'active' : ''); ?>" data-bs-toggle="offcanvas" data-bs-target="#vrUserPanel" aria-controls="vrUserPanel" aria-label="Account">
                        <i class="ri-user-3-line"></i>
                    </button>
                <?php else: ?>
                    <button type="button" class="vr-mobile-header-btn <?php echo e(request()->routeIs('login') ? 'active' : ''); ?>" data-bs-toggle="offcanvas" data-bs-target="#vrUserPanel" aria-controls="vrUserPanel" aria-label="Sign In">
                        <i class="ri-user-3-line"></i>
                    </button>
                <?php endif; ?>
            </div>

            
            <div class="col-lg-3 d-none d-lg-flex align-items-center">
                <a class="vr-brand me-lg-0" href="<?php echo e(route('home')); ?>">
                    <?php if($logo): ?>
                        <img src="<?php echo e(image_url($logo, 'favicon.ico')); ?>" alt="<?php echo e(store_name()); ?>" height="55" class="vr-logo">
                    <?php else: ?>
                        <?php echo e(strtoupper(store_name())); ?><span class="dot">.</span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="col-lg-6 d-none d-lg-flex align-items-center justify-content-center gap-3">
                <ul class="nav align-items-center mb-0">
                    <li class="nav-item">
                        <a class="vr-nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <?php $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item dropdown">
                            <a class="vr-nav-link dropdown-toggle <?php echo e(request('category', '') == $cat->slug ? 'active' : ''); ?>"
                               href="<?php echo e(route('shop.category', $cat->slug)); ?>"
                               <?php if($cat->children->count()): ?> data-bs-toggle="dropdown" <?php endif; ?>>
                                <?php echo e($cat->name); ?>

                            </a>
                            <?php if($cat->children->count()): ?>
                                <ul class="dropdown-menu shadow">
                                    <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item small" href="<?php echo e(route('shop.category', $child->slug)); ?>"><?php echo e($child->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="vr-nav-link" href="<?php echo e(route('contact.index')); ?>">Contact</a>
                    </li>
                </ul>
            </div>

            <div class="col-lg-3 d-none d-lg-flex align-items-center justify-content-end gap-3">
                <?php if(auth()->guard('web')->check()): ?>
                    <a href="<?php echo e(route('account.dashboard')); ?>" class="vr-icon-link" title="Account" aria-label="Account">
                        <i class="bi bi-person"></i>
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="vr-icon-link" title="Sign in" aria-label="Sign in">
                        <i class="bi bi-person"></i>
                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('wishlist.index')); ?>" class="vr-icon-link" title="Wishlist" aria-label="Wishlist">
                    <i class="bi bi-heart"></i>
                    <?php if($wishCount > 0): ?>
                        <span class="vr-badge"><?php echo e($wishCount); ?></span>
                    <?php endif; ?>
                </a>
                <a href="<?php echo e(route('cart.index')); ?>" class="vr-icon-link position-relative" title="Cart" aria-label="Cart">
                    <i class="bi bi-bag"></i>
                    <?php if($cartCount > 0): ?>
                        <span class="vr-badge js-cart-count"><?php echo e($cartCount); ?></span>
                    <?php else: ?>
                        <span class="vr-badge js-cart-count d-none">0</span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </div>
</nav>

<?php $__env->startPush('styles'); ?>
<style>
.vr-navbar{transition:box-shadow .3s ease,background .3s ease,backdrop-filter .3s ease}
</style>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/partials/header.blade.php ENDPATH**/ ?>