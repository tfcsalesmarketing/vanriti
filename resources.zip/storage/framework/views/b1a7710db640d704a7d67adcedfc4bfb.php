<?php $__env->startSection('title', 'Reset Password'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-auth-shell">
    <div class="card vr-auth-card">
        <div class="card-body p-4 p-md-5">
            <div class="text-center mb-4">
                <div class="vr-kicker justify-content-center mb-2">PURE BY NATURE</div>
                <div class="vr-brand mb-1"><?php echo e(strtoupper(store_name())); ?></div>
                <p class="text-muted small mb-0">Choose a new password.</p>
            </div>

            <form method="POST" action="<?php echo e(route('password.store')); ?>" id="vrResetForm" novalidate>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Email</label>
                    <input type="email" name="email" value="<?php echo e(old('email', request('email'))); ?>" class="form-control form-control-lg" autocomplete="email" autofocus>
                    <div class="invalid-feedback"></div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">New Password</label>
                    <div class="password-wrap">
                        <input type="password" name="password" class="form-control form-control-lg" autocomplete="new-password">
                        <button type="button" class="password-toggle-btn" tabindex="-1" aria-label="Show password">
                            <i class="ri-eye-line"></i>
                        </button>
                    </div>
                    <div class="invalid-feedback"></div>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-semibold">Confirm New Password</label>
                    <div class="password-wrap">
                        <input type="password" name="password_confirmation" class="form-control form-control-lg" autocomplete="new-password">
                        <button type="button" class="password-toggle-btn" tabindex="-1" aria-label="Show password">
                            <i class="ri-eye-line"></i>
                        </button>
                    </div>
                    <div class="invalid-feedback"></div>
                </div>
                <button type="submit" class="btn btn-vr w-100 py-2">Reset Password</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var form = document.getElementById('vrResetForm');
        if (form && typeof window.vrLiveServerValidation === 'function') {
            window.vrLiveServerValidation(form, '<?php echo e(route('auth.validate')); ?>', {
                context: 'reset',
                live: ['password', 'password_confirmation']
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/auth/reset-password.blade.php ENDPATH**/ ?>