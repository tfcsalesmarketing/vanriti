<?php
    use App\Services\CartService;
    $cartService = app(CartService::class);
    $cartCount = $cartService->count();

    $barCategories = App\Models\Category::with(['children'])
        ->whereNull('parent_id')
        ->where('status', 'active')
        ->orderBy('sort_order')
        ->get();

    $logo = setting('store_logo');
    if (! $logo) {
        foreach (['svg', 'png', 'webp', 'jpg'] as $ext) {
            if (file_exists(public_path('images/logo.' . $ext))) {
                $logo = 'images/logo.' . $ext;
                break;
            }
        }
    }
?>


<div class="offcanvas offcanvas-start vr-app-drawer" tabindex="-1" id="vrMenuPanel" aria-labelledby="vrMenuPanelLabel">
    <div class="offcanvas-header vr-drawer-header">
        <a class="vr-drawer-brand" href="<?php echo e(route('home')); ?>">
            <?php if($logo): ?>
                <img src="<?php echo e(image_url($logo, 'favicon.ico')); ?>" alt="<?php echo e(store_name()); ?>" height="36" class="vr-logo">
            <?php else: ?>
                <span class="vr-brand-name"><?php echo e(store_name()); ?></span>
            <?php endif; ?>
            <span class="vr-drawer-badge">Official Store</span>
        </a>
        <button type="button" class="vr-drawer-close" data-bs-dismiss="offcanvas" aria-label="Close">
            <i class="ri-close-line"></i>
        </button>
    </div>

    <div class="offcanvas-body vr-drawer-body">
        
        <div class="vr-drawer-section">
            <div class="vr-drawer-section-title">Discover</div>
            <ul class="list-unstyled vr-drawer-nav">
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-home-5-line"></i></div>
                        <span>Home</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('shop.index')); ?>" class="<?php echo e(request()->routeIs('shop.index') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-shopping-bag-3-line"></i></div>
                        <span>Shop All Products</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('blog.index')); ?>" class="<?php echo e(request()->routeIs('blog.*') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-book-read-line"></i></div>
                        <span>Journal & Stories</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('track')); ?>" class="<?php echo e(request()->routeIs('track') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-truck-line"></i></div>
                        <span>Track Order</span>
                        <span class="vr-badge-pill ms-auto me-2">Live</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
            </ul>
        </div>

        
        <div class="vr-drawer-section">
            <div class="vr-drawer-section-title">Customer Care</div>
            <ul class="list-unstyled vr-drawer-nav">
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('contact.index')); ?>" class="<?php echo e(request()->routeIs('contact.*') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-customer-service-2-line"></i></div>
                        <span>Contact Support</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('info.about')); ?>" class="<?php echo e(request()->routeIs('info.about') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-information-line"></i></div>
                        <span>About Our Brand</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
                <?php if(App\Models\Faq::where('status', 'active')->exists()): ?>
                    <li class="vr-drawer-item">
                        <a href="<?php echo e(route('faq.index')); ?>" class="<?php echo e(request()->routeIs('faq.*') ? 'active' : ''); ?>">
                            <div class="vr-nav-icon"><i class="ri-questionnaire-line"></i></div>
                            <span>FAQs & Help</span>
                            <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        
        <div class="vr-drawer-section">
            <div class="vr-drawer-section-title">Store Policies</div>
            <ul class="list-unstyled vr-drawer-nav">
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('info.shipping')); ?>" class="<?php echo e(request()->routeIs('info.shipping') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-box-3-line"></i></div>
                        <span>Shipping & Delivery</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('info.privacy')); ?>" class="<?php echo e(request()->routeIs('info.privacy') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-shield-user-line"></i></div>
                        <span>Privacy Policy</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
                <li class="vr-drawer-item">
                    <a href="<?php echo e(route('info.terms')); ?>" class="<?php echo e(request()->routeIs('info.terms') ? 'active' : ''); ?>">
                        <div class="vr-nav-icon"><i class="ri-file-list-3-line"></i></div>
                        <span>Terms & Conditions</span>
                        <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="vr-drawer-footer">
        <?php if(auth()->guard('web')->check()): ?>
            <a href="<?php echo e(route('account.dashboard')); ?>" class="btn vr-app-btn w-100">
                <i class="ri-user-3-fill me-2"></i> My Account Dashboard
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn vr-app-btn w-100">
                <i class="ri-login-box-line me-2"></i> Sign In to Account
            </a>
        <?php endif; ?>
    </div>
</div>


<div class="offcanvas offcanvas-start vr-app-drawer" tabindex="-1" id="vrCategoryPanel" aria-labelledby="vrCategoryPanelLabel">
    <div class="offcanvas-header vr-drawer-header">
        <div class="d-flex align-items-center gap-2">
            <div class="vr-header-icon-box"><i class="ri-leaf-fill"></i></div>
            <div>
                <h6 class="offcanvas-title fw-bold mb-0" id="vrCategoryPanelLabel">Explore Categories</h6>
                <span class="small text-muted">Browse items by category</span>
            </div>
        </div>
        <button type="button" class="vr-drawer-close" data-bs-dismiss="offcanvas" aria-label="Close">
            <i class="ri-close-line"></i>
        </button>
    </div>

    <div class="offcanvas-body vr-drawer-body">
        
        <div class="vr-category-chips mb-3">
            <a href="<?php echo e(route('shop.index')); ?>" class="vr-chip active">All Products</a>
            <?php $__currentLoopData = $barCategories->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shop.category', $topCat->slug)); ?>" class="vr-chip"><?php echo e($topCat->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="accordion vr-cat-accordion" id="vrCatPanelAcc">
            <?php $__currentLoopData = $barCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="vr-cat-card mb-2">
                    <?php if($cat->children->count()): ?>
                        <div class="vr-cat-header" id="headingCat<?php echo e($cat->id); ?>">
                            <button class="vr-cat-toggle collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#vrCatPanel<?php echo e($cat->id); ?>" aria-expanded="false" aria-controls="vrCatPanel<?php echo e($cat->id); ?>">
                                <div class="vr-cat-icon"><i class="ri-price-tag-3-fill"></i></div>
                                <span class="vr-cat-title"><?php echo e($cat->name); ?></span>
                                <span class="vr-cat-badge"><?php echo e($cat->children->count()); ?> subcategories</span>
                                <i class="ri-arrow-down-s-line vr-cat-chevron ms-2"></i>
                            </button>
                        </div>
                        <div id="vrCatPanel<?php echo e($cat->id); ?>" class="collapse" aria-labelledby="headingCat<?php echo e($cat->id); ?>" data-bs-parent="#vrCatPanelAcc">
                            <div class="vr-cat-body">
                                <a class="vr-subcat-link vr-subcat-all" href="<?php echo e(route('shop.category', $cat->slug)); ?>">
                                    <span>All <?php echo e($cat->name); ?></span>
                                    <i class="ri-arrow-right-line"></i>
                                </a>
                                <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="vr-subcat-link" href="<?php echo e(route('shop.category', $child->slug)); ?>">
                                        <span><?php echo e($child->name); ?></span>
                                        <i class="ri-arrow-right-s-line"></i>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <a class="vr-cat-direct" href="<?php echo e(route('shop.category', $cat->slug)); ?>">
                            <div class="vr-cat-icon"><i class="ri-price-tag-3-line"></i></div>
                            <span class="vr-cat-title"><?php echo e($cat->name); ?></span>
                            <i class="ri-arrow-right-s-line vr-nav-arrow"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<div class="offcanvas offcanvas-start vr-app-drawer" tabindex="-1" id="vrUserPanel" aria-labelledby="vrUserPanelLabel">
    <div class="offcanvas-header vr-drawer-header">
        <div class="d-flex align-items-center gap-2">
            <div class="vr-header-icon-box"><i class="ri-user-3-fill"></i></div>
            <div>
                <h6 class="offcanvas-title fw-bold mb-0" id="vrUserPanelLabel">My Account</h6>
                <span class="small text-muted">Personal hub</span>
            </div>
        </div>
        <button type="button" class="vr-drawer-close" data-bs-dismiss="offcanvas" aria-label="Close">
            <i class="ri-close-line"></i>
        </button>
    </div>

    <div class="offcanvas-body vr-drawer-body d-flex flex-column">
        <?php if(auth()->guard('web')->check()): ?>
            
            <div class="vr-profile-hero mb-3">
                <div class="vr-hero-avatar-wrap">
                    <div class="vr-hero-avatar"><?php echo e(strtoupper(substr(auth('web')->user()->name, 0, 1))); ?></div>
                    <span class="vr-avatar-status"></span>
                </div>
                <div class="vr-hero-info">
                    <div class="vr-hero-name"><?php echo e(auth('web')->user()->name); ?></div>
                    <div class="vr-hero-email"><?php echo e(auth('web')->user()->email); ?></div>
                    <div class="vr-hero-tag"><i class="ri-checkbox-circle-fill me-1"></i> Verified Member</div>
                </div>
            </div>

            
            <div class="vr-user-grid mb-3">
                <a href="<?php echo e(route('account.dashboard')); ?>" class="vr-grid-tile">
                    <div class="vr-tile-icon"><i class="ri-dashboard-3-line"></i></div>
                    <div class="vr-tile-label">Dashboard</div>
                </a>
                <a href="<?php echo e(route('account.orders')); ?>" class="vr-grid-tile">
                    <div class="vr-tile-icon"><i class="ri-shopping-basket-2-line"></i></div>
                    <div class="vr-tile-label">My Orders</div>
                </a>
                <a href="<?php echo e(route('account.addresses')); ?>" class="vr-grid-tile">
                    <div class="vr-tile-icon"><i class="ri-map-pin-2-line"></i></div>
                    <div class="vr-tile-label">Addresses</div>
                </a>
                <a href="<?php echo e(route('wishlist.index')); ?>" class="vr-grid-tile">
                    <div class="vr-tile-icon"><i class="ri-heart-3-line"></i></div>
                    <div class="vr-tile-label">Wishlist</div>
                </a>
            </div>

            <div class="mt-auto pt-3">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn vr-app-outline-btn w-100">
                        <i class="ri-logout-box-r-line me-2"></i> Log Out
                    </button>
                </form>
            </div>
        <?php else: ?>
            
            <div class="vr-guest-card text-center my-auto">
                <div class="vr-guest-icon-box mb-3">
                    <i class="ri-user-smile-line"></i>
                </div>
                <h5 class="fw-bold mb-1">Welcome to Store</h5>
                <p class="text-muted small mb-4">Sign in to track orders, manage addresses, and save items to your wishlist.</p>
                <a href="<?php echo e(route('login')); ?>" class="btn vr-app-btn w-100 mb-2">
                    <i class="ri-login-box-line me-2"></i> Sign In
                </a>
                <a href="<?php echo e(route('register')); ?>" class="btn vr-app-outline-btn w-100">
                    <i class="ri-user-add-line me-2"></i> Create New Account
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>


<div class="vr-mobile-dock d-lg-none" id="vrBottomBar">
    <div class="vr-dock-container">
        
        <button type="button" class="vr-dock-item" data-bs-toggle="offcanvas" data-bs-target="#vrMenuPanel" aria-controls="vrMenuPanel" aria-label="Menu">
            <div class="vr-dock-icon">
                <i class="ri-menu-line"></i>
            </div>
            <span class="vr-dock-label">Menu</span>
        </button>

        
        <button type="button" class="vr-dock-item" data-bs-toggle="offcanvas" data-bs-target="#vrCategoryPanel" aria-controls="vrCategoryPanel" aria-label="Category">
            <div class="vr-dock-icon">
                <i class="ri-leaf-line"></i>
            </div>
            <span class="vr-dock-label">Category</span>
        </button>

        
        <a href="<?php echo e(route('home')); ?>" class="vr-dock-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" aria-label="Home">
            <div class="vr-dock-icon">
                <i class="<?php echo e(request()->routeIs('home') ? 'ri-home-5-fill' : 'ri-home-5-line'); ?>"></i>
            </div>
            <span class="vr-dock-label">Home</span>
        </a>

        
        <?php if(auth()->guard('web')->check()): ?>
            <button type="button" class="vr-dock-item <?php echo e(request()->routeIs('account.*') ? 'active' : ''); ?>" data-bs-toggle="offcanvas" data-bs-target="#vrUserPanel" aria-controls="vrUserPanel" aria-label="Account">
                <div class="vr-dock-icon">
                    <i class="<?php echo e(request()->routeIs('account.*') ? 'ri-user-3-fill' : 'ri-user-3-line'); ?>"></i>
                </div>
                <span class="vr-dock-label">Account</span>
            </button>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="vr-dock-item <?php echo e(request()->routeIs('login') ? 'active' : ''); ?>" aria-label="Sign in">
                <div class="vr-dock-icon">
                    <i class="<?php echo e(request()->routeIs('login') ? 'ri-user-3-fill' : 'ri-user-3-line'); ?>"></i>
                </div>
                <span class="vr-dock-label">Sign In</span>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->guard('web')->check()): ?>
            <a href="<?php echo e(route('cart.index')); ?>" class="vr-dock-item <?php echo e(request()->routeIs('cart.*') ? 'active' : ''); ?>" aria-label="Cart">
                <div class="vr-dock-icon position-relative">
                    <i class="<?php echo e(request()->routeIs('cart.*') ? 'ri-shopping-bag-3-fill' : 'ri-shopping-bag-3-line'); ?>"></i>
                    <?php if($cartCount > 0): ?>
                        <span class="vr-dock-badge js-cart-count"><?php echo e($cartCount); ?></span>
                    <?php else: ?>
                        <span class="vr-dock-badge js-cart-count d-none">0</span>
                    <?php endif; ?>
                </div>
                <span class="vr-dock-label">Cart</span>
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="vr-dock-item" aria-label="Cart">
                <div class="vr-dock-icon position-relative">
                    <i class="ri-shopping-bag-3-line"></i>
                </div>
                <span class="vr-dock-label">Cart</span>
            </a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/partials/bottom-bar.blade.php ENDPATH**/ ?>