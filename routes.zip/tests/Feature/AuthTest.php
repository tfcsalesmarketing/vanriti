<?php

namespace Tests\Feature;

use App\Models\User;
use App\Notifications\WelcomeNotification;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Mail\Events\MessageSending;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
use Tests\TestCase;

class AuthTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_sees_login_page(): void
    {
        $response = $this->get(route('login'));
        $response->assertOk();
    }

    public function test_user_can_register_and_is_redirected_to_dashboard(): void
    {
        $response = $this->post(route('register.submit'), [
            'name' => 'Jane Doe',
            'email' => 'jane@example.com',
            'phone' => '9876543210',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect(route('account.dashboard'));

        $this->assertDatabaseHas('users', [
            'email' => 'jane@example.com',
            'status' => 'active',
        ]);

        $this->assertAuthenticatedAs(User::where('email', 'jane@example.com')->firstOrFail(), 'web');
    }

    public function test_registration_stores_a_canonical_mobile(): void
    {
        $this->post(route('register.submit'), [
            'name' => 'Asha Rao',
            'email' => 'asha@example.com',
            'phone' => '+91 91234 56780',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ])->assertRedirect(route('account.dashboard'));

        $this->assertDatabaseHas('users', [
            'email' => 'asha@example.com',
            'phone' => '9123456780',
        ]);
    }

    public function test_password_login_accepts_plus_91_for_a_ten_digit_account(): void
    {
        $user = User::factory()->create([
            'phone' => '9876543210',
            'password' => 'secret123',
        ]);

        $this->post(route('login.submit'), [
            'login' => '+91 98765 43210',
            'password' => 'secret123',
        ])->assertRedirect(route('account.dashboard'));

        $this->assertAuthenticatedAs($user, 'web');
    }

    public function test_signed_email_verification_works_while_signed_in(): void
    {
        $user = User::factory()->create([
            'email_verified_at' => null,
        ]);

        $url = \Illuminate\Support\Facades\URL::temporarySignedRoute(
            'verification.verify',
            now()->addHour(),
            ['user' => $user->id],
        );

        $this->actingAs($user)->get($url)->assertRedirect(route('account.dashboard'));
        $this->assertNotNull($user->fresh()->email_verified_at);
    }

    public function test_profile_phone_change_requires_a_verified_otp(): void
    {
        $user = User::factory()->create([
            'phone' => '9876543210',
            'name' => 'Keep Name',
        ]);

        $this->actingAs($user)->post(route('account.profile.update'), [
            'name' => 'Keep Name',
            'phone' => '9123456780',
        ])->assertSessionHasErrors('phone');

        $this->assertSame('9876543210', $user->fresh()->phone);
    }

    public function test_registration_password_confirmation_mismatch_fails(): void
    {
        $response = $this->post(route('register.submit'), [
            'name' => 'Jane Doe',
            'email' => 'jane@example.com',
            'phone' => '9876543210',
            'password' => 'password123',
            'password_confirmation' => 'different',
        ]);

        $response->assertSessionHasErrors('password');
        $this->assertDatabaseMissing('users', ['email' => 'jane@example.com']);
    }

    public function test_user_can_login_successfully(): void
    {
        $user = User::factory()->create(['password' => 'secret123']);

        $response = $this->post(route('login.submit'), [
            'login'    => $user->email,
            'password' => 'secret123',
        ]);

        $response->assertRedirect(route('account.dashboard'));
        $this->assertAuthenticatedAs($user, 'web');
    }

    public function test_login_fails_with_wrong_credentials(): void
    {
        $user = User::factory()->create();

        $response = $this->post(route('login.submit'), [
            'login'    => $user->email,
            'password' => 'wrong-password',
        ]);

        // Generic message under the login field prevents email-enumeration via
        // distinct error keys.
        $response->assertSessionHasErrors('login');
        $this->assertGuest('web');
    }

    public function test_login_fails_when_email_does_not_exist(): void
    {
        $response = $this->post(route('login.submit'), [
            'login'    => 'nobody@example.com',
            'password' => 'whatever123',
        ]);

        $response->assertSessionHasErrors('login');
        $this->assertGuest('web');
    }

    public function test_user_can_logout(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user, 'web');
        $response = $this->post(route('logout'));

        $response->assertRedirect(route('home'));
        $this->assertGuest('web');
    }

    public function test_welcome_notification_is_sent_on_registration(): void
    {
        Notification::fake();

        $this->post(route('register.submit'), [
            'name' => 'Jane Doe',
            'email' => 'welcome-notify@example.com',
            'phone' => '9876543210',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ])->assertRedirect(route('account.dashboard'));

        Notification::assertSentTo(
            User::where('email', 'welcome-notify@example.com')->firstOrFail(),
            WelcomeNotification::class
        );
    }

    public function test_registration_succeeds_when_welcome_email_fails_to_send(): void
    {
        Event::listen(MessageSending::class, fn () => throw new \RuntimeException('smtp unreachable'));
        Log::spy();

        $response = $this->post(route('register.submit'), [
            'name' => 'Jane Doe',
            'email' => 'mailfail@example.com',
            'phone' => '9876543210',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect(route('account.dashboard'));
        $this->assertAuthenticated('web');
        $this->assertDatabaseHas('users', ['email' => 'mailfail@example.com']);
        Log::shouldHaveReceived('warning')->once();
    }

    public function test_registration_welcome_email_uses_branded_template(): void
    {
        $user = User::factory()->make([
            'name' => 'Aarav Mehta',
            'email' => 'welcome@example.com',
        ]);

        $notification = new WelcomeNotification;
        $mail = $notification->toMail($user);
        $html = $mail->render();

        $this->assertSame('Welcome to VANRITI', $mail->subject);
        $this->assertStringContainsString('Hi Aarav,', $html);
        $this->assertStringContainsString('Start Shopping', $html);
        $this->assertStringContainsString('welcome@example.com', $html);
        $this->assertStringContainsString('eduse-uploadedfiles.s3.ap-south-1.amazonaws.com', $html);
    }

    public function test_welcome_email_links_respect_configured_app_url(): void
    {
        config(['app.url' => 'https://vanriti.com']);
        \Illuminate\Support\Facades\URL::forceRootUrl('https://vanriti.com');
        \Illuminate\Support\Facades\URL::forceScheme('https');

        $user = User::factory()->create([
            'name' => 'Aarav Mehta',
            'email' => 'welcome@example.com',
            'email_verified_at' => null,
        ]);

        $notification = new WelcomeNotification;
        $mail = $notification->toMail($user);

        $this->assertStringStartsWith('https://vanriti.com/', $mail->viewData['loginUrl']);
        $this->assertStringStartsWith('https://vanriti.com/', $mail->viewData['shopUrl']);
        $this->assertStringStartsWith('https://vanriti.com/', $mail->viewData['verifyUrl']);
    }

    public function test_phone_only_registration_succeeds_without_welcome_email(): void
    {
        Notification::fake();
        Log::spy();

        $response = $this->post(route('register.submit'), [
            'name' => 'Phone Only',
            'phone' => '9876543210',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect(route('account.dashboard'));
        $this->assertAuthenticated('web');
        $this->assertDatabaseHas('users', ['phone' => '9876543210', 'email' => null]);

        Notification::assertNothingSent();
        Log::shouldNotHaveReceived('warning');
    }

    public function test_authenticated_user_is_redirected_from_login(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user, 'web')
            ->get(route('login'))
            ->assertRedirect(route('account.dashboard'));
    }

    public function test_authenticated_user_is_redirected_from_register(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user, 'web')
            ->get(route('register'))
            ->assertRedirect(route('account.dashboard'));
    }

    public function test_guest_is_redirected_to_login_when_accessing_protected_account_route(): void
    {
        $this->get(route('account.dashboard'))
            ->assertRedirect(route('login'));
    }

    public function test_account_nav_shows_logout_button_for_authenticated_user(): void
    {
        $user = User::factory()->create(['password' => 'secret123']);

        $this->actingAs($user, 'web')
            ->get(route('account.dashboard'))
            ->assertOk()
            ->assertSee(route('logout'))
            ->assertSee('Log Out');
    }

    public function test_passwords_are_hashed(): void
    {
        User::create([
            'name' => 'Hash Test',
            'email' => 'hash@example.com',
            'password' => 'Secret#2026',
            'status' => 'active',
        ]);

        $user = User::where('email', 'hash@example.com')->firstOrFail();
        $this->assertNotSame('Secret#2026', $user->password);
        $this->assertTrue(Hash::check('Secret#2026', $user->password));
    }
}
