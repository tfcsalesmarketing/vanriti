<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductVariant;
use App\Services\ActivityLogger;
use App\Services\InventoryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ProductController extends Controller
{
    public function __construct(
        protected ActivityLogger $logger,
        protected InventoryService $inventoryService,
    ) {}

    public function index(Request $request): View
    {
        $query = Product::query()
            ->with(['categories', 'images'])
            ->withCount('images');

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('sku', 'like', "%{$search}%");
            });
        }

        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }

        if ($categoryId = $request->input('category_id')) {
            $query->whereHas('categories', fn ($q) => $q->where('categories.id', $categoryId));
        }

        $products = $query->latest()->paginate(25)->withQueryString();
        $categories = Category::orderBy('name')->get();

        $kpis = [
            'total' => Product::count(),
            'active' => Product::where('status', 'active')->count(),
            'low_stock' => Product::where('status', 'active')->where('stock', '>', 0)->whereColumn('stock', '<=', 'low_stock_threshold')->count(),
            'out_of_stock' => Product::where('status', 'active')->where('stock', '<=', 0)->count(),
            'featured' => Product::where('is_featured', true)->count(),
        ];

        return view('admin.products.index', compact('products', 'categories', 'kpis'));
    }

    public function create(): View
    {
        $categories = Category::orderBy('name')->get();

        return view('admin.products.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'nullable|unique:products,slug',
            'sku' => 'required|string|max:255|unique:products,sku',
            'status' => 'required|in:draft,active,inactive',
            'short_description' => 'nullable|string|max:500',
            'description' => 'nullable|string',
            'highlights' => 'nullable|string',
            'ingredients' => 'nullable|string',
            'benefits' => 'nullable|string',
            'how_to_use' => 'nullable|string',
            'directions' => 'nullable|string',
            'warnings' => 'nullable|string',
            'precautions' => 'nullable|string',
            'disclaimer' => 'nullable|string',
            'unit' => 'nullable|string',
            'weight' => 'nullable|numeric|min:0',
            'mrp' => 'required|numeric|gte:selling_price',
            'selling_price' => 'required|numeric|min:0.01',
            'gst_rate' => 'nullable|numeric|min:0|max:100',
            'stock' => 'nullable|integer|min:0',
            'low_stock_threshold' => 'nullable|integer|min:0',
            'hsn_code' => 'nullable|string',
            'manufacturer' => 'nullable|string',
            'manufacturer_address' => 'nullable|string',
            'country_of_origin' => 'nullable|string',
            'shelf_life' => 'nullable|string',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string',
            'search_keywords' => 'nullable|string',
            'video_url' => 'nullable|string|max:500',
            'video' => 'nullable|file|mimes:mp4,webm,ogg,ogv,mov,3gp|max:51200',
            'is_featured' => 'nullable',
            'is_bestseller' => 'nullable',
            'is_new_arrival' => 'nullable',
            'category_ids' => 'required|array',
            'category_ids.*' => 'exists:categories,id',
            'primary_category_id' => 'nullable|exists:categories,id',
        ]);

        unset($validated['slug']);
        $validated['slug'] = Product::uniqueSlugFromName($validated['name']);
        $validated['discount_percent'] = ($validated['mrp'] > $validated['selling_price'])
            ? round((($validated['mrp'] - $validated['selling_price']) / $validated['mrp']) * 100, 1)
            : 0;
        $validated['is_featured'] = $request->boolean('is_featured');
        $validated['is_bestseller'] = $request->boolean('is_bestseller');
        $validated['is_new_arrival'] = $request->boolean('is_new_arrival');
        $validated['video_url'] = $this->resolveVideoUrl($request, $validated['video_url'] ?? null);
        unset($validated['video']);

        $categoryIds = $validated['category_ids'];
        $primaryCategoryId = $validated['primary_category_id'] ?? $categoryIds[0];
        unset($validated['category_ids'], $validated['primary_category_id']);

        $product = Product::create($validated);

        foreach ($categoryIds as $catId) {
            DB::table('product_category')->insert([
                'product_id' => $product->id,
                'category_id' => $catId,
                'is_primary' => ($catId == $primaryCategoryId),
            ]);
        }

        $this->logger->productCreated(auth('admin')->user(), $product);

        return redirect()->route('admin.products.index')->with('success', 'Product created.');
    }

    public function show(Product $product): View
    {
        $product->load(['categories', 'images', 'variants']);
        $inventory = DB::table('inventories')
            ->where('stockable_type', Product::class)
            ->where('stockable_id', $product->id)
            ->first();

        return view('admin.products.show', compact('product', 'inventory'));
    }

    public function edit(Product $product): View
    {
        $product->load('categories');
        $categories = Category::orderBy('name')->get();

        return view('admin.products.edit', compact('product', 'categories'));
    }

    public function update(Request $request, Product $product)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'nullable|unique:products,slug,'.$product->id,
            'sku' => 'required|string|max:255|unique:products,sku,'.$product->id,
            'status' => 'required|in:draft,active,inactive',
            'short_description' => 'nullable|string|max:500',
            'description' => 'nullable|string',
            'highlights' => 'nullable|string',
            'ingredients' => 'nullable|string',
            'benefits' => 'nullable|string',
            'how_to_use' => 'nullable|string',
            'directions' => 'nullable|string',
            'warnings' => 'nullable|string',
            'precautions' => 'nullable|string',
            'disclaimer' => 'nullable|string',
            'unit' => 'nullable|string',
            'weight' => 'nullable|numeric|min:0',
            'mrp' => 'required|numeric|gte:selling_price',
            'selling_price' => 'required|numeric|min:0.01',
            'gst_rate' => 'nullable|numeric|min:0|max:100',
            'stock' => 'nullable|integer|min:0',
            'low_stock_threshold' => 'nullable|integer|min:0',
            'hsn_code' => 'nullable|string',
            'manufacturer' => 'nullable|string',
            'manufacturer_address' => 'nullable|string',
            'country_of_origin' => 'nullable|string',
            'shelf_life' => 'nullable|string',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string',
            'search_keywords' => 'nullable|string',
            'video_url' => 'nullable|string|max:500',
            'video' => 'nullable|file|mimes:mp4,webm,ogg,ogv,mov,3gp|max:51200',
            'is_featured' => 'nullable',
            'is_bestseller' => 'nullable',
            'is_new_arrival' => 'nullable',
            'category_ids' => 'required|array',
            'category_ids.*' => 'exists:categories,id',
            'primary_category_id' => 'nullable|exists:categories,id',
        ]);

        $old = $product->only([
            'name', 'slug', 'sku', 'status',
            'mrp', 'selling_price', 'discount_percent', 'gst_rate', 'stock',
            'is_featured', 'is_bestseller', 'is_new_arrival',
        ]);

        unset($validated['slug']);
        $validated['slug'] = Product::uniqueSlugFromName($validated['name'], $product->id);
        $validated['discount_percent'] = ($validated['mrp'] > $validated['selling_price'])
            ? round((($validated['mrp'] - $validated['selling_price']) / $validated['mrp']) * 100, 1)
            : 0;
        $validated['is_featured'] = $request->boolean('is_featured');
        $validated['is_bestseller'] = $request->boolean('is_bestseller');
        $validated['is_new_arrival'] = $request->boolean('is_new_arrival');

        $categoryIds = $validated['category_ids'];
        $primaryCategoryId = $validated['primary_category_id'] ?? $categoryIds[0];
        unset($validated['category_ids'], $validated['primary_category_id']);

        $previousVideo = $product->video_url;
        $validated['video_url'] = $this->resolveVideoUrl($request, $validated['video_url'] ?? null);
        unset($validated['video']);
        if ($validated['video_url'] !== $previousVideo) {
            $this->deleteStoredVideo($previousVideo);
        }

        $product->update($validated);

        DB::table('product_category')->where('product_id', $product->id)->delete();
        foreach ($categoryIds as $catId) {
            DB::table('product_category')->insert([
                'product_id' => $product->id,
                'category_id' => $catId,
                'is_primary' => ($catId == $primaryCategoryId),
            ]);
        }

        $new = $product->only(array_keys($old));
        $this->logger->productUpdated(auth('admin')->user(), $product, $old, $new);

        return redirect()->route('admin.products.index')->with('success', 'Product updated.');
    }

    public function destroy(Product $product)
    {
        $this->logger->productDeleted(auth('admin')->user(), $product);
        $product->delete();

        return redirect()->route('admin.products.index')->with('success', 'Product deleted.');
    }

    /**
     * Decide the stored video reference: an uploaded file wins over a pasted
     * link, the remove flag clears everything, otherwise the link is kept.
     */
    private function resolveVideoUrl(Request $request, ?string $link): ?string
    {
        if ($request->hasFile('video')) {
            $stored = $request->file('video')->store('products/videos', 's3');

            return $stored !== false ? $stored : null;
        }

        if ($request->boolean('remove_video')) {
            return null;
        }

        $link = trim((string) $link);

        return $link === '' ? null : $link;
    }

    private function deleteStoredVideo(?string $path): void
    {
        if (blank($path) || str_starts_with($path, 'http') || str_starts_with($path, 'storage/')) {
            return;
        }

        if (Storage::disk('s3')->exists($path)) {
            Storage::disk('s3')->delete($path);
        }
    }

    public function storeImage(Request $request, Product $product)
    {
        $validated = $request->validate([
            'image' => 'required|image|mimes:jpeg,png,webp|max:4096',
            'alt_text' => 'nullable|string|max:255',
            'type' => 'nullable|in:main,gallery,thumbnail,whatsapp',
        ]);

        $type = $validated['type'] ?? 'gallery';
        $file = $request->file('image');
        $path = $file->store('products', 's3');
        $imagePath = $path;

        if ($type === 'main') {
            ProductImage::where('product_id', $product->id)
                ->where('type', 'main')
                ->update(['type' => 'gallery']);
        } elseif ($type === 'whatsapp') {
            ProductImage::where('product_id', $product->id)
                ->where('type', 'whatsapp')
                ->update(['type' => 'gallery']);
        }

        $maxSort = ProductImage::where('product_id', $product->id)->max('sort_order') ?? 0;

        ProductImage::create([
            'product_id' => $product->id,
            'image_path' => $imagePath,
            'alt_text' => $validated['alt_text'] ?? null,
            'type' => $type,
            'sort_order' => $maxSort + 1,
        ]);

        $this->logger->log('product_image_added', $product, 'Image added to "'.$product->name.'".');

        return redirect()->back()->with('success', 'Image uploaded.');
    }

    public function destroyImage(ProductImage $image)
    {
        $product = $image->product;

        if ($image->image_path && ! str_starts_with($image->image_path, 'http') && Storage::disk('s3')->exists($image->image_path)) {
            Storage::disk('s3')->delete($image->image_path);
        }

        $image->delete();

        return redirect()->back()->with('success', 'Image deleted.');
    }

    public function sortImage(Request $request, ProductImage $image)
    {
        $request->validate([
            'sort_order' => 'required|integer|min:0',
        ]);

        $image->update(['sort_order' => $request->input('sort_order')]);

        return redirect()->back()->with('success', 'Sort order updated.');
    }

    public function storeVariant(Request $request, Product $product)
    {
        $validated = $request->validate([
            'name' => 'nullable|string|max:255',
            'sku' => 'nullable|unique:product_variants,sku',
            'mrp' => 'required|numeric',
            'selling_price' => 'required|numeric|lte:mrp',
            'stock' => 'nullable|integer|min:0',
            'gst_rate' => 'nullable|numeric|min:0|max:100',
            'status' => 'nullable|in:active,inactive',
        ]);

        $validated['product_id'] = $product->id;
        $validated['stock'] = $validated['stock'] ?? 0;
        $validated['status'] = $validated['status'] ?? 'active';

        ProductVariant::create($validated);

        return redirect()->back()->with('success', 'Variant added.');
    }

    public function updateVariant(Request $request, ProductVariant $variant)
    {
        $validated = $request->validate([
            'name' => 'nullable|string|max:255',
            'sku' => 'nullable|unique:product_variants,sku,'.$variant->id,
            'mrp' => 'required|numeric',
            'selling_price' => 'required|numeric|lte:mrp',
            'stock' => 'nullable|integer|min:0',
            'gst_rate' => 'nullable|numeric|min:0|max:100',
            'status' => 'nullable|in:active,inactive',
        ]);

        $variant->update($validated);

        return redirect()->back()->with('success', 'Variant updated.');
    }

    public function destroyVariant(ProductVariant $variant)
    {
        $variant->delete();

        return redirect()->back()->with('success', 'Variant deleted.');
    }

    public function import(Request $request)
    {
        $request->validate([
            'import_file' => 'required|file|mimes:csv,txt|max:3072',
        ]);

        $file = $request->file('import_file');
        $imported = 0;

        $handle = fopen('php://temp', 'r+');
        fwrite($handle, file_get_contents($file->getRealPath()));
        rewind($handle);

        $header = fgetcsv($handle);
        $errors = [];
        $line = 1;

        if (! is_array($header) || ! in_array('name', $header, true) || ! in_array('sku', $header, true)) {
            fclose($handle);

            return redirect()->back()->with('error', 'The CSV must include name and sku columns.');
        }

        while (($row = fgetcsv($handle)) !== false) {
            $line++;

            if (count($row) !== count($header)) {
                $errors[] = "Line {$line}: column count does not match the header.";

                continue;
            }

            $data = array_combine($header, $row);

            if (! is_array($data) || trim((string) ($data['name'] ?? '')) === '') {
                $errors[] = "Line {$line}: name is required.";

                continue;
            }

            $sku = strtoupper(trim((string) ($data['sku'] ?? '')));

            if ($sku === '') {
                $errors[] = "Line {$line}: sku is required.";

                continue;
            }

            $status = strtolower(trim((string) ($data['status'] ?? 'draft')));

            if (! in_array($status, ['draft', 'active', 'inactive'], true)) {
                $errors[] = "Line {$line}: status must be draft, active, or inactive.";

                continue;
            }

            foreach (['mrp', 'selling_price', 'gst_rate'] as $money) {
                $raw = trim((string) ($data[$money] ?? '0'));

                if ($raw === '') {
                    $raw = '0';
                }

                if (! is_numeric($raw) || (float) $raw < 0) {
                    $errors[] = "Line {$line}: {$money} must be a number that is zero or greater.";

                    continue 2;
                }

                $data[$money] = $raw;
            }

            $stock = trim((string) ($data['stock'] ?? '0'));

            if ($stock === '') {
                $stock = '0';
            }

            if (! ctype_digit($stock)) {
                $errors[] = "Line {$line}: stock must be a whole number.";

                continue;
            }

            $existing = Product::query()->where('sku', $sku)->first();
            $slug = Product::uniqueSlugFromName((string) $data['name'], $existing?->id);

            if ($slug === '') {
                $errors[] = "Line {$line}: name does not produce a URL slug.";

                continue;
            }

            Product::updateOrCreate(
                ['sku' => $sku],
                [
                    'name' => trim((string) $data['name']),
                    'slug' => $slug,
                    'mrp' => $data['mrp'],
                    'selling_price' => $data['selling_price'],
                    'gst_rate' => $data['gst_rate'],
                    'stock' => (int) $stock,
                    'status' => $status,
                ]
            );

            if (! empty($data['category_slug'])) {
                $category = Category::where('slug', $data['category_slug'])->first();
                if ($category) {
                    $product = Product::where('sku', $sku)->first();
                    if ($product) {
                        $product->categories()->syncWithoutDetaching([$category->id]);
                    }
                }
            }

            $imported++;
        }

        fclose($handle);

        $redirect = redirect()->back()->with('success', $imported.' products imported.');

        if ($errors !== []) {
            $redirect->with('error', implode(' ', array_slice($errors, 0, 8)));
        }

        return $redirect;
    }

    public function export()
    {
        $products = Product::select([
            'name', 'slug', 'sku', 'mrp', 'selling_price', 'gst_rate',
            'stock', 'status', 'is_featured', 'barcode',
        ])->get();

        $filename = 'products_export_'.now()->format('Y-m-d_His').'.csv';

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        return response()->streamDownload(function () use ($products) {
            $handle = fopen('php://output', 'w');

            fputcsv($handle, ['name', 'slug', 'sku', 'mrp', 'selling_price', 'gst_rate', 'stock', 'status', 'is_featured', 'barcode']);

            foreach ($products as $product) {
                fputcsv($handle, [
                    $product->name,
                    $product->slug,
                    $product->sku,
                    $product->mrp,
                    $product->selling_price,
                    $product->gst_rate,
                    $product->stock,
                    $product->status,
                    $product->is_featured ? '1' : '0',
                    $product->barcode,
                ]);
            }

            fclose($handle);
        }, $filename, $headers);
    }

    public function updateStock(Request $request, Product $product)
    {
        // Support direct stock level adjustment (e.g. from quick inline modal)
        if ($request->has('stock') && ! $request->has('type')) {
            $data = $request->validate([
                'stock' => 'required|integer|min:0',
                'reason' => 'nullable|string|max:255',
            ]);

            $diff = (int) $data['stock'] - (int) $product->stock;
            if ($diff !== 0) {
                $type = $diff > 0 ? 'purchase' : 'adjustment';
                $old = $product->stock;

                $this->inventoryService->adjust(
                    $type,
                    $product,
                    $diff,
                    $data['reason'] ?? 'Manual stock update from catalog',
                    auth('admin')->user()
                );

                $this->logger->stockChanged(auth('admin')->user(), $product, $old, $product->fresh()->stock, $data['reason'] ?? null);
            }

            if ($request->expectsJson()) {
                return response()->json([
                    'success' => true,
                    'stock' => $product->fresh()->stock,
                    'is_out_of_stock' => $product->fresh()->isOutOfStock(),
                    'is_low_stock' => $product->fresh()->isLowStock(),
                ]);
            }

            return redirect()->back()->with('success', "Stock updated to {$product->fresh()->stock}.");
        }

        $validated = $request->validate([
            'type' => 'required|in:sale,purchase,adjustment,return,reversal',
            'quantity' => 'required|integer|min:1',
            'reason' => 'required_if:type,adjustment|nullable|string|max:500',
        ]);

        $change = in_array($validated['type'], ['purchase', 'return', 'reversal'])
            ? $validated['quantity']
            : -$validated['quantity'];

        $old = $product->stock;

        $this->inventoryService->adjust(
            $validated['type'],
            $product,
            $change,
            $validated['reason'] ?? $validated['type'].' adjustment',
            auth('admin')->user(),
        );

        $this->logger->stockChanged(auth('admin')->user(), $product, $old, $product->fresh()->stock, $validated['reason'] ?? null);

        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'stock' => $product->fresh()->stock,
            ]);
        }

        return redirect()->back()->with('success', 'Stock updated.');
    }

    public function toggleStatus(Product $product)
    {
        $newStatus = match ($product->status) {
            'active' => 'inactive',
            'inactive' => 'active',
            default => 'active',
        };

        $product->update(['status' => $newStatus]);

        if (request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'status' => $newStatus,
                'label' => ucfirst($newStatus),
            ]);
        }

        return redirect()->back()->with('success', "Product status changed to {$newStatus}.");
    }

    public function toggleFeatured(Product $product)
    {
        $product->update(['is_featured' => ! $product->is_featured]);

        if (request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'is_featured' => (bool) $product->is_featured,
            ]);
        }

        return redirect()->back()->with('success', 'Featured status updated.');
    }
}
