<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Consent\ConsentService;
use App\Services\CartService;
use App\Services\WhatsAppOtpService;
use App\Services\WishlistService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\View\View;

class OtpController extends Controller
{
    protected array $purposes = ['login', 'register', 'reset_password', 'change_phone', 'fast_checkout'];

    public function __construct(
        protected WhatsAppOtpService $whatsapp,
        protected CartService $cartService,
        protected WishlistService $wishlistService,
        protected ConsentService $consentService,
    ) {}

    // ── Send OTP ───────────────────────────────────────────────────────────────
    public function send(Request $request): RedirectResponse|JsonResponse
    {
        $data = $request->validate([
            'phone' => ['required', 'string', 'max:15', 'regex:/^(?:\+91[\s-]?|0)?[6-9][0-9][\s-]?[0-9]{3}[\s-]?[0-9]{5}$/'],
            'purpose' => ['required', 'string', 'in:'.implode(',', $this->purposes)],
            'email' => ['nullable', 'email', 'max:255'],
        ], [
            'phone.required' => 'Please enter your mobile number.',
            'phone.regex' => 'Please enter a valid 10-digit mobile number.',
            'purpose.in' => 'Invalid verification purpose.',
            'email.email' => 'Please enter a valid email address.',
        ]);

        $phone = canonical_phone($data['phone']);

        if ($phone === null) {
            $invalid = 'Please enter a valid 10-digit mobile number.';

            if ($request->wantsJson()) {
                return response()->json(['result' => '0', 'message' => $invalid], 422);
            }

            return back()->with('error', $invalid)->withInput();
        }

        if ($data['purpose'] === 'change_phone' && ! auth('web')->check()) {
            abort(403);
        }

        if ($data['purpose'] !== 'change_phone' && auth('web')->check()) {
            $busy = 'You are already signed in.';

            if ($request->wantsJson()) {
                return response()->json(['result' => '0', 'message' => $busy], 409);
            }

            return back()->with('error', $busy);
        }

        if ($data['purpose'] === 'change_phone') {
            $owner = user_by_phone($phone);

            if ($owner && $owner->id !== auth('web')->id()) {
                $taken = 'This mobile number is already registered.';

                if ($request->wantsJson()) {
                    return response()->json(['result' => '0', 'message' => $taken], 422);
                }

                return back()->with('error', $taken)->withInput();
            }
        }

        // Registration must reject an already-registered number here, before an
        // OTP is dispatched. The register page submits /otp/send instead of the
        // form (its live-validation submit handler is bypassed by the OTP step),
        // so without this the customer only discovered the duplicate number
        // after verifying a code they had no reason to doubt.
        //
        // Unlike the "login" purpose above, this deliberately discloses that the
        // number exists. That asymmetry is intentional: an account that cannot
        // register a number must be told why, and the same message is already
        // returned by AuthController::validateFields and AuthController::register.
        //
        // An optional duplicate email is caught at the same step (and bound to
        // its own field) so a registered email can never be hidden behind an
        // OTP dance either.
        if ($data['purpose'] === 'register') {
            $email = ! empty($data['email'] ?? null)
                ? Str::lower(trim((string) $data['email']))
                : null;

            if (user_by_phone($phone)) {
                $message = 'This mobile number is already registered.';
                $field = 'phone';
            } elseif ($email !== null && \App\Models\User::query()->whereRaw('LOWER(email) = ?', [$email])->exists()) {
                $message = 'This email is already registered.';
                $field = 'email';
            }

            if (isset($message)) {
                if ($request->wantsJson()) {
                    return response()->json([
                        'result' => '0',
                        'message' => $message,
                        'errors' => [$field => [$message]],
                    ], 422);
                }

                return back()->with('error', $message)->withInput();
            }
        }

        // Per-phone daily budget, independent of the IP throttle: a single
        // number must never be flooded with OTP deliveries. Bound both valid
        // and lookup-only sends so enumeration attempts cost rate-limit slots.
        $phoneKey = 'otp-send-phone:'.$phone;
        $dailyLimit = max(3, (int) setting('whatsapp_otp_daily_limit', 10));
        if (RateLimiter::tooManyAttempts($phoneKey, $dailyLimit)) {
            $throttled = 'Too many OTP requests for this number. Please try again later.';

            if ($request->wantsJson()) {
                return response()->json(['result' => '0', 'message' => $throttled], 429);
            }

            return back()->with('error', $throttled)->withInput();
        }

        RateLimiter::hit($phoneKey, 86400);

        // For the login flow an unknown number must be answered exactly like a
        // known one (same status code, same message shape) so the endpoint can
        // never be used to enumerate registered numbers. No code is dispatched
        // for an account that does not exist.
        if ($data['purpose'] === 'login') {
            $loginUser = user_by_phone($phone);

            if (! $loginUser) {
                $cover = 'If that number is registered, we will send a code to your WhatsApp.';

                if ($request->wantsJson()) {
                    return response()->json([
                        'result' => '1',
                        'message' => $cover,
                        'data' => ['phone' => $phone],
                    ], 202);
                }

                return back()->with('success', $cover)->withInput();
            }
        }

        // Cooldown: reuse the in-flight OTP instead of re-hitting WhatsApp.
        $remaining = $this->whatsapp->cooldownRemaining($phone, $data['purpose']);

        if ($remaining > 0) {
            if ($request->wantsJson()) {
                return response()->json(['result' => '0', 'message' => 'Please wait '.$remaining.' seconds before requesting a new code.'], 429);
            }

            return back()->with('error', 'Please wait '.$remaining.' seconds before requesting a new code.')->withInput();
        }

        $result = $this->whatsapp->sendOtp($phone, $data['purpose']);

        if (($result['result'] ?? '0') === '1') {
            session()->put('otp_pending_phone', $phone);

            if ($request->wantsJson()) {
                return response()->json($result);
            }

            return back()->with('success', 'OTP sent to your WhatsApp.');
        }

        if ($request->wantsJson()) {
            return response()->json($result, 422);
        }

        return back()->with('error', $result['message'] ?? 'OTP could not be sent.')->withInput();
    }

    // ── Verify OTP ─────────────────────────────────────────────────────────────
    public function verify(Request $request): RedirectResponse|JsonResponse
    {
        $data = $request->validate([
            'phone' => ['required', 'string', 'max:15'],
            'code' => ['required', 'string', 'digits:6'],
            'purpose' => ['required', 'string', 'in:'.implode(',', $this->purposes)],
        ], [
            'phone.required' => 'Please enter your mobile number.',
            'code.required' => 'Please enter the code sent to your WhatsApp.',
            'code.digits' => 'The code must be exactly 6 digits.',
            'purpose.in' => 'Invalid verification purpose.',
        ]);

        $phone = canonical_phone($data['phone']);

        if ($phone === null) {
            $invalid = 'Please enter a valid 10-digit mobile number.';

            if ($request->wantsJson()) {
                return response()->json(['result' => '0', 'message' => $invalid], 422);
            }

            return back()->with('error', $invalid)->withInput();
        }

        if ($data['purpose'] === 'change_phone' && ! auth('web')->check()) {
            abort(403);
        }

        $result = $this->whatsapp->verifyOtp($phone, $data['code'], $data['purpose']);

        if (($result['result'] ?? '0') !== '1') {
            if ($request->wantsJson()) {
                return response()->json($result, 422);
            }

            return back()->with('error', $result['message'] ?? 'The code you entered is invalid.')->withInput();
        }

        if ($data['purpose'] === 'change_phone') {
            session()->put('otp_verified_phone', $phone);
            session()->forget('otp_pending_phone');

            if ($request->wantsJson()) {
                return response()->json($result);
            }

            return back()->with('success', 'Phone verified. You can now save your profile.');
        }

        // ── fast_checkout: 1-tap WhatsApp checkout & login (auto-provisions new user if not found) ──
        if ($data['purpose'] === 'fast_checkout') {
            $user = user_by_phone($phone);
            $isNewUser = false;

            if (! $user) {
                $isNewUser = true;
                $user = \App\Models\User::create([
                    'name' => 'Customer '.substr($phone, -4),
                    'phone' => $phone,
                    'phone_verified_at' => now(),
                    'last_login_at' => now(),
                    'status' => 'active',
                    'password' => \Illuminate\Support\Facades\Hash::make(\Illuminate\Support\Str::random(32)),
                ]);
            }

            if ($user->status !== 'active') {
                $suspended = 'Your account has been suspended. Contact support.';
                if ($request->wantsJson()) {
                    return response()->json(['result' => '0', 'message' => $suspended], 403);
                }
                return back()->with('error', $suspended);
            }

            if ($user->phone !== $phone && ! \App\Models\User::query()->where('phone', $phone)->whereKeyNot($user->id)->exists()) {
                $user->phone = $phone;
            }

            $user->update([
                'phone' => $user->phone,
                'last_login_at' => now(),
                'phone_verified_at' => $user->phone_verified_at ?? now(),
            ]);

            auth('web')->login($user);
            session()->regenerate();
            session()->regenerateToken();

            $this->cartService->mergeGuestCartIntoUser($user);
            $this->wishlistService->mergeGuestIntoUser($user);
            $this->consentService->mergeAnonymousIntoUser($user);

            $rawName = trim((string) $user->name);
            $hasPlaceholderName = empty($rawName)
                || (bool) preg_match('/^Customer(\s+\d+)?$/i', $rawName)
                || strcasecmp($rawName, 'Guest') === 0
                || strcasecmp($rawName, 'User') === 0;
            $needsName = $isNewUser || $hasPlaceholderName;

            $result['csrf_token'] = csrf_token();
            $result['redirect'] = route('checkout.index');
            $result['needs_name'] = $needsName;
            $result['is_new'] = $isNewUser;

            if ($request->wantsJson()) {
                return response()->json($result);
            }

            return redirect()->intended(route('checkout.index'));
        }

        // ── login: log the user in (negates the password step) ────────────────
        if ($data['purpose'] === 'login') {
            $user = user_by_phone($phone);

            if (! $user) {
                $notFound = 'Unable to sign you in. Please try again or register a new account.';
                if ($request->wantsJson()) {
                    return response()->json(['result' => '0', 'message' => $notFound], 422);
                }

                return back()->with('error', $notFound);
            }

            if ($user->status !== 'active') {
                $suspended = 'Your account has been suspended. Contact support.';
                if ($request->wantsJson()) {
                    return response()->json(['result' => '0', 'message' => $suspended], 403);
                }

                return back()->with('error', $suspended);
            }

            if ($user->phone !== $phone && ! \App\Models\User::query()->where('phone', $phone)->whereKeyNot($user->id)->exists()) {
                $user->phone = $phone;
            }

            $user->update([
                'phone' => $user->phone,
                'last_login_at' => now(),
                'phone_verified_at' => $user->phone_verified_at ?? now(),
            ]);

            auth('web')->login($user);
            session()->regenerate();
            session()->regenerateToken();

            $this->cartService->mergeGuestCartIntoUser($user);
            $this->wishlistService->mergeGuestIntoUser($user);
            $this->consentService->mergeAnonymousIntoUser($user);

            // OTP login regenerates the session, so the existing CSRF token is now
            // stale. Ship a fresh token back so the storefront modal can replay the
            // pending add-to-cart / wishlist POST without hitting a 419 mismatch.
            $result['csrf_token'] = csrf_token();
            $rawName = trim((string) $user->name);
            $hasPlaceholderName = empty($rawName)
                || (bool) preg_match('/^Customer(\s+\d+)?$/i', $rawName)
                || strcasecmp($rawName, 'Guest') === 0
                || strcasecmp($rawName, 'User') === 0;
            $result['needs_name'] = $hasPlaceholderName;

            $hasCart = $this->cartService->count() > 0;
            $result['redirect'] = $hasCart ? route('checkout.index') : route('account.dashboard');

            if ($request->wantsJson()) {
                return response()->json($result);
            }

            return redirect()->intended(route('account.dashboard'));
        }

        // ── register: remember the verified phone for the next step ───────────
        if ($data['purpose'] === 'register') {
            session()->put('otp_verified_phone', $phone);
            session()->forget('otp_pending_phone');

            if ($request->wantsJson()) {
                return response()->json($result);
            }

            return back()->with('success', 'Phone verified. You may now complete registration.');
        }

        // ── reset_password: send the user to the password reset form ---------
        $user = user_by_phone($phone);

        if (! $user) {
            return back()->with('error', 'Unable to reset the password for this number. Please try again.');
        }

        $token = \Illuminate\Support\Facades\Password::broker('users')->createToken($user);

        return redirect()->route('password.reset', ['token' => $token])->withInput(['phone' => $phone]);
    }

    // ── Save Name (Progressive Onboarding Step 2) ──────────────────────────────
    public function saveName(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'min:2', 'max:100'],
        ], [
            'name.required' => 'Please enter your name.',
            'name.min' => 'Name must be at least 2 characters.',
            'name.max' => 'Name cannot exceed 100 characters.',
        ]);

        /** @var \App\Models\User|null $user */
        $user = auth('web')->user();

        if (! $user) {
            return response()->json([
                'result' => '0',
                'message' => 'Please sign in first.',
            ], 401);
        }

        $cleanName = trim(strip_tags((string) $data['name']));
        $user->update(['name' => $cleanName]);

        // Send WhatsApp welcome message now that we have customer's real name
        try {
            if ($this->whatsapp->isEnabled() && setting('whatsapp_auto_welcome_enabled', false) && ! empty($user->phone)) {
                $firstName = explode(' ', $cleanName)[0] ?? $cleanName;
                $this->whatsapp->sendWelcome($user->phone, $firstName);
            }
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('WhatsApp welcome could not be delivered after saving name.', [
                'phone' => $user->phone,
                'error' => $e->getMessage(),
            ]);
        }

        return response()->json([
            'result' => '1',
            'message' => 'Name saved successfully.',
            'name' => $cleanName,
            'csrf_token' => csrf_token(),
            'redirect' => $this->cartService->count() > 0 ? route('checkout.index') : route('account.dashboard'),
        ]);
    }
}
