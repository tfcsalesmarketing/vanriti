<?php $__env->startSection('title', 'Banners'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Banners</h5>
        <small class="text-muted"><?php echo e($banners->total()); ?> banners total</small>
    </div>
    <a href="<?php echo e(route('admin.banners.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Banner</a>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Link</th>
                    <th>Position</th>
                    <th>Type</th>
                    <th>Sort</th>
                    <th>Status</th>
                    <th>Dates</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($banner->image): ?>
                                <img src="<?php echo e(image_url($banner->image)); ?>" alt="" class="img-thumb">
                            <?php else: ?>
                                <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                    <i class="bi bi-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="small">
                            <?php if($banner->link): ?>
                                <a href="<?php echo e($banner->link); ?>" target="_blank" class="text-truncate d-inline-block" style="max-width:200px;"><?php echo e($banner->link); ?></a>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <td class="small"><?php echo e($banner->position); ?></td>
                        <td>
                            <span class="badge badge-soft-primary"><?php echo e(ucfirst($banner->type)); ?></span>
                        </td>
                        <td class="small"><?php echo e($banner->sort_order); ?></td>
                        <td>
                            <span class="badge <?php echo e($banner->status === 'active' ? 'badge-soft-success' : 'badge-soft-secondary'); ?>"><?php echo e(ucfirst($banner->status)); ?></span>
                        </td>
                        <td class="small text-muted">
                            <?php if($banner->starts_at || $banner->expires_at): ?>
                                <div><?php echo e($banner->starts_at?->format('d M Y') ?: '—'); ?></div>
                                <div><?php echo e($banner->expires_at?->format('d M Y') ?: '—'); ?></div>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <a href="<?php echo e(route('admin.banners.edit', $banner)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <form method="POST" action="<?php echo e(route('admin.banners.destroy', $banner)); ?>" data-confirm="Delete this banner?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No banners found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($banners->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/banners/index.blade.php ENDPATH**/ ?>