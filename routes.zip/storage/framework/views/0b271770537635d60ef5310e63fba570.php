<?php $__env->startSection('title', 'Policies'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-section" style="background:var(--vr-cream);">
    <div class="container">
        <nav class="vr-breadcrumb">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <span class="mx-1">/</span>
            <span>Return Policy</span>
        </nav>
    </div>
</div>

<div class="vr-section">
    <div class="container">
        <h1 class="mb-4" style="font-weight:800;color:var(--vr-green-dark);">Return &amp; Refund Policy</h1>

        <div style="line-height:1.8;font-size:1.05rem;">
            <?php echo nl2br(e($content)); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\policies.blade.php ENDPATH**/ ?>