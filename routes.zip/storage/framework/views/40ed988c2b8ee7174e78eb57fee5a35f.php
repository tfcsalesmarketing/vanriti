<?php $__env->startSection('title', 'My Orders'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row g-4">
        <div class="col-lg-3">
            <?php echo $__env->make('storefront.account.partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <div class="col-lg-9">
            <h5 class="fw-bold mb-3">My Orders</h5>
            <?php if($orders->isEmpty()): ?>
                <div class="vr-empty bg-white border rounded-4">
                    <i class="bi bi-bag"></i>
                    <p class="mt-2">You haven't placed any orders yet.</p>
                    <a href="<?php echo e(route('shop.index')); ?>" class="btn btn-vr btn-sm">Shop Now</a>
                </div>
            <?php else: ?>
                <?php echo $__env->make('storefront.account.partials.order-table', ['orders' => $orders], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="mt-3">
                    <?php echo e($orders->links('storefront.partials.pagination')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\account\orders.blade.php ENDPATH**/ ?>