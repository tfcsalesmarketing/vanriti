<?php $__env->startSection('title', 'Product Catalogue | TFC Sales & Marketing'); ?>

<?php $__env->startSection('content'); ?>
<section class="tfc-page-header py-5" style="background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%); border-bottom: 1px solid rgba(0,0,0,0.06);">
    <div class="container text-center py-2">
        <span class="badge bg-warning text-dark fw-bold mb-2 px-3 py-1.5" style="font-size: 0.8rem; letter-spacing: 0.5px;">CURATED FORMULATIONS</span>
        <h1 class="display-5 fw-bold text-dark mb-2">Our Product Catalogue</h1>
        <p class="text-muted lead mb-0">High-Performance Botanical Care &bull; Authentic Quality</p>
    </div>
</section>

<section class="py-5">
    <div class="container">
        
        <div class="card p-3 mb-5 border-0 shadow-sm rounded-3">
            <form method="GET" action="<?php echo e(tfc_route('products')); ?>" class="row g-3 align-items-center">
                <div class="col-12 col-md-5">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-start-0" placeholder="Search by name, herbal active, or benefit..." value="<?php echo e(request('search')); ?>">
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <select name="category" class="form-select">
                        <option value="">All Wellness Categories</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->slug); ?>" <?php echo e(request('category') === $cat->slug ? 'selected' : ''); ?>>
                                <?php echo e($cat->name); ?> (<?php echo e($cat->products_count); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-12 col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-tfc-primary w-100">Filter</button>
                    <a href="<?php echo e(tfc_route('products')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>

        
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="card tfc-card h-100">
                        <div class="position-relative overflow-hidden">
                            <?php
                                $img = $product->getPrimaryImage()?->image_path;
                            ?>
                            <a href="<?php echo e(tfc_route('products.show', $product->slug)); ?>">
                                <?php if($img): ?>
                                    <img src="<?php echo e(image_url($img)); ?>" alt="<?php echo e($product->name); ?>" class="tfc-product-img">
                                <?php else: ?>
                                    <div class="tfc-product-img bg-light d-flex align-items-center justify-content-center text-muted">
                                        <i class="bi bi-image fs-1"></i>
                                    </div>
                                <?php endif; ?>
                            </a>
                            <?php if($product->discountPercent() > 0): ?>
                                <span class="badge bg-danger position-absolute top-0 start-0 m-2 px-2 py-1">
                                    <?php echo e(round($product->discountPercent())); ?>% OFF
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="card-body d-flex flex-column p-4">
                            <div class="small text-muted mb-1">
                                <?php echo e($product->primaryCategory()?->name ?? 'Ayurvedic Wellness'); ?>

                            </div>
                            <h6 class="fw-bold mb-2">
                                <a href="<?php echo e(tfc_route('products.show', $product->slug)); ?>" class="text-dark text-decoration-none">
                                    <?php echo e($product->name); ?>

                                </a>
                            </h6>
                            <div class="mt-auto pt-3 border-top d-flex align-items-center justify-content-between">
                                <div>
                                    <span class="tfc-price"><?php echo e(format_price($product->selling_price)); ?></span>
                                    <?php if($product->mrp && $product->mrp > $product->selling_price): ?>
                                        <span class="tfc-mrp"><?php echo e(format_price($product->mrp)); ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo e(tfc_route('products.show', $product->slug)); ?>" class="btn btn-sm btn-tfc-primary">
                                    Details
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center py-5">
                    <div class="py-5">
                        <i class="bi bi-box-seam text-muted fs-1 mb-3 d-block"></i>
                        <h5 class="fw-bold text-dark">No products found</h5>
                        <p class="text-muted">Try adjusting your search criteria or explore another category.</p>
                        <a href="<?php echo e(tfc_route('products')); ?>" class="btn btn-tfc-navy mt-2">View All Products</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php if($products->hasPages()): ?>
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tfc.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/tfc/products/index.blade.php ENDPATH**/ ?>