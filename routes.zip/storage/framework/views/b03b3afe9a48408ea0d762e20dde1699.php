<?php $__env->startSection('title', 'Shipments'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $classes = ['delivered'=>'success','shipped'=>'info','out_for_delivery'=>'info','packed'=>'primary','pending'=>'secondary','returning'=>'warning','returned'=>'secondary','failed'=>'danger'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Shipments</h5>
        <small class="text-muted"><?php echo e($shipments->total()); ?> shipments total</small>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.shipments.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Status</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(request('status') === $status ? 'selected' : ''); ?>><?php echo e(ucwords(str_replace('_', ' ', $status))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.shipments.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Shipment</th>
                    <th>Order #</th>
                    <th>Courier</th>
                    <th>Tracking #</th>
                    <th>Status</th>
                    <th>Shipped At</th>
                    <th>Est. Delivery</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="small text-primary fw-semibold">#<?php echo e($shipment->id); ?></td>
                        <td class="small"><?php echo e($shipment->order?->order_number ?: '—'); ?></td>
                        <td class="small"><?php echo e($shipment->courier ?: '—'); ?></td>
                        <td class="small"><?php echo e($shipment->tracking_number ?: '—'); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($classes[$shipment->status] ?? 'secondary'); ?>"><?php echo e(ucwords(str_replace('_', ' ', $shipment->status))); ?></span>
                        </td>
                        <td class="small"><?php echo e($shipment->shipped_at?->format('d M Y')); ?></td>
                        <td class="small"><?php echo e($shipment->estimated_delivery?->format('d M Y')); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('admin.shipments.show', $shipment)); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="bi bi-eye"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-muted">No shipments found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($shipments->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\shipments\index.blade.php ENDPATH**/ ?>