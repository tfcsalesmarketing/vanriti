<?php $__env->startSection('title', 'Refunds'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $classes = ['completed'=>'success','approved'=>'primary','processing'=>'warning','requested'=>'secondary','under_review'=>'info','rejected'=>'danger'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Refunds</h5>
        <small class="text-muted"><?php echo e($refunds->total()); ?> refunds total</small>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.refunds.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search refund # or order #..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Status</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(request('status') === $status ? 'selected' : ''); ?>><?php echo e(ucwords(str_replace('_', ' ', $status))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.refunds.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Refund #</th>
                    <th>Order #</th>
                    <th>Customer</th>
                    <th class="text-end">Amount</th>
                    <th>Type</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Requested</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="small text-primary fw-semibold"><?php echo e($refund->refund_number); ?></td>
                        <td class="small"><?php echo e($refund->order?->order_number ?: '—'); ?></td>
                        <td>
                            <div class="fw-semibold small"><?php echo e($refund->user?->name ?: '—'); ?></div>
                            <div class="text-muted small"><?php echo e($refund->user?->email); ?></div>
                        </td>
                        <td class="text-end fw-semibold small"><?php echo e(format_price($refund->amount)); ?></td>
                        <td class="small text-capitalize"><?php echo e($refund->type); ?></td>
                        <td class="small"><?php echo e($refund->method ?: '—'); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($classes[$refund->status] ?? 'secondary'); ?>"><?php echo e(ucwords(str_replace('_', ' ', $refund->status))); ?></span>
                        </td>
                        <td class="small"><?php echo e($refund->requested_at?->format('d M Y')); ?></td>
                        <td class="text-end">
                            <?php if(in_array($refund->status, ['requested', 'under_review'])): ?>
                                <div class="d-flex gap-1 justify-content-end">
                                    <form method="POST" action="<?php echo e(route('admin.refunds.approve', $refund)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="admin_note" value="">
                                        <button type="submit" class="btn btn-sm btn-outline-success" title="Approve"><i class="bi bi-check-lg"></i></button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.refunds.reject', $refund)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="admin_note" value="">
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Reject"><i class="bi bi-x-lg"></i></button>
                                    </form>
                                </div>
                            <?php elseif($refund->status === 'approved'): ?>
                                <div class="d-flex gap-1 justify-content-end">
                                    <form method="POST" action="<?php echo e(route('admin.refunds.process', $refund)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-primary" title="Process"><i class="bi bi-play-fill"></i></button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.refunds.complete', $refund)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" name="gateway_reference" class="form-control form-control-sm d-inline-block" style="width:110px;" placeholder="Ref #" title="Gateway reference">
                                        <button type="submit" class="btn btn-sm btn-outline-success" title="Complete"><i class="bi bi-check2-circle"></i></button>
                                    </form>
                                </div>
                            <?php elseif($refund->status === 'processing'): ?>
                                <form method="POST" action="<?php echo e(route('admin.refunds.complete', $refund)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex gap-1 justify-content-end">
                                        <input type="text" name="gateway_reference" class="form-control form-control-sm" style="width:120px;" placeholder="Gateway ref" title="Gateway reference">
                                        <button type="submit" class="btn btn-sm btn-outline-success" title="Complete"><i class="bi bi-check2-circle"></i>Complete</button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center py-4 text-muted">No refunds found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($refunds->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\refunds\index.blade.php ENDPATH**/ ?>