<?php
    $admin = auth('admin')->user();
    $newInquiriesCount = \App\Models\Tfc\TfcInquiry::where('status', 'new')->count();
    $pendingGrievanceCount = \App\Models\Tfc\TfcGrievanceTicket::where('status', '!=', 'resolved')->count();
    $unreadTfcWaCount = \App\Models\WhatsAppConversation::where('channel', 'tfc')->where('unread_count', '>', 0)->count();
    $pendingKycCount = \App\Models\Tfc\MemberKyc::where('status', 'pending')->count();

    // Group active checks matching VANRITI accordion pattern
    $membersActive = request()->routeIs('admin.tfc.members.*', 'admin.tfc.kyc.*');
    $crmActive = request()->routeIs('admin.tfc.inquiries.*', 'admin.tfc.grievances.*');
    $waActive = request()->routeIs('admin.tfc.whatsapp.*');
    $settingsActive = request()->routeIs('admin.tfc.settings.*');
?>


<div class="px-2 mb-2">
    <a class="nav-link text-success fw-semibold d-flex align-items-center gap-2 p-2 rounded" 
       href="<?php echo e(route('admin.dashboard')); ?>" 
       style="background: rgba(25, 135, 84, 0.08); font-size: 0.85rem; transition: background 0.2s ease;">
        <i class="bi bi-arrow-left-circle fs-6"></i>
        <span>Back to VANRITI</span>
    </a>
</div>


<div class="px-3 py-2 mb-3 rounded-3 d-flex align-items-center gap-2" 
     style="background: #0A1D37; color: #FFFFFF; border: 1px solid rgba(212, 155, 36, 0.4); box-shadow: 0 2px 6px rgba(10, 29, 55, 0.15);">
    <i class="bi bi-building fs-5" style="color: #D49B24;"></i>
    <div class="overflow-hidden">
        <div class="fw-bold small text-truncate" style="letter-spacing: 0.5px; color: #F8FAFC;">TFC SALES &amp; MKTG</div>
        <div class="small text-truncate" style="font-size: 0.68rem; color: #CBD5E1;">Direct-Selling Suite</div>
    </div>
</div>

<ul class="nav flex-column">
    
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.tfc.dashboard') ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.tfc.dashboard')); ?>">
            <i class="bi bi-grid-1x2"></i>
            <span>TFC Dashboard</span>
        </a>
    </li>

    
    <li class="nav-item">
        <a class="nav-link sidebar-group-toggle <?php echo e($membersActive ? 'active-parent' : ''); ?>"
           data-bs-toggle="collapse"
           href="#collapseTfcMembers"
           role="button"
           aria-expanded="<?php echo e($membersActive ? 'true' : 'false'); ?>"
           aria-controls="collapseTfcMembers">
            <i class="bi bi-diagram-3-fill" style="color: #D49B24;"></i>
            <span>Network &amp; Members</span>
            <?php if($pendingKycCount > 0): ?>
                <span class="badge rounded-pill bg-warning text-dark ms-auto me-1" style="font-size: 0.68rem; padding: 0.25em 0.55em;" title="Pending KYC Approvals">
                    <?php echo e($pendingKycCount); ?>

                </span>
            <?php endif; ?>
            <i class="bi bi-chevron-right chevron-icon"></i>
        </a>
        <div class="collapse <?php echo e($membersActive ? 'show' : ''); ?>" id="collapseTfcMembers">
            <ul class="sidebar-submenu">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin.tfc.members.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.members.index')); ?>">
                        <i class="bi bi-person-badge"></i>
                        <span>Member Directory</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center justify-content-between <?php echo e(request()->routeIs('admin.tfc.kyc.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.kyc.index')); ?>">
                        <span class="d-flex align-items-center gap-2">
                            <i class="bi bi-shield-check"></i>
                            <span>KYC Desk</span>
                        </span>
                        <?php if($pendingKycCount > 0): ?>
                            <span class="badge bg-warning text-dark rounded-pill" style="font-size: 0.65rem;"><?php echo e($pendingKycCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </li>

    
    <li class="nav-item">
        <a class="nav-link sidebar-group-toggle <?php echo e($crmActive ? 'active-parent' : ''); ?>"
           data-bs-toggle="collapse"
           href="#collapseTfcCrm"
           role="button"
           aria-expanded="<?php echo e($crmActive ? 'true' : 'false'); ?>"
           aria-controls="collapseTfcCrm">
            <i class="bi bi-people"></i>
            <span>Direct Selling Desk</span>
            <?php if($newInquiriesCount + $pendingGrievanceCount > 0): ?>
                <span class="badge rounded-pill bg-danger ms-auto me-1" style="font-size: 0.68rem; padding: 0.25em 0.55em;">
                    <?php echo e($newInquiriesCount + $pendingGrievanceCount); ?>

                </span>
            <?php endif; ?>
            <i class="bi bi-chevron-right chevron-icon"></i>
        </a>
        <div class="collapse <?php echo e($crmActive ? 'show' : ''); ?>" id="collapseTfcCrm">
            <ul class="sidebar-submenu">
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center justify-content-between <?php echo e(request()->routeIs('admin.tfc.inquiries.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.inquiries.index')); ?>">
                        <span class="d-flex align-items-center gap-2">
                            <i class="bi bi-person-lines-fill"></i>
                            <span>Inquiries &amp; Apps</span>
                        </span>
                        <?php if($newInquiriesCount > 0): ?>
                            <span class="badge bg-primary rounded-pill" style="font-size: 0.65rem;"><?php echo e($newInquiriesCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center justify-content-between <?php echo e(request()->routeIs('admin.tfc.grievances.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.grievances.index')); ?>">
                        <span class="d-flex align-items-center gap-2">
                            <i class="bi bi-shield-exclamation text-danger"></i>
                            <span>Grievances (Rule 7)</span>
                        </span>
                        <?php if($pendingGrievanceCount > 0): ?>
                            <span class="badge bg-danger rounded-pill" style="font-size: 0.65rem;"><?php echo e($pendingGrievanceCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </li>

    
    <li class="nav-item">
        <a class="nav-link sidebar-group-toggle <?php echo e($waActive ? 'active-parent' : ''); ?>"
           data-bs-toggle="collapse"
           href="#collapseTfcWhatsApp"
           role="button"
           aria-expanded="<?php echo e($waActive ? 'true' : 'false'); ?>"
           aria-controls="collapseTfcWhatsApp">
            <i class="bi bi-whatsapp" style="color: #25D366;"></i>
            <span>WhatsApp CRM</span>
            <?php if($unreadTfcWaCount > 0): ?>
                <span class="badge rounded-pill bg-success ms-auto me-1" style="font-size: 0.68rem; padding: 0.25em 0.55em;">
                    <?php echo e($unreadTfcWaCount); ?>

                </span>
            <?php endif; ?>
            <i class="bi bi-chevron-right chevron-icon"></i>
        </a>
        <div class="collapse <?php echo e($waActive ? 'show' : ''); ?>" id="collapseTfcWhatsApp">
            <ul class="sidebar-submenu">
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center justify-content-between <?php echo e(request()->routeIs('admin.tfc.whatsapp.inbox*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.whatsapp.inbox')); ?>">
                        <span class="d-flex align-items-center gap-2">
                            <i class="bi bi-chat-dots-fill" style="color: #25D366;"></i>
                            <span>Live Chat Inbox</span>
                        </span>
                        <?php if($unreadTfcWaCount > 0): ?>
                            <span class="badge bg-success rounded-pill" style="font-size: 0.65rem;"><?php echo e($unreadTfcWaCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin.tfc.whatsapp.campaigns.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.whatsapp.campaigns.index')); ?>">
                        <i class="bi bi-megaphone"></i>
                        <span>Broadcast Campaigns</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin.tfc.whatsapp.bot.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.whatsapp.bot.index')); ?>">
                        <i class="bi bi-robot"></i>
                        <span>Chatbot &amp; Quick Replies</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin.tfc.whatsapp.templates.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.whatsapp.templates.index')); ?>">
                        <i class="bi bi-file-earmark-check"></i>
                        <span>Meta Templates</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin.tfc.whatsapp.profile*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('admin.tfc.whatsapp.profile')); ?>">
                        <i class="bi bi-gear-wide-connected"></i>
                        <span>API &amp; Floating Widget</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>

    
    <li class="nav-item">
        <a class="nav-link <?php echo e($settingsActive ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.tfc.settings.index')); ?>">
            <i class="bi bi-gear" style="color: #D49B24;"></i>
            <span>Corporate Settings</span>
        </a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/tfc/partials/sidebar-nav.blade.php ENDPATH**/ ?>