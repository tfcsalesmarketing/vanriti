<?php
    $logo = setting('store_logo');
    if (! $logo) {
        foreach (['svg', 'png', 'webp', 'jpg'] as $ext) {
            if (file_exists(public_path('images/logo.' . $ext))) {
                $logo = 'images/logo.' . $ext;
                break;
            }
        }
    }
    $footerCats = App\Models\Category::with(['children'])
        ->whereNull('parent_id')
        ->where('status', 'active')
        ->orderBy('sort_order')
        ->take(6)
        ->get();
?>

<footer class="vr-footer d-none d-lg-block">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <a href="<?php echo e(route('home')); ?>" class="vr-footer-brand mb-3">
                    <?php if($logo): ?>
                        <img src="<?php echo e(image_url($logo, 'favicon.ico')); ?>" alt="<?php echo e(store_name()); ?>" height="40" class="vr-logo">
                    <?php else: ?>
                        <span class="vr-brand-name"><?php echo e(store_name()); ?></span>
                    <?php endif; ?>
                </a>
                <p class="vr-footer-about"><?php echo e(setting('store_tagline', 'PURE BY NATURE')); ?>. Handcrafted skincare, herbal teas and wellness essentials made with nature in mind.</p>
                <ul class="list-unstyled vr-footer-contact mb-0">
                    <li><i class="ri-map-pin-2-line"></i><?php echo nl2br(e(setting('store_address', ''))); ?></li>
                    <li><i class="ri-mail-line"></i><?php echo e(setting('store_email', '')); ?></li>
                    <li><i class="ri-phone-line"></i><?php echo e(setting('store_phone', '')); ?></li>
                    <li>
                        <a href="https://wa.me/919211946606?text=<?php echo e(urlencode('Hi Vanriti, I would like to inquire about your products.')); ?>" target="_blank" rel="noopener noreferrer" class="text-decoration-none d-inline-flex align-items-center gap-2" style="color:inherit;">
                            <i class="ri-whatsapp-line text-success"></i> +91 92119 46606
                        </a>
                    </li>
                </ul>
                <?php
                    $_socials = array_filter([
                        'whatsapp' => 'https://wa.me/919211946606?text=' . urlencode('Hi Vanriti, I would like to inquire about your products.'),
                        'instagram' => setting('instagram_url'),
                        'facebook' => setting('facebook_url'),
                        'twitter' => setting('twitter_url'),
                        'youtube' => setting('youtube_url'),
                        'linkedin' => setting('linkedin_url'),
                    ]);
                ?>
                <?php if($_socials): ?>
                    <div class="vr-footer-social mt-3">
                        <?php $__currentLoopData = $_socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_handle => $_url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($_url); ?>" class="vr-social-icon" aria-label="<?php echo e(ucfirst($_handle)); ?>" target="_blank" rel="noopener noreferrer">
                                <i class="ri-<?php echo e($_handle === 'twitter' ? 'twitter-x-line' : $_handle); ?>-line"></i>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-lg-2">
                <div class="vr-footer-title">Shop</div>
                <ul class="list-unstyled vr-footer-links">
                    <li><a href="<?php echo e(route('shop.index')); ?>">All Products</a></li>
                    <?php $__currentLoopData = $footerCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('shop.category', $cat->slug)); ?>"><?php echo e($cat->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="col-lg-2">
                <div class="vr-footer-title">Company</div>
                <ul class="list-unstyled vr-footer-links">
                    <li><a href="<?php echo e(route('info.about')); ?>">About Us</a></li>
                    <li><a href="<?php echo e(route('blog.index')); ?>">Journal</a></li>
                    <li><a href="<?php echo e(route('faq.index')); ?>">FAQs</a></li>
                    <li><a href="<?php echo e(route('contact.index')); ?>">Contact Us</a></li>
                </ul>
            </div>

            <div class="col-lg-2">
                <div class="vr-footer-title">Customer Care</div>
                <ul class="list-unstyled vr-footer-links">
                    <li><a href="<?php echo e(route('track')); ?>">Track Order</a></li>
                    <li><a href="<?php echo e(route('account.orders')); ?>">My Orders</a></li>
                    <li><a href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a></li>
                    <li><a href="<?php echo e(route('shop.return-policy')); ?>">Returns &amp; Refunds</a></li>
                    <li><a href="<?php echo e(route('shop.cancellation-policy')); ?>">Cancellation Policy</a></li>
                </ul>
            </div>

            <div class="col-lg-2">
                <div class="vr-footer-title">Policies</div>
                <ul class="list-unstyled vr-footer-links">
                    <li><a href="<?php echo e(route('info.shipping')); ?>">Shipping &amp; Delivery</a></li>
                    <li><a href="<?php echo e(route('info.privacy')); ?>">Privacy Policy</a></li>
                    <li><a href="<?php echo e(route('info.terms')); ?>">Terms &amp; Conditions</a></li>
                    <li><a href="<?php echo e(route('info.disclaimer')); ?>">Disclaimer</a></li>
                    <li><a href="<?php echo e(route('sitemap')); ?>">Sitemap</a></li>
                </ul>
            </div>
        </div>

        <div class="vr-footer-bottom">
            <span>Vanriti &copy; Copyright TFC Sales &amp; Marketing</span>
        </div>
    </div>
</footer>

<?php echo $__env->make('storefront.partials.bottom-bar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/partials/footer.blade.php ENDPATH**/ ?>