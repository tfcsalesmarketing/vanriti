<?php $__env->startSection('title', 'Dadi Product Profiles'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $statusColors = [
        'draft' => 'secondary', 'pending_review' => 'warning', 'approved' => 'success', 'rejected' => 'danger',
    ];
    $productStatusColors = ['draft' => 'secondary', 'active' => 'success', 'inactive' => 'secondary'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Dadi Product Profiles</h5>
        <small class="text-muted"><?php echo e($profiles->total()); ?> profiles total</small>
    </div>
    <a href="<?php echo e(route('admin.dadi.product-profiles.create')); ?>" class="btn btn-sm btn-dark"><i class="bi bi-plus-lg me-1"></i>New Profile</a>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.dadi.product-profiles.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search product..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Status</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status->value); ?>" <?php echo e(request('status') === $status->value ? 'selected' : ''); ?>><?php echo e($status->label()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-sm btn-dark"><i class="bi bi-search me-1"></i>Filter</button>
            </div>
            <div class="col-auto">
                <a href="<?php echo e(route('admin.dadi.product-profiles.index')); ?>" class="btn btn-sm btn-outline-secondary">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Section</th>
                    <th>Concerns</th>
                    <th>Approval</th>
                    <th>Reviewed By</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="small fw-semibold"><?php echo e($profile->product?->name ?: 'Product #'.$profile->product_id); ?></div>
                            <div class="text-muted" style="font-size:0.75rem;"><?php echo e($profile->product?->sku ?: '—'); ?></div>
                            <span class="badge bg-<?php echo e($productStatusColors[$profile->product?->status] ?? 'secondary'); ?>" style="font-size:0.65rem;"><?php echo e(ucfirst($profile->product?->status ?: 'missing')); ?></span>
                        </td>
                        <td>
                            <?php $__currentLoopData = $profile->sections ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-light text-dark me-1"><?php echo e(ucfirst($section)); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php $__currentLoopData = array_slice($profile->concerns ?? [], 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-light text-dark me-1" style="font-size:0.7rem;"><?php echo e($concern); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(count($profile->concerns ?? []) > 3): ?>
                                <span class="text-muted small">+<?php echo e(count($profile->concerns) - 3); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-<?php echo e($statusColors[$profile->status->value] ?? 'secondary'); ?>"><?php echo e($profile->status->label()); ?></span>
                            <?php if($profile->reviewed_at): ?>
                                <div class="text-muted" style="font-size:0.7rem;"><?php echo e($profile->reviewed_at->format('d M Y')); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="small"><?php echo e($profile->reviewer?->name ?: '—'); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('admin.dadi.product-profiles.edit', $profile->id)); ?>" class="btn btn-sm btn-outline-dark">Open</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">No Dadi product profiles found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($profiles->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/dadi-product-profiles/index.blade.php ENDPATH**/ ?>