<?php
    $admin = auth('admin')->user();
?>

<ul class="nav flex-column">
    <?php if($admin->hasPermission('view-dashboard')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="bi bi-grid-1x2"></i><span>Dashboard</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if($admin->hasPermission('view-reports')): ?>
    <li class="nav-heading">Analytics</li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.analytics') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.analytics')); ?>">
            <i class="bi bi-graph-up"></i><span>Analytics Command Center</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if($admin->hasPermission(['manage-products', 'manage-categories', 'manage-inventory', 'review-dadi-product-profiles'])): ?>
    <li class="nav-heading">Catalogue</li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-products')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.products.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.products.index')); ?>">
            <i class="bi bi-box-seam"></i><span>Products</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-categories')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.categories.index')); ?>">
            <i class="bi bi-diagram-3"></i><span>Categories</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.main-categories.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.main-categories.index')); ?>">
            <i class="bi bi-folder"></i><span>Main Categories</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-inventory')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.inventory.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.inventory.index')); ?>">
            <i class="bi bi-box2"></i><span>Inventory</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('review-dadi-product-profiles')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.dadi.product-profiles.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.dadi.product-profiles.index')); ?>">
            <i class="bi bi-robot"></i><span>Dadi Product Profiles</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if($admin->hasPermission(['manage-orders', 'manage-refunds', 'manage-returns', 'manage-shipments'])): ?>
    <li class="nav-heading">Orders</li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-orders')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.orders.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.orders.index')); ?>">
            <i class="bi bi-cart-check"></i><span>Orders</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-refunds')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.refunds.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.refunds.index')); ?>">
            <i class="bi bi-arrow-counterclockwise"></i><span>Refunds</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-returns')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.returns.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.returns.index')); ?>">
            <i class="bi bi-return"></i><span>Returns</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-shipments')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.shipments.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.shipments.index')); ?>">
            <i class="bi bi-truck"></i><span>Shipments</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if($admin->hasPermission(['manage-customers', 'manage-coupons', 'manage-reviews', 'manage-newsletters'])): ?>
    <li class="nav-heading">Customers</li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-customers')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.customers.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.customers.index')); ?>">
            <i class="bi bi-people"></i><span>Customers</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-coupons')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.coupons.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.coupons.index')); ?>">
            <i class="bi bi-ticket-perforated"></i><span>Coupons</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-reviews')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.reviews.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.reviews.index')); ?>">
            <i class="bi bi-star"></i><span>Reviews</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-newsletters')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.newsletters.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.newsletters.index')); ?>">
            <i class="bi bi-envelope-heart"></i><span>Newsletter</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if($admin->hasPermission(['manage-media', 'manage-banners', 'manage-blogs', 'manage-pages', 'manage-faqs'])): ?>
    <li class="nav-heading">Content</li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-media')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.media.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.media.index')); ?>">
            <i class="bi bi-folder2-open"></i><span>Media Library</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-banners')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.banners.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.banners.index')); ?>">
            <i class="bi bi-images"></i><span>Banners</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-blogs')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.blogs.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.blogs.index')); ?>">
            <i class="bi bi-journal-text"></i><span>Blogs</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-pages')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.pages.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.pages.index')); ?>">
            <i class="bi bi-file-text"></i><span>Pages</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-faqs')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.faqs.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.faqs.index')); ?>">
            <i class="bi bi-question-circle"></i><span>FAQs</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if($admin->hasPermission(['manage-admins', 'manage-roles', 'manage-activities', 'manage-settings'])): ?>
    <li class="nav-heading">System</li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-admins')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.admins.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.admins.index')); ?>">
            <i class="bi bi-person-gear"></i><span>Admins</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-roles')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.roles.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.roles.index')); ?>">
            <i class="bi bi-shield-lock"></i><span>Roles & Permissions</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-activities')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.activities.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.activities.index')); ?>">
            <i class="bi bi-clock-history"></i><span>Activity Log</span>
        </a>
    </li>
    <?php endif; ?>
    <?php if($admin->hasPermission('manage-settings')): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('admin.settings.index')); ?>">
            <i class="bi bi-gear"></i><span>Settings</span>
        </a>
    </li>
    <?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\partials\sidebar-nav.blade.php ENDPATH**/ ?>