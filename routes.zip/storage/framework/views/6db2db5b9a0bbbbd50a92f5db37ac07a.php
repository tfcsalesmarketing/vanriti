<?php $__env->startSection('title', 'Forgot Password'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-auth-shell">
    <div class="vr-auth-container vr-auth-container-narrow">
        <div class="card vr-auth-card">
            <div class="vr-auth-form-panel p-4 p-md-5">
                <div class="text-center mb-4">
                    <div class="vr-otp-icon mb-3" style="background: rgba(38, 61, 37, 0.1); color: var(--vr-auth-primary); border-color: rgba(38, 61, 37, 0.2);">
                        <i class="ri-lock-unlock-line"></i>
                    </div>
                    <div class="vr-kicker mb-1">RECOVER ACCOUNT</div>
                    <h5 class="fw-bold text-dark mb-1">Forgot Password?</h5>
                    <p class="vr-auth-subtitle mb-0">Enter your registered email and we'll send you a password reset link.</p>
                </div>

                <form method="POST" action="<?php echo e(route('password.email')); ?>" id="vrForgotForm" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label class="form-label small fw-semibold" for="forgot_email">Email Address</label>
                        <div class="vr-input-wrap">
                            <input type="email" id="forgot_email" name="email" value="<?php echo e(old('email')); ?>"
                                   class="form-control" placeholder="e.g. user@domain.com"
                                   autocomplete="email" autofocus>
                            <i class="ri-mail-send-line vr-input-icon"></i>
                        </div>
                        <div class="invalid-feedback d-block mt-1 small"></div>
                    </div>

                    <button type="submit" class="btn btn-vr w-100 py-2.5">
                        Send Reset Link
                    </button>
                </form>

                <p class="text-center small text-muted mt-4 mb-0">
                    Remember your password? <a href="<?php echo e(route('login')); ?>" class="fw-bold vr-link-underline">&larr; Back to login</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/storefront-auth.css')); ?>?v=<?php echo e(@filemtime(public_path('css/storefront-auth.css')) ?: time()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var form = document.getElementById('vrForgotForm');
        if (form && typeof window.vrLiveServerValidation === 'function') {
            window.vrLiveServerValidation(form, '<?php echo e(route('auth.validate')); ?>', {
                context: 'forgot'
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\auth\forgot-password.blade.php ENDPATH**/ ?>