<?php $__env->startSection('title', 'Unsubscribed'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-section">
    <div class="container">
        <div class="mx-auto" style="max-width:640px;text-align:center;">
            <h1 class="mb-3" style="font-weight:800;color:var(--vr-green-dark);">You have been unsubscribed</h1>

            <p style="line-height:1.8;">
                This email address will no longer receive offers and news from <?php echo e(store_name()); ?>.
                Changed your mind? You can subscribe again any time from the footer of any page.
            </p>

            <a href="<?php echo e(route('home')); ?>" class="btn btn-dark mt-3">Continue shopping</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\unsubscribed.blade.php ENDPATH**/ ?>