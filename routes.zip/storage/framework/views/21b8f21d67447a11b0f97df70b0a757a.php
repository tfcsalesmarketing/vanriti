<?php $__env->startSection('title', 'Blogs'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Blogs</h5>
        <small class="text-muted"><?php echo e($blogs->total()); ?> blog posts total</small>
    </div>
    <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Blog</a>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.blogs.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search by title..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Featured</th>
                    <th>Title / Slug</th>
                    <th>Category</th>
                    <th>Author</th>
                    <th>Status</th>
                    <th>Published</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($blog->featured_image): ?>
                                <img src="<?php echo e(image_url($blog->featured_image)); ?>" alt="" class="img-thumb">
                            <?php else: ?>
                                <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                    <i class="bi bi-journal-text text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="fw-semibold small"><?php echo e($blog->title); ?></div>
                            <div class="text-muted small"><?php echo e($blog->slug); ?></div>
                        </td>
                        <td class="small"><?php echo e($blog->category->name ?? '—'); ?></td>
                        <td class="small"><?php echo e($blog->author->name ?? '—'); ?></td>
                        <td>
                            <span class="badge <?php echo e($blog->status === 'published' ? 'badge-soft-success' : ($blog->status === 'archived' ? 'badge-soft-secondary' : 'badge-soft-warning')); ?>"><?php echo e(ucfirst($blog->status)); ?></span>
                        </td>
                        <td class="small text-muted"><?php echo e($blog->published_at?->format('d M Y') ?: '—'); ?></td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <a href="<?php echo e(route('admin.blogs.edit', $blog)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <form method="POST" action="<?php echo e(route('admin.blogs.destroy', $blog)); ?>" data-confirm="Delete this blog post?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No blog posts found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($blogs->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>