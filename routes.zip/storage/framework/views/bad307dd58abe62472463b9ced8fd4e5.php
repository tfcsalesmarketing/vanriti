<?php
    $category = $category ?? null;
    $excludeIds = $excludeIds ?? [];
?>

<div class="row g-3">
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-header fw-semibold">Basic Information</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Category Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control form-control-sm" value="<?php echo e(old('name', $category->name ?? '')); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Parent Category</label>
                        <select name="parent_id" class="form-select form-select-sm">
                            <option value="">None (Root)</option>
                            <?php
                                $parentCats = $categories->whereNull('parent_id');
                            ?>
                            <?php $__currentLoopData = $parentCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(! in_array($pc->id, $excludeIds)): ?>
                                    <option value="<?php echo e($pc->id); ?>" <?php echo e(old('parent_id', $category->parent_id ?? '') == $pc->id ? 'selected' : ''); ?>><?php echo e($pc->name); ?></option>
                                    <?php
                                        $childCats = $categories->where('parent_id', $pc->id);
                                    ?>
                                    <?php $__currentLoopData = $childCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(! in_array($cc->id, $excludeIds)): ?>
                                            <option value="<?php echo e($cc->id); ?>" <?php echo e(old('parent_id', $category->parent_id ?? '') == $cc->id ? 'selected' : ''); ?>>&nbsp;&nbsp;— <?php echo e($cc->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select form-select-sm" required>
                            <option value="active" <?php echo e(old('status', $category->status ?? 'active') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(old('status', $category->status ?? '') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Sort Order</label>
                        <input type="number" name="sort_order" class="form-control form-control-sm" value="<?php echo e(old('sort_order', $category->sort_order ?? 0)); ?>" min="0">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Description</label>
                        <textarea name="description" class="form-control form-control-sm" rows="3"><?php echo e(old('description', $category->description ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Image</label>
                        <input type="file" name="image" class="form-control form-control-sm" accept="image/jpeg,image/png,image/webp">
                        <?php if($category && $category->image): ?>
                            <div class="mt-2"><img src="<?php echo e(image_url($category->image)); ?>" alt="" class="img-thumb"></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">SEO</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Meta Title</label>
                        <input type="text" name="meta_title" class="form-control form-control-sm" value="<?php echo e(old('meta_title', $category->meta_title ?? '')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Meta Keywords</label>
                        <input type="text" name="meta_keywords" class="form-control form-control-sm" value="<?php echo e(old('meta_keywords', $category->meta_keywords ?? '')); ?>">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Meta Description</label>
                        <textarea name="meta_description" class="form-control form-control-sm" rows="2"><?php echo e(old('meta_description', $category->meta_description ?? '')); ?></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex gap-2 mt-3">
    <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-check-lg me-1"></i>Save Category</button>
    <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-sm btn-outline-secondary">Cancel</a>
</div>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\categories\_form.blade.php ENDPATH**/ ?>