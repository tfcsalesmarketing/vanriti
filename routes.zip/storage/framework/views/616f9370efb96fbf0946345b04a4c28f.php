<?php $__env->startSection('title', 'Edit Order '.$order->order_number); ?>

<?php $__env->startSection('content'); ?>
<?php
    $oClass = ['cancelled'=>'danger','failed'=>'danger','delivered'=>'success','shipped'=>'info','out_for_delivery'=>'info','pending'=>'secondary','confirmed'=>'primary','processing'=>'warning','packed'=>'warning'];
    $pClass = ['paid'=>'success','refunded'=>'secondary','partially_refunded'=>'warning','pending'=>'secondary','processing'=>'info','failed'=>'danger','cancelled'=>'danger'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Edit Order <?php echo e($order->order_number); ?></h5>
        <small class="text-muted">Placed on <?php echo e($order->created_at->format('d M Y, h:i A')); ?></small>
    </div>
    <div class="d-flex gap-2">
        <span class="badge bg-<?php echo e($oClass[$order->order_status] ?? 'secondary'); ?> align-self-center"><?php echo e(ucwords(str_replace('_', ' ', $order->order_status))); ?></span>
        <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="btn btn-sm btn-outline-info">View</a>
        <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-outline-secondary">Back</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header">Update Order Status</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.orders.status', $order)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-2">
                        <label class="form-label small text-muted">New Status</label>
                        <select name="order_status" class="form-select form-select-sm" required>
                            <?php $__currentLoopData = $orderStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>" <?php echo e($order->order_status === $status ? 'selected' : ''); ?>><?php echo e(ucwords(str_replace('_', ' ', $status))); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small text-muted">Description (optional)</label>
                        <textarea name="description" class="form-control form-control-sm" rows="2" maxlength="500" placeholder="e.g. Package handed to courier"></textarea>
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-check-circle me-1"></i>Update Status</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header">Payment Status</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.orders.payment-status', $order)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-2">
                        <label class="form-label small text-muted">Payment Status</label>
                        <select name="payment_status" class="form-select form-select-sm" required>
                            <option value="paid" <?php echo e($order->payment_status === 'paid' ? 'selected' : ''); ?>>Paid</option>
                            <option value="failed" <?php echo e($order->payment_status === 'failed' ? 'selected' : ''); ?>>Failed</option>
                            <option value="cancelled" <?php echo e($order->payment_status === 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="small text-muted mb-2">
                        Current: <span class="badge bg-<?php echo e($pClass[$order->payment_status] ?? 'secondary'); ?>"><?php echo e(ucwords(str_replace('_', ' ', $order->payment_status))); ?></span>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small text-muted">Reason (required)</label>
                        <input type="text" name="reason" class="form-control form-control-sm" maxlength="1000" placeholder="e.g. UPI payment confirmed in bank statement" required>
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-credit-card me-1"></i>Update Payment</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header">Add Internal Note</div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.orders.notes', $order)); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-2">
                <textarea name="internal_notes" class="form-control form-control-sm" rows="2" maxlength="2000" placeholder="Add a note for your team..."></textarea>
            </div>
            <button type="submit" class="btn btn-sm btn-outline-primary"><i class="bi bi-sticky me-1"></i>Add Note</button>
        </form>
        <?php if($order->internal_notes): ?>
            <hr>
            <div class="small text-muted" style="white-space:pre-line;"><?php echo e($order->internal_notes); ?></div>
        <?php endif; ?>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header">Items</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th class="text-center">Qty</th>
                    <th class="text-end">Unit Price</th>
                    <th class="text-end">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php if($item->image): ?>
                                    <?php if(str_starts_with($item->image, 'http')): ?>
                                        <img src="<?php echo e($item->image); ?>" alt="" class="rounded" width="40" height="40" style="object-fit:cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(image_url($item->image)); ?>" alt="" class="rounded" width="40" height="40" style="object-fit:cover;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:40px;height:40px;"><i class="bi bi-image text-muted"></i></div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-semibold small"><?php echo e($item->product_name); ?></div>
                                    <div class="text-muted small"><?php echo e($item->variant_name ?: ($item->sku ?: '')); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="text-center small"><?php echo e($item->quantity); ?></td>
                        <td class="text-end small"><?php echo e(format_price($item->unit_price)); ?></td>
                        <td class="text-end fw-semibold small"><?php echo e(format_price($item->total_price)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-header">Totals</div>
            <div class="card-body py-2 small">
<div class="d-flex justify-content-between py-1"><span class="text-muted">Subtotal</span><span><?php echo e(format_price($order->subtotal)); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Discount</span><span><?php echo e(format_price($order->discount_amount)); ?></span></div>
                <?php if($order->coupon_discount > 0): ?>
                    <div class="d-flex justify-content-between py-1">
                        <span class="text-muted">
                            Coupon<?php echo e($order->coupon_code ? ' ('.$order->coupon_code.')' : ''); ?>

                            <?php if($order->coupon_type || $order->coupon_value !== null): ?>
                                <span class="d-block text-muted" style="font-size:0.8em;"><?php echo e(ucfirst((string) $order->coupon_type)); ?><?php echo e($order->coupon_value !== null ? ' '.format_price($order->coupon_value) : ''); ?></span>
                            <?php endif; ?>
                        </span>
                        <span>- <?php echo e(format_price($order->coupon_discount)); ?></span>
                    </div>
                <?php endif; ?>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Taxable Value</span><span><?php echo e(format_price($order->taxable_value)); ?></span></div>
                <?php if($order->isIntraState()): ?>
                    <div class="d-flex justify-content-between py-1"><span class="text-muted">CGST<?php echo e($order->uniformGstRate() !== null ? ' ('.number_format($order->uniformGstRate() / 2, 1, '.', '').'%)' : ''); ?></span><span><?php echo e(format_price($order->cgst_amount)); ?></span></div>
                    <div class="d-flex justify-content-between py-1"><span class="text-muted">SGST<?php echo e($order->uniformGstRate() !== null ? ' ('.number_format($order->uniformGstRate() / 2, 1, '.', '').'%)' : ''); ?></span><span><?php echo e(format_price($order->sgst_amount)); ?></span></div>
                <?php else: ?>
                    <div class="d-flex justify-content-between py-1"><span class="text-muted">IGST<?php echo e($order->uniformGstRate() !== null ? ' ('.(float) $order->uniformGstRate().'%)' : ''); ?></span><span><?php echo e(format_price($order->igst_amount)); ?></span></div>
                <?php endif; ?>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Shipping</span><span><?php echo e(format_price($order->shipping_charge)); ?></span></div>
                <hr class="my-1">
                <div class="d-flex justify-content-between py-1 fw-bold"><span>Grand Total</span><span><?php echo e(format_price($order->grand_total)); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Paid</span><span><?php echo e(format_price($order->amount_paid)); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Due</span><span class="fw-semibold"><?php echo e(format_price($order->amount_due)); ?></span></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-header">Billing</div>
            <div class="card-body small">
                <div class="fw-semibold"><?php echo e($order->billing_name); ?></div>
                <div class="text-muted"><?php echo e($order->billing_address_line1); ?></div>
                <?php if($order->billing_address_line2): ?><div class="text-muted"><?php echo e($order->billing_address_line2); ?></div><?php endif; ?>
                <?php if($order->billing_landmark): ?><div class="text-muted"><?php echo e($order->billing_landmark); ?></div><?php endif; ?>
                <div class="text-muted"><?php echo e($order->billing_city); ?>, <?php echo e($order->billing_state); ?> - <?php echo e($order->billing_pincode); ?></div>
                <div class="text-muted mt-2">Ph: <?php echo e($order->billing_mobile); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-header">Shipping</div>
            <div class="card-body small">
                <div class="fw-semibold"><?php echo e($order->shipping_name); ?></div>
                <div class="text-muted"><?php echo e($order->shipping_address_line1); ?></div>
                <?php if($order->shipping_address_line2): ?><div class="text-muted"><?php echo e($order->shipping_address_line2); ?></div><?php endif; ?>
                <?php if($order->shipping_landmark): ?><div class="text-muted"><?php echo e($order->shipping_landmark); ?></div><?php endif; ?>
                <div class="text-muted"><?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?> - <?php echo e($order->shipping_pincode); ?></div>
                <div class="text-muted mt-2">Ph: <?php echo e($order->shipping_mobile); ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">Status History</div>
    <div class="card-body">
        <?php $__empty_1 = true; $__currentLoopData = $order->statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="d-flex gap-2 mb-2 small">
                <i class="bi bi-circle-fill mt-1" style="font-size:0.5rem;"></i>
                <div>
                    <div class="fw-semibold"><?php echo e(ucwords(str_replace('_', ' ', $history->status))); ?></div>
                    <div class="text-muted" style="font-size:0.75rem;"><?php echo e($history->created_at->format('d M Y, h:i A')); ?></div>
                    <?php if($history->description): ?><div class="text-muted"><?php echo e($history->description); ?></div><?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-muted small">No status history.</div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\orders\edit.blade.php ENDPATH**/ ?>