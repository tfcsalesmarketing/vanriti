<?php if(! empty($cards)): ?>
    <div class="dadi-recs" aria-label="<?php echo e(count($cards) > 1 ? 'Recommended products' : 'Recommended product'); ?>">
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="dadi-card"
                data-dadi-ref="<?php echo e($_card['reference'] ?? ''); ?>"
                data-add-url="<?php echo e($_card['add_url'] ?? ''); ?>"
                data-variant-id="<?php echo e($_card['variant_id'] ?? ''); ?>">
                <a class="dadi-card-media" href="<?php echo e($_card['product_url']); ?>" aria-label="<?php echo e('Dekho: '.$_card['name']); ?>" data-dadi-click>
                    <img
                        class="dadi-card-img"
                        src="<?php echo e($_card['image_url']); ?>"
                        alt=""
                        loading="lazy"
                    >
                </a>
                <div class="dadi-card-body">
                    <span class="dadi-card-name"><?php echo e($_card['name']); ?></span>
                    <span class="dadi-card-price">
                        <span class="dadi-card-now"><?php echo e($_card['price_formatted']); ?></span>
                        <?php if((float) $_card['mrp'] > (float) $_card['price']): ?>
                            <del class="dadi-card-mrp"><?php echo e($_card['mrp_formatted']); ?></del>
                        <?php endif; ?>
                    </span>
                    <span class="dadi-card-meta">
                        <span class="dadi-card-stock <?php echo e($_card['available'] ? 'is-available' : 'is-unavailable'); ?>">
                            <?php echo e($_card['available'] ? 'Stock mein hai' : 'Abhi stock khatam'); ?>

                        </span>
                    </span>
                    <?php if(! empty($_card['why'])): ?>
                        <p class="dadi-card-why"><?php echo e($_card['why']); ?></p>
                    <?php endif; ?>
                </div>
                <?php if(! empty($_card['addable']) && ! empty($_card['add_url'])): ?>
                    <div class="dadi-card-actions">
                        <button type="button" class="dadi-card-btn js-dadi-add">Cart mein rakho</button>
                        <button type="button" class="dadi-card-btn dadi-card-btn-primary js-dadi-buy-now">Abhi kharidein</button>
                        <span class="dadi-card-actions-row">
                            <a class="dadi-card-link" href="<?php echo e($_card['product_url']); ?>" data-dadi-click>Dekho <i class="ri-arrow-right-line"></i></a>
                        </span>
                    </div>
                <?php else: ?>
                    <div class="dadi-card-actions">
                        <span class="dadi-card-actions-row">
                            <a class="dadi-card-link" href="<?php echo e($_card['product_url']); ?>" data-dadi-click>Dekho <i class="ri-arrow-right-line"></i></a>
                        </span>
                    </div>
                <?php endif; ?>
                <p class="dadi-card-status" hidden data-dadi-status aria-live="polite"></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\dadi\_recs.blade.php ENDPATH**/ ?>