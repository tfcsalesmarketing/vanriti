<?php $__env->startSection('title', 'Checkout'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="vr-cart-item p-5 text-center">
                    <i class="bi bi-person-lock d-block mb-3" style="font-size:3rem;color:var(--vr-border);"></i>
                    <h4 class="fw-bold mb-2">Please log in to checkout</h4>
                    <p class="text-muted mb-4">You need an account to complete your purchase. It only takes a minute.</p>
                    <div class="d-flex justify-content-center gap-2">
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-vr">Log In</a>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-vr-outline">Create Account</a>
                    </div>
                    <div class="mt-4">
                        <a href="<?php echo e(route('cart.index')); ?>" class="small text-muted vr-link-underline">
                            <i class="bi bi-arrow-left me-1"></i> Back to Cart
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\checkout\guest.blade.php ENDPATH**/ ?>