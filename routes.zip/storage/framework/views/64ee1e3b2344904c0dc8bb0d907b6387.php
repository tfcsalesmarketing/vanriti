<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Categories</h5>
        <small class="text-muted"><?php echo e($categories->count()); ?> categories total</small>
    </div>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Category</a>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Slug</th>
                    <th class="text-center">Products</th>
                    <th>Status</th>
                    <th class="text-center">Sort</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $roots = $categories->whereNull('parent_id');
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $roots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e($cat->name); ?></td>
                        <td class="small text-muted"><?php echo e($cat->slug); ?></td>
                        <td class="text-center"><?php echo e($cat->products_count); ?></td>
                        <td>
                            <span class="badge <?php echo e($cat->status === 'active' ? 'badge-soft-success' : 'badge-soft-secondary'); ?>"><?php echo e(ucfirst($cat->status)); ?></span>
                        </td>
                        <td class="text-center"><?php echo e($cat->sort_order); ?></td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <a href="<?php echo e(route('admin.categories.edit', $cat->slug)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <form method="POST" action="<?php echo e(route('admin.categories.destroy', $cat->slug)); ?>" data-confirm="Delete this category?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php
                        $children = $categories->where('parent_id', $cat->id);
                    ?>
                    <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-semibold" style="padding-left: 2.5rem;"><i class="bi bi-arrow-return-right me-1 text-muted"></i><?php echo e($child->name); ?></td>
                            <td class="small text-muted"><?php echo e($child->slug); ?></td>
                            <td class="text-center"><?php echo e($child->products_count); ?></td>
                            <td>
                                <span class="badge <?php echo e($child->status === 'active' ? 'badge-soft-success' : 'badge-soft-secondary'); ?>"><?php echo e(ucfirst($child->status)); ?></span>
                            </td>
                            <td class="text-center"><?php echo e($child->sort_order); ?></td>
                            <td class="text-end">
                                <div class="d-flex gap-1 justify-content-end">
                                    <a href="<?php echo e(route('admin.categories.edit', $child->slug)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                    <form method="POST" action="<?php echo e(route('admin.categories.destroy', $child->slug)); ?>" data-confirm="Delete this category?">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php
                            $grandchildren = $categories->where('parent_id', $child->id);
                        ?>
                        <?php $__currentLoopData = $grandchildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-semibold" style="padding-left: 4.5rem;"><i class="bi bi-arrow-return-right me-1 text-muted"></i><i class="bi bi-arrow-return-right me-1 text-muted"></i><?php echo e($gc->name); ?></td>
                                <td class="small text-muted"><?php echo e($gc->slug); ?></td>
                                <td class="text-center"><?php echo e($gc->products_count); ?></td>
                                <td>
                                    <span class="badge <?php echo e($gc->status === 'active' ? 'badge-soft-success' : 'badge-soft-secondary'); ?>"><?php echo e(ucfirst($gc->status)); ?></span>
                                </td>
                                <td class="text-center"><?php echo e($gc->sort_order); ?></td>
                                <td class="text-end">
                                    <div class="d-flex gap-1 justify-content-end">
                                        <a href="<?php echo e(route('admin.categories.edit', $gc->slug)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                        <form method="POST" action="<?php echo e(route('admin.categories.destroy', $gc->slug)); ?>" data-confirm="Delete this category?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">No categories found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\categories\index.blade.php ENDPATH**/ ?>