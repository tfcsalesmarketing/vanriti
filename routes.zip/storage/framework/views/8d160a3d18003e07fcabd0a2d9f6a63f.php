<?php $__env->startSection('title', 'Journal'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-section" style="background:var(--vr-cream);">
    <div class="container text-center">
        <h1 class="vr-section-title mb-2">Journal</h1>
        <p class="vr-section-sub">Stories, guides and updates from Vanriti</p>
    </div>
</div>

<div class="vr-section">
    <div class="container">
        <?php if($featured): ?>
            <a href="<?php echo e(route('blog.show', $featured->slug)); ?>" class="text-decoration-none mb-4 d-block">
                <div class="row g-4 align-items-center mb-5">
                    <div class="col-lg-7">
                        <?php if($featured->featured_image): ?>
                            <div style="border-radius:var(--vr-radius);overflow:hidden;aspect-ratio:16/9;">
                                <img src="<?php echo e(image_url($featured->featured_image)); ?>" alt="<?php echo e($featured->title); ?>" style="width:100%;height:100%;object-fit:cover;">
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-5">
                        <?php if($featured->category): ?>
                            <span class="vr-pill-badge" style="background:var(--vr-green-soft);color:var(--vr-green);"><?php echo e($featured->category->name); ?></span>
                        <?php endif; ?>
                        <h2 class="mt-2 mb-3" style="font-weight:800;color:var(--vr-green-dark);"><?php echo e($featured->title); ?></h2>
                        <p class="text-muted mb-3" style="line-height:1.7;"><?php echo e(Str::limit($featured->excerpt, 200)); ?></p>
                        <div class="small text-muted mb-3">
                            <?php echo e($featured->published_at->format('M d, Y')); ?>

                            <?php if($featured->author): ?>
                                &middot; <?php echo e($featured->author->name); ?>

                            <?php endif; ?>
                        </div>
                        <span class="btn-vr">Read More</span>
                    </div>
                </div>
            </a>
        <?php endif; ?>

        <?php if($blogs->count() > ($featured ? 1 : 0)): ?>
            <div class="row g-4">
                <?php $__currentLoopData = $blogs->skip($featured ? 1 : 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="text-decoration-none">
                            <div class="vr-card">
                                <?php if($post->featured_image): ?>
                                    <div class="img-wrap" style="aspect-ratio:16/10;">
                                        <img src="<?php echo e(image_url($post->featured_image)); ?>" alt="<?php echo e($post->title); ?>">
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <?php if($post->category): ?>
                                        <span class="cat-name"><?php echo e($post->category->name); ?></span>
                                    <?php endif; ?>
                                    <h5 class="mt-1 mb-2" style="font-weight:700;color:var(--vr-green-dark);"><?php echo e($post->title); ?></h5>
                                    <p class="small text-muted mb-2" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;"><?php echo e($post->excerpt); ?></p>
                                    <div class="small text-muted mt-auto">
                                        <?php echo e($post->published_at->format('M d, Y')); ?>

                                        <?php if($post->author): ?>
                                            &middot; <?php echo e($post->author->name); ?>

                                        <?php endif; ?>
                                    </div>
                                    <span class="vr-link-underline small fw-semibold mt-2 d-inline-block" style="color:var(--vr-green);">Read More</span>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-4">
                <?php echo e($blogs->links('storefront.partials.pagination')); ?>

            </div>
        <?php elseif(!$featured): ?>
            <div class="vr-empty">
                <i class="bi bi-journal-text"></i>
                <h4 class="mt-3 fw-bold">No posts yet</h4>
                <p>We're working on something. Check back soon!</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\blog\index.blade.php ENDPATH**/ ?>