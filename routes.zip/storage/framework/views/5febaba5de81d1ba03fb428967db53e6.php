<?php $__env->startSection('title', 'Too Many Requests'); ?>
<?php $__env->startSection('code', '429'); ?>
<?php $__env->startSection('icon', 'bi bi-speedometer2'); ?>
<?php $__env->startSection('message', "You're going a little too fast. Please wait a moment and try again."); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="ad-btn-back"><i class="bi bi-speedometer2"></i> Back to Dashboard</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\errors\429.blade.php ENDPATH**/ ?>