<?php $__env->startSection('title', 'Create Dadi Product Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Create Dadi Product Profile</h5>
        <small class="text-muted">Author a draft of human-controlled product intelligence.</small>
    </div>
    <a href="<?php echo e(route('admin.dadi.product-profiles.index')); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo e(route('admin.dadi.product-profiles.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="card mb-3">
        <div class="card-body">
            <label class="form-label fw-semibold" for="product_id">Product</label>
            <select name="product_id" id="product_id" class="form-select <?php echo e($errors->has('content') ? 'is-invalid' : ''); ?>" required>
                <option value="">— Select product —</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>" <?php echo e(old('product_id') == $product->id ? 'selected' : ''); ?>>
                        <?php echo e($product->name); ?> (<?php echo e($product->sku); ?> — <?php echo e(ucfirst($product->status)); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('content')): ?>
                <div class="text-danger small mt-1"><?php echo e($errors->first('content')); ?></div>
            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('admin.dadi-product-profiles._form', ['profile' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <button type="submit" class="btn btn-dark"><i class="bi bi-plus-lg me-1"></i>Create Draft</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\dadi-product-profiles\create.blade.php ENDPATH**/ ?>