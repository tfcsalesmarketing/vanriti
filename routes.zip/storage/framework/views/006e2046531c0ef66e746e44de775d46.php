<?php $__env->startSection('title', 'Coupons'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Coupons</h5>
        <small class="text-muted"><?php echo e($coupons->total()); ?> coupons total</small>
    </div>
    <a href="<?php echo e(route('admin.coupons.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Coupon</a>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Code</th>
                    <th class="text-end">Discount</th>
                    <th class="text-end">Min Cart</th>
                    <th>Validity</th>
                    <th class="text-center">Usage</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $active = $coupon->is_active
                            && (!$coupon->expires_at || $coupon->expires_at->isFuture())
                            && (!$coupon->starts_at || $coupon->starts_at->isPast());
                        $expired = !$coupon->is_active ? null : (!$coupon->expires_at || $coupon->expires_at->isFuture());
                    ?>
                    <tr>
                        <td>
                            <div class="fw-semibold small"><?php echo e($coupon->code); ?></div>
                            <?php if($coupon->description): ?>
                                <div class="text-muted" style="font-size:0.75rem;"><?php echo e(Str::limit($coupon->description, 40)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <span class="fw-semibold small"><?php echo e($coupon->discount_type === 'percentage' ? $coupon->discount_value . '%' : format_price($coupon->discount_value)); ?></span>
                            <?php if($coupon->max_discount): ?>
                                <div class="text-muted" style="font-size:0.75rem;">max <?php echo e(format_price($coupon->max_discount)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="text-end small"><?php echo e($coupon->min_cart_value > 0 ? format_price($coupon->min_cart_value) : '—'); ?></td>
                        <td class="small text-muted">
                            <?php if($coupon->starts_at): ?>
                                <?php echo e($coupon->starts_at->format('d M Y')); ?>

                            <?php else: ?>
                                Anytime
                            <?php endif; ?>
                            <?php if($coupon->expires_at): ?>
                                <br>to <?php echo e($coupon->expires_at->format('d M Y')); ?>

                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php echo e($coupon->usages_count); ?>

                            <?php if($coupon->usage_limit): ?>
                                <span class="text-muted" style="font-size:0.75rem;">/ <?php echo e($coupon->usage_limit); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!$coupon->is_active): ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php elseif($coupon->expires_at && $coupon->expires_at->isPast()): ?>
                                <span class="badge bg-danger">Expired</span>
                            <?php elseif($coupon->starts_at && $coupon->starts_at->isFuture()): ?>
                                <span class="badge bg-info">Scheduled</span>
                            <?php else: ?>
                                <span class="badge bg-success">Active</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <a href="<?php echo e(route('admin.coupons.edit', $coupon->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <form method="POST" action="<?php echo e(route('admin.coupons.destroy', $coupon->id)); ?>" data-confirm="Delete this coupon?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No coupons found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($coupons->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\coupons\index.blade.php ENDPATH**/ ?>