<?php $__env->startSection('title', 'Forbidden'); ?>
<?php $__env->startSection('code', '403'); ?>
<?php $__env->startSection('icon', 'bi bi-ban'); ?>
<?php $__env->startSection('message', 'You don\'t have permission to access this page.'); ?>
<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\errors\403.blade.php ENDPATH**/ ?>