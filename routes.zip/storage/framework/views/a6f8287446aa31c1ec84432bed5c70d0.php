<?php $__env->startSection('title', 'Admins'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Admins</h5>
        <small class="text-muted"><?php echo e($admins->total()); ?> admins total</small>
    </div>
    <a href="<?php echo e(route('admin.admins.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Admin</a>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Admin</th>
                    <th>Contact</th>
                    <th>Roles</th>
                    <th>Status</th>
                    <th>Last Login</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="rounded bg-light d-flex align-items-center justify-content-center fw-bold text-muted" style="width:40px;height:40px;">
                                    <?php echo e(strtoupper(substr($admin->name, 0, 1))); ?>

                                </div>
                                <div>
                                    <div class="fw-semibold small"><?php echo e($admin->name); ?></div>
                                    <?php if($admin->is_super_admin): ?>
                                        <span class="badge badge-soft-warning">Super Admin</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="small"><?php echo e($admin->email); ?></div>
                            <div class="small text-muted"><?php echo e($admin->phone ?: '—'); ?></div>
                        </td>
                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $admin->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <span class="badge badge-soft-primary"><?php echo e($role->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <span class="badge badge-soft-secondary">No roles</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?php echo e($admin->status === 'active' ? 'badge-soft-success' : ($admin->status === 'suspended' ? 'badge-soft-danger' : 'badge-soft-secondary')); ?>"><?php echo e(ucfirst($admin->status)); ?></span>
                        </td>
                        <td class="small text-muted"><?php echo e($admin->last_login_at ? $admin->last_login_at->format('d M Y, h:i A') : '—'); ?></td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <a href="<?php echo e(route('admin.admins.edit', $admin->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <?php if(!$admin->is_super_admin && $admin->id !== auth('admin')->id()): ?>
                                    <form method="POST" action="<?php echo e(route('admin.admins.destroy', $admin->id)); ?>" data-confirm="Delete this admin?">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">No admins found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($admins->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\admins\index.blade.php ENDPATH**/ ?>