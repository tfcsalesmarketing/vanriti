<?php
    $admin = $admin ?? null;
?>

<div class="row g-3">
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-header fw-semibold">Account Information</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control form-control-sm" value="<?php echo e(old('name', $admin->name ?? '')); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control form-control-sm" value="<?php echo e(old('email', $admin->email ?? '')); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Phone</label>
                        <input type="text" name="phone" class="form-control form-control-sm" value="<?php echo e(old('phone', $admin->phone ?? '')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select form-select-sm" required>
                            <option value="active" <?php echo e(old('status', $admin->status ?? 'active') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(old('status', $admin->status ?? '') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                            <option value="suspended" <?php echo e(old('status', $admin->status ?? '') === 'suspended' ? 'selected' : ''); ?>>Suspended</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Password <?php if(!$admin): ?><span class="text-danger">*</span><?php endif; ?></label>
                        <input type="password" name="password" class="form-control form-control-sm" <?php if(!$admin): ?> required <?php endif; ?>>
                        <?php if($admin): ?>
                            <div class="form-text">Leave blank to keep the current password.</div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Confirm Password</label>
                        <input type="password" name="password_confirmation" class="form-control form-control-sm">
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Roles <span class="text-danger">*</span></div>
            <div class="card-body">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 col-lg-4 mb-2">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" name="roles[]" value="<?php echo e($role->id); ?>" id="role_<?php echo e($role->id); ?>"
                                    <?php echo e(in_array($role->id, old('roles', $adminRoleIds ?? [])) ? 'checked' : ''); ?>>
                                <label class="form-check-label small" for="role_<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-muted small">No roles available.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex gap-2 mt-3">
    <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-check-lg me-1"></i><?php echo e($admin ? 'Save Admin' : 'Create Admin'); ?></button>
    <a href="<?php echo e(route('admin.admins.index')); ?>" class="btn btn-sm btn-outline-secondary">Cancel</a>
</div><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\admins\_form.blade.php ENDPATH**/ ?>