<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold"><?php echo e($product->name); ?></h5>
        <small class="text-muted">SKU: <?php echo e($product->sku ?: '—'); ?> &middot; Slug: <?php echo e($product->slug); ?></small>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('admin.products.edit', $product->slug)); ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil me-1"></i>Edit</a>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-sm btn-outline-secondary">Back</a>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-header fw-semibold">Basic Information</div>
            <div class="card-body">
                <div class="row g-2 small">
                    <div class="col-md-6"><strong>Name:</strong> <?php echo e($product->name); ?></div>
                    <div class="col-md-6">
                        <strong>Status:</strong>
                        <?php $sc = ['draft' => 'secondary', 'active' => 'success', 'inactive' => 'danger']; ?>
                        <span class="badge bg-<?php echo e($sc[$product->status] ?? 'secondary'); ?>"><?php echo e(ucfirst($product->status)); ?></span>
                    </div>
                    <div class="col-12"><strong>Short Description:</strong> <?php echo e($product->short_description ?: '—'); ?></div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Pricing</div>
            <div class="card-body">
                <div class="row g-2 small">
                    <div class="col-md-3"><strong>MRP:</strong> <?php echo e(format_price($product->mrp)); ?></div>
                    <div class="col-md-3"><strong>Selling:</strong> <?php echo e(format_price($product->selling_price)); ?></div>
                    <div class="col-md-3"><strong>GST:</strong> <?php echo e($product->gst_rate); ?>%</div>
                    <div class="col-md-3"><strong>Discount:</strong> <?php echo e($product->discount_percent); ?>%</div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Stock</div>
            <div class="card-body">
                <div class="row g-2 small mb-3">
                    <div class="col-md-4"><strong>Stock on Hand:</strong> <?php echo e($inventory->stock_on_hand ?? $product->stock); ?></div>
                    <div class="col-md-4"><strong>Reserved:</strong> <?php echo e($inventory->reserved ?? 0); ?></div>
                    <div class="col-md-4"><strong>Low Stock Threshold:</strong> <?php echo e($product->low_stock_threshold); ?></div>
                </div>
                <div class="d-flex gap-2 mb-2">
                    <?php if($product->isOutOfStock()): ?>
                        <span class="badge bg-danger">Out of Stock</span>
                    <?php elseif($product->isLowStock()): ?>
                        <span class="badge bg-warning text-dark">Low Stock</span>
                    <?php else: ?>
                        <span class="badge bg-success">In Stock</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Categories</div>
            <div class="card-body small">
                <?php $__empty_1 = true; $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <span class="badge bg-light text-dark border me-1 mb-1"><?php echo e($cat->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="text-muted">No categories assigned.</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Flags</div>
            <div class="card-body">
                <?php if($product->is_featured): ?><span class="badge bg-primary me-1">Featured</span><?php endif; ?>
                <?php if($product->is_bestseller): ?><span class="badge bg-warning text-dark me-1">Bestseller</span><?php endif; ?>
                <?php if($product->is_new_arrival): ?><span class="badge bg-info me-1">New Arrival</span><?php endif; ?>
                <?php if(!$product->is_featured && !$product->is_bestseller && !$product->is_new_arrival): ?><span class="text-muted small">No flags set.</span><?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header fw-semibold">Images</div>
            <div class="card-body">
                <?php $images = $product->images; ?>
                <?php if($images->count()): ?>
                    <div class="row g-2">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-4">
                                <img src="<?php echo e(image_url($img->image_path)); ?>" alt="<?php echo e($img->alt_text); ?>" class="rounded border w-100" style="height:80px;object-fit:cover;">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted small mb-0">No images.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Update Stock</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.products.stock', $product->slug)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-2">
                        <select name="type" class="form-select form-select-sm" required>
                            <option value="purchase">Purchase</option>
                            <option value="sale">Sale</option>
                            <option value="adjustment">Adjustment</option>
                            <option value="return">Return</option>
                            <option value="reversal">Reversal</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <input type="number" name="quantity" class="form-control form-control-sm" placeholder="Quantity" min="1" required>
                    </div>
                    <div class="mb-2">
                        <input type="text" name="reason" class="form-control form-control-sm" placeholder="Reason (required for adjustment)">
                    </div>
                    <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-arrow-repeat me-1"></i>Update Stock</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header fw-semibold d-flex justify-content-between align-items-center">
        <span>Variants</span>
        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#addVariantForm"><i class="bi bi-plus"></i> Add</button>
    </div>
    <div class="card-body">
        <div id="addVariantForm" class="collapse mb-3">
            <form method="POST" action="<?php echo e(route('admin.products.variants.store', $product->slug)); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-2">
                    <div class="col-md-2">
                        <input type="text" name="name" class="form-control form-control-sm" placeholder="Name">
                    </div>
                    <div class="col-md-2">
                        <input type="text" name="sku" class="form-control form-control-sm" placeholder="SKU">
                    </div>
                    <div class="col-md-2">
                        <input type="number" step="0.01" name="mrp" class="form-control form-control-sm" placeholder="MRP" required>
                    </div>
                    <div class="col-md-2">
                        <input type="number" step="0.01" name="selling_price" class="form-control form-control-sm" placeholder="Selling Price" required>
                    </div>
                    <div class="col-md-1">
                        <input type="number" name="stock" class="form-control form-control-sm" placeholder="Stock" value="0">
                    </div>
                    <div class="col-md-1">
                        <input type="number" step="0.01" name="gst_rate" class="form-control form-control-sm" placeholder="GST%" value="0">
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-sm btn-primary">Save</button>
                    </div>
                </div>
            </form>
        </div>

        <?php $variants = $product->variants; ?>
        <?php if($variants->count()): ?>
            <div class="table-responsive">
                <table class="table table-sm table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>SKU</th>
                            <th class="text-end">MRP</th>
                            <th class="text-end">Price</th>
                            <th class="text-end">Stock</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="small"><?php echo e($variant->name ?: '—'); ?></td>
                                <td class="small"><?php echo e($variant->sku ?: '—'); ?></td>
                                <td class="text-end small"><?php echo e(format_price($variant->mrp)); ?></td>
                                <td class="text-end small"><?php echo e(format_price($variant->selling_price)); ?></td>
                                <td class="text-end small"><?php echo e($variant->stock); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($variant->status === 'active' ? 'success' : 'secondary'); ?>"><?php echo e(ucfirst($variant->status)); ?></span>
                                </td>
                                <td class="text-end">
                                    <div class="d-flex gap-1 justify-content-end">
                                        <form method="POST" action="<?php echo e(route('admin.products.variants.update', $variant->id)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="name" value="<?php echo e($variant->name); ?>">
                                            <input type="hidden" name="sku" value="<?php echo e($variant->sku); ?>">
                                            <input type="hidden" name="mrp" value="<?php echo e($variant->mrp); ?>">
                                            <input type="hidden" name="selling_price" value="<?php echo e($variant->selling_price); ?>">
                                            <input type="hidden" name="stock" value="<?php echo e($variant->stock); ?>">
                                            <input type="hidden" name="gst_rate" value="<?php echo e($variant->gst_rate); ?>">
                                            <input type="hidden" name="status" value="<?php echo e($variant->status); ?>">
                                        </form>
                                        <form method="POST" action="<?php echo e(route('admin.products.variants.destroy', $variant->id)); ?>" class="d-inline" data-confirm="Delete variant?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted small mb-0">No variants.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\products\show.blade.php ENDPATH**/ ?>