<?php $__env->startSection('title', 'Unauthorized'); ?>
<?php $__env->startSection('code', '401'); ?>
<?php $__env->startSection('icon', 'bi bi-shield-lock'); ?>
<?php $__env->startSection('message', 'You are not authorized to view this page. If you believe this is a mistake, please sign in and try again.'); ?>
<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/errors/401.blade.php ENDPATH**/ ?>