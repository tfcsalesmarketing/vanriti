<?php $__env->startSection('title', 'Activity Log'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Activity Log</h5>
        <small class="text-muted"><?php echo e($logs->total()); ?> activities</small>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.activities.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small fw-semibold mb-1">Search</label>
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search description / action..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold mb-1">Action</label>
                <select name="action" class="form-select form-select-sm">
                    <option value="">All actions</option>
                    <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($action); ?>" <?php echo e(request('action') === $action ? 'selected' : ''); ?>><?php echo e($action); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold mb-1">From</label>
                <input type="date" name="date_from" class="form-control form-control-sm" value="<?php echo e(request('date_from')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold mb-1">To</label>
                <input type="date" name="date_to" class="form-control form-control-sm" value="<?php echo e(request('date_to')); ?>">
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-dark"><i class="bi bi-search me-1"></i>Filter</button>
                <a href="<?php echo e(route('admin.activities.index')); ?>" class="btn btn-sm btn-outline-secondary">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Actor</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>Description</th>
                    <th>IP</th>
                    <th>When</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $actorName = $log->actor_type === \App\Models\Admin::class
                            ? ($log->actor->name ?? 'System')
                            : ($log->actor->name ?? 'System');
                        $entityName = $log->entity ? class_basename($log->entity) . ' #' . $log->entity_id : '—';
                    ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="rounded bg-light d-flex align-items-center justify-content-center fw-bold text-muted" style="width:32px;height:32px;">
                                    <?php echo e(strtoupper(substr($actorName, 0, 1))); ?>

                                </div>
                                <span class="small fw-semibold"><?php echo e($actorName); ?></span>
                            </div>
                        </td>
                        <td>
                            <span class="badge <?php echo e(in_array($log->action, ['created', 'approved', 'activated']) ? 'badge-soft-success' : (in_array($log->action, ['deleted', 'rejected', 'suspended']) ? 'badge-soft-danger' : 'badge-soft-primary')); ?>"><?php echo e(ucfirst($log->action)); ?></span>
                        </td>
                        <td class="small text-muted"><?php echo e($entityName); ?></td>
                        <td>
                            <div class="small"><?php echo e($log->description ?: '—'); ?></div>
                            <?php if(!empty($log->old_values) || !empty($log->new_values)): ?>
                                <button type="button" class="btn btn-link btn-sm p-0 small" data-bs-toggle="collapse" data-bs-target="#logDetails_<?php echo e($log->id); ?>">Show details</button>
                                <div class="collapse mt-2" id="logDetails_<?php echo e($log->id); ?>">
                                    <div class="row g-2">
                                        <?php if(!empty($log->old_values)): ?>
                                            <div class="col-md-6">
                                                <div class="small text-muted fw-semibold mb-1">Old values</div>
                                                <pre class="bg-light rounded p-2 mb-0 small"><?php echo e(json_encode($log->old_values, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)); ?></pre>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(!empty($log->new_values)): ?>
                                            <div class="col-md-6">
                                                <div class="small text-muted fw-semibold mb-1">New values</div>
                                                <pre class="bg-light rounded p-2 mb-0 small"><?php echo e(json_encode($log->new_values, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)); ?></pre>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="small text-muted"><?php echo e($log->ip_address ?: '—'); ?></td>
                        <td class="small text-muted"><?php echo e($log->created_at->format('d M Y, h:i A')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">No activities found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($logs->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\activities\index.blade.php ENDPATH**/ ?>