<?php $__env->startSection('title', 'Order '.$order->order_number); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Order <?php echo e($order->order_number); ?></h5>
        <small class="text-muted">Placed on <?php echo e($order->created_at->format('d M Y, h:i A')); ?></small>
    </div>
    <div class="d-flex gap-2">
        <?php $oClass = ['cancelled'=>'danger','failed'=>'danger','delivered'=>'success','shipped'=>'info','out_for_delivery'=>'info','pending'=>'secondary','confirmed'=>'primary','processing'=>'warning','packed'=>'warning']; ?>
        <span class="badge bg-<?php echo e($oClass[$order->order_status] ?? 'secondary'); ?> align-self-center"><?php echo e(ucwords(str_replace('_', ' ', $order->order_status))); ?></span>
        <a href="<?php echo e(route('admin.orders.edit', $order)); ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil me-1"></i>Edit</a>
        <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-outline-secondary">Back</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small">Order Number</div>
                <div class="fw-bold"><?php echo e($order->order_number); ?></div>
                <div class="text-muted small mt-2">Date</div>
                <div class="fw-semibold small"><?php echo e($order->created_at->format('d M Y, h:i A')); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small">Payment</div>
                <div class="fw-bold small"><?php echo e(ucwords(str_replace('_', ' ', $order->payment_status))); ?></div>
                <div class="text-muted small mt-2">Method</div>
                <div class="fw-semibold small text-uppercase"><?php echo e($order->payment_method); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small">Grand Total</div>
                <div class="fw-bold"><?php echo e(format_price($order->grand_total)); ?></div>
                <div class="text-muted small mt-2">Paid / Due</div>
                <div class="fw-semibold small"><?php echo e(format_price($order->amount_paid)); ?> / <?php echo e(format_price($order->amount_due)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small">Customer</div>
                <div class="fw-bold small"><?php echo e($order->user?->name ?: $order->billing_name); ?></div>
                <div class="text-muted small"><?php echo e($order->user?->email); ?></div>
                <div class="text-muted small"><?php echo e($order->user?->phone ?: $order->billing_mobile); ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header">Billing Address</div>
            <div class="card-body small">
                <div class="fw-semibold"><?php echo e($order->billing_name); ?></div>
                <div class="text-muted"><?php echo e($order->billing_address_line1); ?></div>
                <?php if($order->billing_address_line2): ?>
                    <div class="text-muted"><?php echo e($order->billing_address_line2); ?></div>
                <?php endif; ?>
                <?php if($order->billing_landmark): ?>
                    <div class="text-muted"><?php echo e($order->billing_landmark); ?></div>
                <?php endif; ?>
                <div class="text-muted"><?php echo e($order->billing_city); ?>, <?php echo e($order->billing_state); ?> - <?php echo e($order->billing_pincode); ?></div>
                <div class="text-muted"><?php echo e($order->billing_country); ?></div>
                <div class="text-muted mt-2">Ph: <?php echo e($order->billing_mobile); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header">Shipping Address</div>
            <div class="card-body small">
                <div class="fw-semibold"><?php echo e($order->shipping_name); ?></div>
                <div class="text-muted"><?php echo e($order->shipping_address_line1); ?></div>
                <?php if($order->shipping_address_line2): ?>
                    <div class="text-muted"><?php echo e($order->shipping_address_line2); ?></div>
                <?php endif; ?>
                <?php if($order->shipping_landmark): ?>
                    <div class="text-muted"><?php echo e($order->shipping_landmark); ?></div>
                <?php endif; ?>
                <div class="text-muted"><?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?> - <?php echo e($order->shipping_pincode); ?></div>
                <div class="text-muted"><?php echo e($order->shipping_country); ?></div>
                <div class="text-muted mt-2">Ph: <?php echo e($order->shipping_mobile); ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header">Items</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th class="text-center">Qty</th>
                    <th class="text-end">Unit Price</th>
                    <th class="text-end">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php if($item->image): ?>
                                    <?php if(str_starts_with($item->image, 'http')): ?>
                                        <img src="<?php echo e($item->image); ?>" alt="" class="rounded" width="40" height="40" style="object-fit:cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(image_url($item->image)); ?>" alt="" class="rounded" width="40" height="40" style="object-fit:cover;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:40px;height:40px;"><i class="bi bi-image text-muted"></i></div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-semibold small"><?php echo e($item->product_name); ?></div>
                                    <div class="text-muted small"><?php echo e($item->variant_name ?: ($item->sku ?: '')); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="text-center small"><?php echo e($item->quantity); ?></td>
                        <td class="text-end small"><?php echo e(format_price($item->unit_price)); ?></td>
                        <td class="text-end fw-semibold small"><?php echo e(format_price($item->total_price)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-header">Totals</div>
            <div class="card-body py-2 small">
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Subtotal</span><span><?php echo e(format_price($order->subtotal)); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Discount</span><span><?php echo e(format_price($order->discount_amount)); ?></span></div>
                <?php if($order->coupon_discount > 0): ?>
                    <div class="d-flex justify-content-between py-1">
                        <span class="text-muted">
                            Coupon<?php echo e($order->coupon_code ? ' ('.$order->coupon_code.')' : ''); ?>

                            <?php if($order->coupon_type || $order->coupon_value !== null): ?>
                                <span class="d-block text-muted" style="font-size:0.8em;"><?php echo e(ucfirst((string) $order->coupon_type)); ?><?php echo e($order->coupon_value !== null ? ' '.format_price($order->coupon_value) : ''); ?></span>
                            <?php endif; ?>
                        </span>
                        <span>- <?php echo e(format_price($order->coupon_discount)); ?></span>
                    </div>
                <?php endif; ?>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Taxable Value</span><span><?php echo e(format_price($order->taxable_value)); ?></span></div>
                <?php if($order->isIntraState()): ?>
                    <div class="d-flex justify-content-between py-1"><span class="text-muted">CGST<?php echo e($order->uniformGstRate() !== null ? ' ('.number_format($order->uniformGstRate() / 2, 1, '.', '').'%)' : ''); ?></span><span><?php echo e(format_price($order->cgst_amount)); ?></span></div>
                    <div class="d-flex justify-content-between py-1"><span class="text-muted">SGST<?php echo e($order->uniformGstRate() !== null ? ' ('.number_format($order->uniformGstRate() / 2, 1, '.', '').'%)' : ''); ?></span><span><?php echo e(format_price($order->sgst_amount)); ?></span></div>
                <?php else: ?>
                    <div class="d-flex justify-content-between py-1"><span class="text-muted">IGST<?php echo e($order->uniformGstRate() !== null ? ' ('.(float) $order->uniformGstRate().'%)' : ''); ?></span><span><?php echo e(format_price($order->igst_amount)); ?></span></div>
                <?php endif; ?>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Shipping</span><span><?php echo e(format_price($order->shipping_charge)); ?></span></div>
                <hr class="my-1">
                <div class="d-flex justify-content-between py-1 fw-bold"><span>Grand Total</span><span><?php echo e(format_price($order->grand_total)); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Paid</span><span><?php echo e(format_price($order->amount_paid)); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Due</span><span class="fw-semibold"><?php echo e(format_price($order->amount_due)); ?></span></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-header">Status History</div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $order->statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex gap-2 mb-2 small">
                        <i class="bi bi-circle-fill mt-1" style="font-size:0.5rem;"></i>
                        <div>
                            <div class="fw-semibold"><?php echo e(ucwords(str_replace('_', ' ', $history->status))); ?></div>
                            <div class="text-muted" style="font-size:0.75rem;"><?php echo e($history->created_at->format('d M Y, h:i A')); ?></div>
                            <?php if($history->description): ?>
                                <div class="text-muted"><?php echo e($history->description); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-muted small">No status history.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-header">Payments</div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $order->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between small mb-2">
                        <div>
                            <span class="badge bg-<?php echo e($payment->status === 'paid' ? 'success' : 'secondary'); ?>"><?php echo e(ucwords($payment->status)); ?></span>
                            <div class="text-muted mt-1"><?php echo e($payment->method ?: 'N/A'); ?> <?php if($payment->payment_reference): ?> · <?php echo e($payment->payment_reference); ?> <?php endif; ?></div>
                        </div>
                        <div class="fw-semibold"><?php echo e(format_price($payment->amount)); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-muted small">No payments recorded.</div>
                <?php endif; ?>
                <?php if($order->shipments->count()): ?>
                    <div class="border-top pt-2 mt-2">
                        <div class="fw-semibold small mb-1">Shipments</div>
                        <?php $__currentLoopData = $order->shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="small text-muted">
                                <a href="<?php echo e(route('admin.shipments.show', $shipment)); ?>" class="text-decoration-none">Shipment #<?php echo e($shipment->id); ?></a>
                                <?php if($shipment->tracking_number): ?> · <?php echo e($shipment->tracking_number); ?> <?php endif; ?>
                                · <span class="badge bg-secondary"><?php echo e($shipment->status); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if($order->internal_notes): ?>
    <div class="card">
        <div class="card-header">Internal Notes</div>
        <div class="card-body small text-muted" style="white-space:pre-line;"><?php echo e($order->internal_notes); ?></div>
    </div>
<?php endif; ?>


<?php if(setting('shipmojo_enabled')): ?>
<?php
    $shipment = $order->shipments->first();
    $pushed   = $shipment?->isPushedToShipMojo();
    $hasAwb   = $shipment?->hasAwb();
?>
<div class="card mt-3">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span class="fw-semibold">
            <i class="bi bi-truck me-1 text-success"></i> ShipMojo Shipping
        </span>
        <div class="d-flex align-items-center gap-2">
            <?php if($pushed): ?>
                <span class="badge bg-success-subtle text-success border border-success-subtle">
                    <i class="bi bi-check-circle me-1"></i>Pushed
                </span>
            <?php endif; ?>
            <?php if($hasAwb): ?>
                <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                    AWB: <?php echo e($shipment->awb_number); ?>

                </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">

        
        <?php if($shipment && $pushed): ?>
        <div class="row g-2 mb-3 text-center small">
            <div class="col">
                <div class="text-muted">ShipMojo Ref</div>
                <div class="fw-semibold"><?php echo e($shipment->shipmojo_reference_id ?? '—'); ?></div>
            </div>
            <div class="col">
                <div class="text-muted">Courier</div>
                <div class="fw-semibold"><?php echo e($shipment->courier ?? '—'); ?></div>
            </div>
            <div class="col">
                <div class="text-muted">AWB</div>
                <div class="fw-semibold"><?php echo e($shipment->awb_number ?? '—'); ?></div>
            </div>
            <div class="col">
                <div class="text-muted">LR Number</div>
                <div class="fw-semibold"><?php echo e($shipment->lr_number ?? '—'); ?></div>
            </div>
            <div class="col">
                <div class="text-muted">Status</div>
                <div class="fw-semibold text-capitalize"><?php echo e(str_replace('_', ' ', $shipment->status ?? '—')); ?></div>
            </div>
            <div class="col">
                <div class="text-muted">Pushed At</div>
                <div class="fw-semibold"><?php echo e($shipment->shipmojo_pushed_at?->format('d M, h:i A') ?? '—'); ?></div>
            </div>
        </div>
        <?php endif; ?>

        
        <div class="d-flex flex-wrap gap-2">

            
            <?php if(! $pushed): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.shipmojo.push', $order)); ?>" class="d-inline" data-confirm="Push order <?php echo e($order->order_number); ?> to ShipMojo?">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-success">
                    <i class="bi bi-cloud-upload me-1"></i> Push to ShipMojo
                </button>
            </form>
            <?php else: ?>
            <form method="POST" action="<?php echo e(route('admin.orders.shipmojo.push', $order)); ?>" class="d-inline" data-confirm="Re-push order to ShipMojo?">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-clockwise me-1"></i> Re-push
                </button>
            </form>
            <?php endif; ?>

            
            <?php if($pushed && ! $hasAwb): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.shipmojo.auto-assign', $order)); ?>" class="d-inline" data-confirm="Auto-assign courier for this order?">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-primary">
                    <i class="bi bi-lightning me-1"></i> Auto-Assign Courier
                </button>
            </form>
            <?php endif; ?>

            
            <?php if($pushed && ! $hasAwb): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.shipmojo.schedule-pickup', $order)); ?>" class="d-inline" data-confirm="Schedule pickup for this order?">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-info text-white">
                    <i class="bi bi-calendar-check me-1"></i> Schedule Pickup
                </button>
            </form>
            <?php endif; ?>

            
            <?php if($hasAwb): ?>
            <a href="<?php echo e(route('admin.orders.shipmojo.label', $order)); ?>"
               class="btn btn-sm btn-dark" target="_blank">
                <i class="bi bi-printer me-1"></i> Download Label
            </a>
            <?php endif; ?>

            
            <?php if($hasAwb): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.shipmojo.track', $order)); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-arrow-repeat me-1"></i> Sync Tracking
                </button>
            </form>
            <?php endif; ?>

            
            <?php if($hasAwb && ! in_array($shipment->status, ['delivered', 'returned'])): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.shipmojo.cancel', $order)); ?>" class="d-inline" data-confirm="Cancel this shipment in ShipMojo? This cannot be undone.">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-outline-danger">
                    <i class="bi bi-x-circle me-1"></i> Cancel Shipment
                </button>
            </form>
            <?php endif; ?>

        </div>

        
        <?php if($shipment && $shipment->trackingEvents->count()): ?>
        <hr class="my-3">
        <div class="small fw-semibold mb-2 text-muted">Tracking Events</div>
        <ul class="list-group list-group-flush">
            <?php $__currentLoopData = $shipment->trackingEvents->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item px-0 py-1 small">
                <span class="badge bg-secondary me-2"><?php echo e(ucwords(str_replace('_',' ',$event->status))); ?></span>
                <?php echo e($event->description); ?>

                <?php if($event->location): ?> · <em><?php echo e($event->location); ?></em> <?php endif; ?>
                <span class="text-muted float-end"><?php echo e(\Carbon\Carbon::parse($event->event_date)->format('d M, H:i')); ?></span>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

    </div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\orders\show.blade.php ENDPATH**/ ?>