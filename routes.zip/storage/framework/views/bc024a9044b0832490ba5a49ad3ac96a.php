<?php $__env->startSection('title', 'Something Went Wrong'); ?>
<?php $__env->startSection('code', 'Error'); ?>
<?php $__env->startSection('icon', 'bi bi-exclamation-triangle'); ?>
<?php $__env->startSection('message', 'An unexpected error occurred in the admin panel. Please try again.'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="ad-btn-back"><i class="bi bi-speedometer2"></i> Back to Dashboard</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\errors\generic.blade.php ENDPATH**/ ?>