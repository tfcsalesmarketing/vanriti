<?php $__env->startSection('title', 'Shipment #'.$shipment->id); ?>

<?php $__env->startSection('content'); ?>
<?php
    $classes = ['delivered'=>'success','shipped'=>'info','out_for_delivery'=>'info','packed'=>'primary','pending'=>'secondary','returning'=>'warning','returned'=>'secondary','failed'=>'danger'];
    $trackClasses = ['delivered'=>'success','shipped'=>'info','out_for_delivery'=>'info','packed'=>'primary','failed'=>'danger','returning'=>'warning'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Shipment #<?php echo e($shipment->id); ?></h5>
        <small class="text-muted">Created on <?php echo e($shipment->created_at->format('d M Y, h:i A')); ?></small>
    </div>
    <div class="d-flex gap-2">
        <span class="badge bg-<?php echo e($classes[$shipment->status] ?? 'secondary'); ?> align-self-center"><?php echo e(ucwords(str_replace('_', ' ', $shipment->status))); ?></span>
        <a href="<?php echo e(route('admin.shipments.index')); ?>" class="btn btn-sm btn-outline-secondary">Back</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header">Shipment Info</div>
            <div class="card-body small">
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Courier</span><span><?php echo e($shipment->courier ?: '—'); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Tracking #</span><span><?php echo e($shipment->tracking_number ?: '—'); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">AWB #</span><span><?php echo e($shipment->awb_number ?: '—'); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Method</span><span><?php echo e($shipment->shipping_method ?: '—'); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Weight</span><span><?php echo e($shipment->weight ? $shipment->weight.' kg' : '—'); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Shipped At</span><span><?php echo e($shipment->shipped_at?->format('d M Y, h:i A') ?: '—'); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Est. Delivery</span><span><?php echo e($shipment->estimated_delivery?->format('d M Y') ?: '—'); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Delivered At</span><span><?php echo e($shipment->delivered_at?->format('d M Y, h:i A') ?: '—'); ?></span></div>
                <?php if($shipment->notes): ?>
                    <div class="text-muted mt-2">Notes</div>
                    <div><?php echo e($shipment->notes); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header">Order</div>
            <div class="card-body small">
                <?php if($shipment->order): ?>
                    <a href="<?php echo e(route('admin.orders.show', $shipment->order)); ?>" class="text-decoration-none fw-semibold"><?php echo e($shipment->order->order_number); ?></a>
                    <div class="text-muted">Customer: <?php echo e($shipment->order->user?->name ?: $shipment->order->billing_name); ?></div>
                    <div class="text-muted">Total: <?php echo e(format_price($shipment->order->grand_total)); ?></div>
                    <div class="text-muted">Status: <span class="badge bg-secondary"><?php echo e(ucwords(str_replace('_', ' ', $shipment->order->order_status))); ?></span></div>
                <?php else: ?>
                    <div class="text-muted">Order not found.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header">Add Tracking Event</div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.shipments.tracking', $shipment)); ?>" class="row g-2">
            <?php echo csrf_field(); ?>
            <div class="col-md-2">
                <label class="form-label small text-muted">Status</label>
                <select name="status" class="form-select form-select-sm" required>
                    <?php $__currentLoopData = ['packed', 'shipped', 'out_for_delivery', 'delivered', 'failed', 'returning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(request('status') === $status ? 'selected' : ''); ?>><?php echo e(ucwords(str_replace('_', ' ', $status))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small text-muted">Description</label>
                <input type="text" name="description" class="form-control form-control-sm" maxlength="500" placeholder="e.g. Package out for delivery">
            </div>
            <div class="col-md-2">
                <label class="form-label small text-muted">Location</label>
                <input type="text" name="location" class="form-control form-control-sm" maxlength="255" placeholder="e.g. New Delhi">
            </div>
            <div class="col-md-2">
                <label class="form-label small text-muted">Event Date</label>
                <input type="datetime-local" name="event_date" class="form-control form-control-sm" value="<?php echo e(now()->format('Y-m-d\TH:i')); ?>" required>
            </div>
            <div class="col-md-2">
                <label class="form-label small text-muted">Est. Delivery</label>
                <input type="datetime-local" name="estimated_delivery" class="form-control form-control-sm" value="<?php echo e($shipment->estimated_delivery?->format('Y-m-d\TH:i')); ?>">
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <button type="submit" class="btn btn-sm btn-primary w-100">Add</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">Tracking Timeline</div>
    <div class="card-body">
        <?php $__empty_1 = true; $__currentLoopData = $shipment->trackingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="d-flex gap-2 mb-3 small">
                <div class="d-flex flex-column align-items-center">
                    <i class="bi bi-circle-fill text-<?php echo e($trackClasses[$event->status] ?? 'secondary'); ?>" style="font-size:0.5rem;"></i>
                </div>
                <div>
                    <div class="fw-semibold"><?php echo e(ucwords(str_replace('_', ' ', $event->status))); ?></div>
                    <div class="text-muted" style="font-size:0.75rem;"><?php echo e($event->event_date?->format('d M Y, h:i A')); ?></div>
                    <?php if($event->location): ?><div class="text-muted"><?php echo e($event->location); ?></div><?php endif; ?>
                    <?php if($event->description): ?><div><?php echo e($event->description); ?></div><?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-muted small">No tracking events yet.</div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\shipments\show.blade.php ENDPATH**/ ?>