<?php $__env->startSection('title', 'Customer: ' . $user->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0 fw-bold">Customer Details</h5>
    <a href="<?php echo e(route('admin.customers.index')); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <div class="d-flex align-items-center gap-3">
            <span class="avatar-circle bg-primary text-white" style="width:60px;height:60px;font-size:1.5rem;"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></span>
            <div>
                <h5 class="mb-1 fw-bold"><?php echo e($user->name); ?></h5>
                <div class="text-muted small"><?php echo e($user->email); ?><?php echo e($user->phone ? ' | ' . $user->phone : ''); ?></div>
                <div class="mt-1">
                    <span class="badge <?php echo e($user->status === 'active' ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e(ucfirst($user->status)); ?></span>
                    <span class="badge bg-light text-dark">Joined <?php echo e($user->created_at->format('d M Y')); ?></span>
                </div>
            </div>
            <div class="ms-auto">
                <form method="POST" action="<?php echo e(route('admin.customers.toggle', $user->id)); ?>" data-confirm="<?php echo e($user->status === 'active' ? 'Deactivate' : 'Activate'); ?> this customer?">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-<?php echo e($user->status === 'active' ? 'warning' : 'success'); ?>">
                        <i class="bi <?php echo e($user->status === 'active' ? 'bi-person-x' : 'bi-person-check'); ?> me-1"></i><?php echo e($user->status === 'active' ? 'Deactivate' : 'Activate'); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <h4 class="fw-bold mb-0"><?php echo e($stats['total_orders']); ?></h4>
                <div class="text-muted small">Total Orders</div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <h4 class="fw-bold mb-0"><?php echo e(format_price($stats['total_spent'])); ?></h4>
                <div class="text-muted small">Total Spent</div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <h4 class="fw-bold mb-0"><?php echo e($stats['last_order_date'] ? $stats['last_order_date']->format('d M Y') : '—'); ?></h4>
                <div class="text-muted small">Last Order</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-5">
        <div class="card mb-3">
            <div class="card-header fw-semibold">Addresses</div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border rounded p-3 mb-2">
                        <div class="fw-semibold small"><?php echo e($address->full_name); ?></div>
                        <div class="small text-muted">
                            <?php echo e($address->address_line1); ?><?php echo e($address->address_line2 ? ', ' . $address->address_line2 : ''); ?><br>
                            <?php echo e($address->landmark ? $address->landmark . ', ' : ''); ?><?php echo e($address->city); ?>, <?php echo e($address->state); ?> - <?php echo e($address->pincode); ?><br>
                            <?php echo e($address->country); ?>

                        </div>
                        <div class="small mt-1">
                            <span class="badge bg-light text-dark"><?php echo e(ucfirst($address->type)); ?></span>
                            <?php if($address->is_default): ?>
                                <span class="badge bg-primary">Default</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted small mb-0">No addresses on file.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header fw-semibold">Reviews</div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-bottom py-2">
                        <div class="d-flex justify-content-between">
                            <span class="small fw-semibold"><?php echo e($review->product?->name ?: 'Product'); ?></span>
                            <span class="small text-muted"><?php echo e($review->created_at->format('d M Y')); ?></span>
                        </div>
                        <div class="small">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <i class="bi <?php echo e($i <= $review->rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'); ?>"></i>
                            <?php endfor; ?>
                            <span class="badge bg-light text-dark"><?php echo e(ucfirst($review->status)); ?></span>
                        </div>
                        <?php if($review->comment): ?>
                            <div class="text-muted small mt-1"><?php echo e(Str::limit($review->comment, 100)); ?></div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted small mb-0">No reviews yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card">
            <div class="card-header fw-semibold">Orders</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th class="text-end">Total</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $orderStatusColors = [
                                'pending' => 'warning', 'confirmed' => 'info', 'processing' => 'info',
                                'shipped' => 'primary', 'out_for_delivery' => 'primary', 'delivered' => 'success',
                                'cancelled' => 'danger', 'failed' => 'danger',
                            ];
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="small fw-semibold"><?php echo e($order->order_number); ?></td>
                                <td class="text-end small"><?php echo e(format_price($order->grand_total)); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($orderStatusColors[$order->order_status] ?? 'secondary'); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $order->order_status))); ?></span>
                                </td>
                                <td class="small text-muted"><?php echo e($order->created_at->format('d M Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">No orders found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\customers\show.blade.php ENDPATH**/ ?>