<?php $__env->startSection('title', 'Newsletter'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Newsletter Subscribers</h5>
        <small class="text-muted"><?php echo e($newsletters->total()); ?> subscribers total</small>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Subscribed At</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $newsletters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsletter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="small fw-semibold"><?php echo e($newsletter->email); ?></td>
                        <td class="small"><?php echo e($newsletter->name ?: '—'); ?></td>
                        <td>
                            <span class="badge <?php echo e($newsletter->is_subscribed ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($newsletter->is_subscribed ? 'Subscribed' : 'Unsubscribed'); ?></span>
                        </td>
                        <td class="small text-muted"><?php echo e($newsletter->subscribed_at?->format('d M Y H:i') ?: '—'); ?></td>
                        <td class="text-end">
                            <form method="POST" action="<?php echo e(route('admin.newsletters.destroy', $newsletter->id)); ?>" data-confirm="Delete this subscription?">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">No newsletter subscribers found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($newsletters->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\newsletters\index.blade.php ENDPATH**/ ?>