<?php $__env->startSection('title', 'Edit Address'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4" style="max-width: 680px;">
    <a href="<?php echo e(route('account.addresses')); ?>" class="small vr-link-underline mb-3 d-inline-block"><i class="bi bi-arrow-left me-1"></i>Back to addresses</a>
    <div class="card border-0 shadow-sm" style="border-radius: 16px;">
        <div class="card-body p-4">
            <h5 class="fw-bold mb-4">Edit Address</h5>
            <?php echo $__env->make('storefront.account.partials.address-form', ['address' => $address, 'route' => route('account.addresses.update', $address), 'method' => 'PUT'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\account\address-edit.blade.php ENDPATH**/ ?>