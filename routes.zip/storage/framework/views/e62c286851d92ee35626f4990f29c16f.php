<?php $__env->startSection('title', 'Unauthorized'); ?>
<?php $__env->startSection('code', '401'); ?>
<?php $__env->startSection('icon', 'bi bi-shield-lock'); ?>
<?php $__env->startSection('message', 'You are not authorized to access this admin panel area.'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('admin.login')); ?>" class="ad-btn-back"><i class="bi bi-box-arrow-in-right"></i> Sign in to Admin</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\errors\401.blade.php ENDPATH**/ ?>