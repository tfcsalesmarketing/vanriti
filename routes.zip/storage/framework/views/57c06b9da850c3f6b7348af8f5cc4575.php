<?php
    $product = $product ?? null;
    $selectedCategories = $product ? $product->categories->pluck('id')->toArray() : old('category_ids', []);
    $primaryCategoryId = $product ? ($product->categories->where('pivot.is_primary', true)->first()?->id ?? ($selectedCategories[0] ?? null)) : old('primary_category_id');
?>

<div class="row g-3">
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-header fw-semibold">Basic Information</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Product Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control form-control-sm" value="<?php echo e(old('name', $product->name ?? '')); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">SKU</label>
                        <input type="text" name="sku" class="form-control form-control-sm" value="<?php echo e(old('sku', $product->sku ?? '')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select form-select-sm" required>
                            <option value="draft" <?php echo e(old('status', $product->status ?? 'draft') === 'draft' ? 'selected' : ''); ?>>Draft</option>
                            <option value="active" <?php echo e(old('status', $product->status ?? '') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(old('status', $product->status ?? '') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Short Description</label>
                        <textarea name="short_description" class="form-control form-control-sm" rows="2"><?php echo e(old('short_description', $product->short_description ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Description</label>
                        <textarea name="description" class="form-control form-control-sm" rows="4"><?php echo e(old('description', $product->description ?? '')); ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Pricing</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">MRP <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="mrp" id="formMrp" class="form-control form-control-sm" value="<?php echo e(old('mrp', $product->mrp ?? '')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Selling Price <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="selling_price" id="formSellingPrice" class="form-control form-control-sm" value="<?php echo e(old('selling_price', $product->selling_price ?? '')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">GST Rate (%)</label>
                        <input type="number" step="0.01" name="gst_rate" class="form-control form-control-sm" value="<?php echo e(old('gst_rate', $product->gst_rate ?? 0)); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Discount %</label>
                        <input type="text" id="formDiscountDisplay" class="form-control form-control-sm bg-light" value="<?php echo e(old('discount_percent', $product->discount_percent ?? 0)); ?>" readonly>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Content</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Highlights</label>
                        <textarea name="highlights" class="form-control form-control-sm" rows="3"><?php echo e(old('highlights', $product->highlights ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Ingredients</label>
                        <textarea name="ingredients" class="form-control form-control-sm" rows="3"><?php echo e(old('ingredients', $product->ingredients ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Benefits</label>
                        <textarea name="benefits" class="form-control form-control-sm" rows="3"><?php echo e(old('benefits', $product->benefits ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">How to Use</label>
                        <textarea name="how_to_use" class="form-control form-control-sm" rows="3"><?php echo e(old('how_to_use', $product->how_to_use ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Directions</label>
                        <textarea name="directions" class="form-control form-control-sm" rows="3"><?php echo e(old('directions', $product->directions ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Warnings</label>
                        <textarea name="warnings" class="form-control form-control-sm" rows="3"><?php echo e(old('warnings', $product->warnings ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Precautions</label>
                        <textarea name="precautions" class="form-control form-control-sm" rows="3"><?php echo e(old('precautions', $product->precautions ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Disclaimer</label>
                        <textarea name="disclaimer" class="form-control form-control-sm" rows="2"><?php echo e(old('disclaimer', $product->disclaimer ?? '')); ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">SEO</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Meta Title</label>
                        <input type="text" name="meta_title" class="form-control form-control-sm" value="<?php echo e(old('meta_title', $product->meta_title ?? '')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Meta Keywords</label>
                        <input type="text" name="meta_keywords" class="form-control form-control-sm" value="<?php echo e(old('meta_keywords', $product->meta_keywords ?? '')); ?>">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Meta Description</label>
                        <textarea name="meta_description" class="form-control form-control-sm" rows="2"><?php echo e(old('meta_description', $product->meta_description ?? '')); ?></textarea>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Search Keywords</label>
                        <input type="text" name="search_keywords" class="form-control form-control-sm" value="<?php echo e(old('search_keywords', $product->search_keywords ?? '')); ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header fw-semibold">Stock & Details</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Stock</label>
                        <input type="number" name="stock" class="form-control form-control-sm" value="<?php echo e(old('stock', $product->stock ?? 0)); ?>" min="0">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Low Stock Threshold</label>
                        <input type="number" name="low_stock_threshold" class="form-control form-control-sm" value="<?php echo e(old('low_stock_threshold', $product->low_stock_threshold ?? 5)); ?>" min="0">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">HSN Code</label>
                        <input type="text" name="hsn_code" class="form-control form-control-sm" value="<?php echo e(old('hsn_code', $product->hsn_code ?? '')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Net Quantity</label>
                        <input type="text" name="net_quantity" class="form-control form-control-sm" value="<?php echo e(old('net_quantity', $product->net_quantity ?? '')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Unit</label>
                        <input type="text" name="unit" class="form-control form-control-sm" value="<?php echo e(old('unit', $product->unit ?? '')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Shelf Life</label>
                        <input type="text" name="shelf_life" class="form-control form-control-sm" value="<?php echo e(old('shelf_life', $product->shelf_life ?? '')); ?>">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Manufacturer</label>
                        <input type="text" name="manufacturer" class="form-control form-control-sm" value="<?php echo e(old('manufacturer', $product->manufacturer ?? '')); ?>">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-semibold">Manufacturer Address</label>
                        <input type="text" name="manufacturer_address" class="form-control form-control-sm" value="<?php echo e(old('manufacturer_address', $product->manufacturer_address ?? '')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Country of Origin</label>
                        <input type="text" name="country_of_origin" class="form-control form-control-sm" value="<?php echo e(old('country_of_origin', $product->country_of_origin ?? '')); ?>">
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Categories</div>
            <div class="card-body">
                <label class="form-label small fw-semibold">Assign Categories <span class="text-danger">*</span></label>
                <div class="border rounded-3 p-2" style="max-height:220px;overflow-y:auto;">
                    <?php
                        $roots = collect($categories)->where('parent_id', null);
                    ?>
                    <?php $__currentLoopData = $roots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $root): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="category_ids[]" value="<?php echo e($root->id); ?>" id="cat_<?php echo e($root->id); ?>" <?php echo e(in_array($root->id, $selectedCategories) ? 'checked' : ''); ?>>
                            <label class="form-check-label small fw-semibold" for="cat_<?php echo e($root->id); ?>"><?php echo e($root->name); ?></label>
                        </div>
                        <?php
                            $children = collect($categories)->where('parent_id', $root->id);
                        ?>
                        <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check ms-3">
                                <input class="form-check-input" type="checkbox" name="category_ids[]" value="<?php echo e($child->id); ?>" id="cat_<?php echo e($child->id); ?>" <?php echo e(in_array($child->id, $selectedCategories) ? 'checked' : ''); ?>>
                                <label class="form-check-label small" for="cat_<?php echo e($child->id); ?>"><?php echo e($child->name); ?></label>
                            </div>
                            <?php
                                $grandchildren = collect($categories)->where('parent_id', $child->id);
                            ?>
                            <?php $__currentLoopData = $grandchildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check ms-4">
                                    <input class="form-check-input" type="checkbox" name="category_ids[]" value="<?php echo e($gc->id); ?>" id="cat_<?php echo e($gc->id); ?>" <?php echo e(in_array($gc->id, $selectedCategories) ? 'checked' : ''); ?>>
                                    <label class="form-check-label small" for="cat_<?php echo e($gc->id); ?>"><?php echo e($gc->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="form-text">Click checkboxes to select multiple categories.</div>

                <label class="form-label small fw-semibold mt-2">Primary Category</label>
                <select name="primary_category_id" class="form-select form-select-sm">
                    <option value="">None</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cat->parent_id): ?>
                            <?php $parent = collect($categories)->firstWhere('id', $cat->parent_id); ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e($primaryCategoryId == $cat->id ? 'selected' : ''); ?>><?php echo e($parent?->name ?? '—'); ?> / <?php echo e($cat->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e($primaryCategoryId == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold">Flags</div>
            <div class="card-body">
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="is_featured" value="1" id="flagFeatured" <?php echo e(old('is_featured', $product->is_featured ?? false) ? 'checked' : ''); ?>>
                    <label class="form-check-label small fw-semibold" for="flagFeatured">Featured</label>
                </div>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="is_bestseller" value="1" id="flagBestseller" <?php echo e(old('is_bestseller', $product->is_bestseller ?? false) ? 'checked' : ''); ?>>
                    <label class="form-check-label small fw-semibold" for="flagBestseller">Bestseller</label>
                </div>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="is_new_arrival" value="1" id="flagNewArrival" <?php echo e(old('is_new_arrival', $product->is_new_arrival ?? false) ? 'checked' : ''); ?>>
                    <label class="form-check-label small fw-semibold" for="flagNewArrival">New Arrival</label>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex gap-2 mt-3">
    <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-check-lg me-1"></i>Save Product</button>
    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-sm btn-outline-secondary">Cancel</a>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const mrp = document.getElementById('formMrp');
    const sp = document.getElementById('formSellingPrice');
    const display = document.getElementById('formDiscountDisplay');
    function calc() {
        const m = parseFloat(mrp.value) || 0;
        const s = parseFloat(sp.value) || 0;
        if (m > 0 && m >= s) {
            display.value = Math.round(((m - s) / m) * 1000) / 10 + '%';
        } else {
            display.value = '0%';
        }
    }
    if (mrp) mrp.addEventListener('input', calc);
    if (sp) sp.addEventListener('input', calc);
    calc();
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\products\_form.blade.php ENDPATH**/ ?>