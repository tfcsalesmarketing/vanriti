<?php $__env->startSection('title', 'Service Unavailable'); ?>
<?php $__env->startSection('code', '503'); ?>
<?php $__env->startSection('icon', 'bi bi-tools'); ?>
<?php $__env->startSection('message', 'We\'re temporarily down for maintenance. Please check back shortly.'); ?>
<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\errors\503.blade.php ENDPATH**/ ?>