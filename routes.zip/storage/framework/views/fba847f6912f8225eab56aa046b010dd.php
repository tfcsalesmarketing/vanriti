<?php $__env->startSection('title', 'Returns'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $classes = ['returned'=>'success','approved'=>'primary','pickup_scheduled'=>'info','picked_up'=>'info','requested'=>'secondary','under_review'=>'warning','rejected'=>'danger'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Returns</h5>
        <small class="text-muted"><?php echo e($returns->total()); ?> returns total</small>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.returns.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Status</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(request('status') === $status ? 'selected' : ''); ?>><?php echo e(ucwords(str_replace('_', ' ', $status))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.returns.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Return #</th>
                    <th>Order #</th>
                    <th>Customer</th>
                    <th>Reason</th>
                    <th class="text-center">Items</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="small text-primary fw-semibold"><?php echo e($return->return_number); ?></td>
                        <td class="small"><?php echo e($return->order?->order_number ?: '—'); ?></td>
                        <td>
                            <div class="fw-semibold small"><?php echo e($return->user?->name ?: '—'); ?></div>
                            <div class="text-muted small"><?php echo e($return->user?->email); ?></div>
                        </td>
                        <td class="small"><?php echo e($return->reason ?: '—'); ?></td>
                        <td class="text-center small"><?php echo e($return->items_count); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($classes[$return->status] ?? 'secondary'); ?>"><?php echo e(ucwords(str_replace('_', ' ', $return->status))); ?></span>
                        </td>
                        <td class="small"><?php echo e($return->requested_at?->format('d M Y')); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('admin.returns.show', $return)); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="bi bi-eye"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-muted">No returns found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($returns->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\returns\index.blade.php ENDPATH**/ ?>