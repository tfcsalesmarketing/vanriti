<?php $__env->startSection('title', ucfirst($leg) . ' Group Team'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">

    <div class="member-card p-4 mb-4" style="border-left: 4px solid <?php echo e($leg === 'orange' ? '#F97316' : '#0284C7'); ?>;">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                    <span class="fs-4"><?php echo e($leg === 'orange' ? '🟠' : '🔵'); ?></span>
                    <h4 class="fw-bold mb-0 text-dark brand-font"><?php echo e(ucfirst($leg)); ?> Group Team</h4>
                </div>
                <div class="small text-muted">All active downline team members inherited under your <?php echo e(ucfirst($leg)); ?> branch across all depths</div>
            </div>

            <form method="GET" action="<?php echo e(route('tfc.preview.member.team.group', $leg)); ?>" class="d-flex gap-2">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search by name, ID..." value="<?php echo e($search); ?>" style="width: 220px;">
                <button type="submit" class="btn btn-sm btn-primary">Search</button>
                <?php if($search): ?>
                    <a href="<?php echo e(route('tfc.preview.member.team.group', $leg)); ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="member-card overflow-hidden">
        <?php if($members->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small">
                        <tr>
                            <th>Depth</th>
                            <th>Member ID</th>
                            <th>Full Name</th>
                            <th>Immediate Leg</th>
                            <th>Joined Date</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="badge bg-light text-dark border font-monospace px-2 py-1">Level <?php echo e($item->depth); ?></span>
                                </td>
                                <td class="font-monospace fw-bold text-primary"><?php echo e($item->tfc_member_id); ?></td>
                                <td class="fw-medium text-dark"><?php echo e($item->full_name); ?></td>
                                <td>
                                    <?php if($item->placement_position === 'orange'): ?>
                                        <span class="badge leg-badge-orange">🟠 Orange</span>
                                    <?php else: ?>
                                        <span class="badge leg-badge-blue">🔵 Blue</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted"><?php echo e($item->joined_at ? \Carbon\Carbon::parse($item->joined_at)->format('d M Y') : '—'); ?></td>
                                <td>
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25">
                                        <?php echo e(ucfirst($item->status)); ?>

                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('tfc.preview.member.team.tree', ['root' => $item->tfc_member_id])); ?>" class="btn btn-xs btn-outline-primary py-1 px-2" style="font-size: 0.72rem;">
                                        <i class="bi bi-diagram-3"></i> View Tree
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if($members->hasPages()): ?>
                <div class="p-3 border-top d-flex justify-content-end">
                    <?php echo e($members->links()); ?>

                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <div class="rounded-circle bg-light d-inline-flex p-3 mb-2 text-secondary fs-3">
                    <i class="bi bi-diagram-2"></i>
                </div>
                <div class="fw-semibold">No team members in your <?php echo e(ucfirst($leg)); ?> group yet</div>
                <p class="small text-muted">Place or direct new members into your <?php echo e(ucfirst($leg)); ?> leg to build this branch.</p>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tfc.member.layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/tfc/member/team/group.blade.php ENDPATH**/ ?>