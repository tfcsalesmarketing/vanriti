<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $renderSettingField = function ($setting) {
        $key = $setting->key;
        $label = $setting->label;
        $type = $setting->type;
        $val = setting($key);
?>
    <?php if($type === 'boolean'): ?>
        <div class="p-2.5 rounded-3 border bg-light-subtle h-100 d-flex align-items-center justify-content-between">
            <div class="pe-2">
                <label class="form-check-label small fw-semibold cursor-pointer d-block mb-0.5" for="setting_<?php echo e($key); ?>">
                    <?php echo e($label); ?>

                </label>
                <code class="text-muted small" style="font-size: 0.70rem;"><?php echo e($key); ?></code>
            </div>
            <div class="form-check form-switch m-0 ps-0">
                <input type="checkbox" class="form-check-input" style="width: 2.2em; height: 1.2em; cursor: pointer;"
                    name="<?php echo e($key); ?>" id="setting_<?php echo e($key); ?>" value="1"
                    <?php echo e($val === '1' || $val === true ? 'checked' : ''); ?>>
            </div>
        </div>
    <?php else: ?>
        <div>
            <div class="d-flex align-items-center justify-content-between mb-1">
                <label class="form-label small fw-semibold text-muted mb-0"><?php echo e($label); ?></label>
                <code class="text-muted" style="font-size: 0.70rem;"><?php echo e($key); ?></code>
            </div>
            <?php if($type === 'textarea'): ?>
                <textarea name="<?php echo e($key); ?>" class="form-control form-control-sm" rows="3"><?php echo e($val); ?></textarea>
            <?php elseif($type === 'select'): ?>
                <select name="<?php echo e($key); ?>" class="form-select form-select-sm">
                    <option value="inclusive" <?php echo e($val === 'inclusive' ? 'selected' : ''); ?>>Inclusive</option>
                    <option value="exclusive" <?php echo e($val === 'exclusive' ? 'selected' : ''); ?>>Exclusive</option>
                </select>
            <?php elseif($type === 'password'): ?>
                <input type="password" name="<?php echo e($key); ?>" class="form-control form-control-sm" value="" autocomplete="new-password"
                    placeholder="<?php echo e(blank($val) ? '' : '•••••••• (leave blank to keep unchanged)'); ?>">
            <?php else: ?>
                <input type="<?php echo e($type === 'number' ? 'number' : ($type === 'email' ? 'email' : ($type === 'url' ? 'url' : 'text'))); ?>"
                    name="<?php echo e($key); ?>" class="form-control form-control-sm" value="<?php echo e($val); ?>"
                    step="<?php echo e($type === 'number' ? 'any' : null); ?>">
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php
    };

    $checkoutGroups = ['orders', 'shipping', 'tax', 'returns'];
    $storeGroups = ['general', 'seo'];
    $knownGroups = ['general', 'seo', 'orders', 'shipping', 'tax', 'returns', 'payment', 'shipmojo', 'whatsapp'];
    $otherGroups = $settingsGrouped->keys()->diff($knownGroups);
?>

<form method="POST" action="<?php echo e(route('admin.settings.update')); ?>">
    <?php echo csrf_field(); ?>

    
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
            <h5 class="mb-0 fw-bold">Store Configuration &amp; Integrations</h5>
            <div class="text-muted small mt-0.5">Manage store preferences, Razorpay, WhatsApp Meta API, and ShipMojo logistics</div>
        </div>
        <div>
            <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-1.5 shadow-sm px-3">
                <i class="bi bi-check2"></i><span>Save All Settings</span>
            </button>
        </div>
    </div>

    
    <ul class="nav settings-nav-pills mb-4 flex-nowrap overflow-auto" id="settingsTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="tab-store-btn" data-bs-toggle="pill" data-bs-target="#pane-store" type="button" role="tab">
                <i class="bi bi-shop"></i><span>Store Profile &amp; SEO</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="tab-checkout-btn" data-bs-toggle="pill" data-bs-target="#pane-checkout" type="button" role="tab">
                <i class="bi bi-cart-check"></i><span>Orders, Shipping &amp; Tax</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="tab-payment-btn" data-bs-toggle="pill" data-bs-target="#pane-payment" type="button" role="tab">
                <i class="bi bi-credit-card"></i><span>Payments &amp; Razorpay</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="tab-shipmojo-btn" data-bs-toggle="pill" data-bs-target="#pane-shipmojo" type="button" role="tab">
                <i class="bi bi-truck"></i><span>ShipMojo Logistics</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="tab-whatsapp-btn" data-bs-toggle="pill" data-bs-target="#pane-whatsapp" type="button" role="tab">
                <i class="bi bi-whatsapp"></i><span>WhatsApp Meta API</span>
            </button>
        </li>
        <?php if($otherGroups->isNotEmpty()): ?>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-other-btn" data-bs-toggle="pill" data-bs-target="#pane-other" type="button" role="tab">
                    <i class="bi bi-gear"></i><span>Other</span>
                </button>
            </li>
        <?php endif; ?>
    </ul>

    
    <div class="tab-content" id="settingsTabContent">
        
        
        <div class="tab-pane fade show active" id="pane-store" role="tabpanel">
            <div class="card table-card mb-4">
                <div class="card-header d-flex align-items-center gap-2">
                    <i class="bi bi-shop text-muted"></i>
                    <span>Store Identity & Business Contact</span>
                </div>
                <div class="card-body p-3">
                    <div class="row g-3">
                        <?php if(isset($settingsGrouped['general'])): ?>
                            <?php $__currentLoopData = $settingsGrouped['general']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php echo e(in_array($setting->type, ['textarea']) ? 'col-12' : 'col-12 col-md-6 col-lg-4'); ?>">
                                    <?php $renderSettingField($setting); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(isset($settingsGrouped['seo'])): ?>
            <div class="card table-card">
                <div class="card-header d-flex align-items-center gap-2">
                    <i class="bi bi-search text-muted"></i>
                    <span>Search Engine Optimization & Meta CAPI Pixel</span>
                </div>
                <div class="card-body p-3">
                    <div class="row g-3">
                        <?php $__currentLoopData = $settingsGrouped['seo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-md-6">
                                <?php $renderSettingField($setting); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        
        <div class="tab-pane fade" id="pane-checkout" role="tabpanel">
            <div class="card table-card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center gap-2">
                        <i class="bi bi-sliders2 text-muted"></i>
                        <span>Checkout Rules, Delivery Charges, GST & Returns</span>
                    </div>
                    <span class="badge bg-light text-muted border">Unified Checkout Policies</span>
                </div>
                <div class="card-body p-3">
                    
                    <?php if(isset($settingsGrouped['orders'])): ?>
                        <div class="settings-section-header">
                            <span class="avatar-circle" style="width:26px; height:26px; font-size:0.75rem; background: var(--vanriti-green-lighter); color: var(--vanriti-green);">
                                <i class="bi bi-cart"></i>
                            </span>
                            <h6>Order Limits & Confirmation Rules</h6>
                        </div>
                        <div class="row g-3 mb-4">
                            <?php $__currentLoopData = $settingsGrouped['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-md-6">
                                    <?php $renderSettingField($setting); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(isset($settingsGrouped['shipping'])): ?>
                        <div class="settings-section-divider"></div>
                        <div class="settings-section-header">
                            <span class="avatar-circle" style="width:26px; height:26px; font-size:0.75rem; background:#EEF4FF; color:#3538CD;">
                                <i class="bi bi-truck"></i>
                            </span>
                            <h6>Shipping Fees & Delivery Pincode Verification</h6>
                        </div>
                        <div class="row g-3 mb-4">
                            <?php $__currentLoopData = $settingsGrouped['shipping']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php echo e($setting->type === 'boolean' ? 'col-12 col-md-6' : 'col-12 col-md-4'); ?>">
                                    <?php $renderSettingField($setting); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(isset($settingsGrouped['tax'])): ?>
                        <div class="settings-section-divider"></div>
                        <div class="settings-section-header">
                            <span class="avatar-circle" style="width:26px; height:26px; font-size:0.75rem; background:#ECFDF5; color:#047857;">
                                <i class="bi bi-receipt"></i>
                            </span>
                            <h6>Goods & Services Tax (GST)</h6>
                        </div>
                        <div class="row g-3 mb-4">
                            <?php $__currentLoopData = $settingsGrouped['tax']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-md-4">
                                    <?php $renderSettingField($setting); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(isset($settingsGrouped['returns'])): ?>
                        <div class="settings-section-divider"></div>
                        <div class="settings-section-header">
                            <span class="avatar-circle" style="width:26px; height:26px; font-size:0.75rem; background:#FFFBEB; color:#B45309;">
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </span>
                            <h6>Return Window & Customer Policy</h6>
                        </div>
                        <div class="row g-3">
                            <?php $__currentLoopData = $settingsGrouped['returns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php echo e($setting->type === 'textarea' ? 'col-12' : 'col-12 col-md-6'); ?>">
                                    <?php $renderSettingField($setting); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="tab-pane fade" id="pane-payment" role="tabpanel">
            <?php if(isset($settingsGrouped['payment'])): ?>
                <div class="card table-card">
                    <div class="card-header d-flex align-items-center gap-2">
                        <i class="bi bi-credit-card text-muted"></i>
                        <span>Payment Gateways & Razorpay API</span>
                    </div>
                    <div class="card-body p-3">
                        <div class="row g-3">
                            <?php $__currentLoopData = $settingsGrouped['payment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php echo e($setting->type === 'boolean' ? 'col-12 col-md-4' : 'col-12 col-md-6'); ?>">
                                    <?php $renderSettingField($setting); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-12 mt-3">
                                <div class="alert alert-light border small mb-0 p-3 rounded-3">
                                    <div class="fw-semibold mb-1 text-dark"><i class="bi bi-broadcast me-1 text-primary"></i>Razorpay Webhook Callback URL</div>
                                    <span class="text-muted" style="font-size:0.75rem;">Add this Webhook URL in your Razorpay Dashboard (Settings &rarr; Webhooks) so orders are instantly captured even if mobile shoppers close the tab after paying via UPI (GPay/PhonePe/Paytm):</span>
                                    <div class="d-flex align-items-center gap-2 mt-1.5">
                                        <code class="bg-white px-2 py-1 rounded border w-100 font-monospace small" id="razorpay-webhook-url"><?php echo e(url('/razorpay/webhook')); ?></code>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('razorpay-webhook-url').textContent); if(window.vrToast) window.vrToast('Copied to clipboard!');" title="Copy Webhook URL"><i class="bi bi-clipboard"></i></button>
                                    </div>
                                    <small class="text-muted d-block mt-2" style="font-size:0.72rem; line-height:1.4;">
                                        <strong>Setup Instructions:</strong> In Razorpay Dashboard &rarr; <em>Settings</em> &rarr; <em>Webhooks</em> &rarr; <em>Add New Webhook</em>, paste the URL above, enter any secret you choose, and select Active Events: <code>payment.captured</code> and <code>payment.failed</code>. Then paste that exact secret into the <strong>Razorpay Webhook Secret</strong> field above and click <em>Save All Settings</em>.
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="tab-pane fade" id="pane-shipmojo" role="tabpanel">
            <?php if(isset($settingsGrouped['shipmojo'])): ?>
                <div class="card table-card">
                    <div class="card-header d-flex justify-content-between align-items-center py-2.5">
                        <div class="d-flex align-items-center gap-2">
                            <i class="bi bi-truck text-muted"></i>
                            <span>ShipMojo Multi-Courier Dispatch Integration</span>
                        </div>
                        <button type="button" class="btn btn-xs btn-outline-success btn-sm py-0.5 px-2" onclick="testShipMojo(this)">
                            <i class="bi bi-wifi me-1"></i>Test Connection
                        </button>
                    </div>
                    <div class="card-body p-3">
                        <div class="row g-3">
                            <?php $__currentLoopData = $settingsGrouped['shipmojo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php echo e($setting->type === 'boolean' ? 'col-12 col-md-6' : 'col-12 col-md-4'); ?>">
                                    <?php $renderSettingField($setting); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-12 mt-3">
                                <div class="alert alert-light border small mb-0 p-3 rounded-3">
                                    <div class="fw-semibold mb-1 text-dark"><i class="bi bi-broadcast me-1 text-primary"></i>ShipMojo Webhook Callback</div>
                                    <span class="text-muted" style="font-size:0.75rem;">Set this URL in your ShipMojo dashboard as the webhook callback:</span>
                                    <div class="d-flex align-items-center gap-2 mt-1.5">
                                        <code class="bg-white px-2 py-1 rounded border w-100 font-monospace small" id="shipmojo-webhook-url"><?php echo e(url('/shipmojo/webhook')); ?></code>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('shipmojo-webhook-url').textContent)" title="Copy Webhook URL"><i class="bi bi-clipboard"></i></button>
                                    </div>
                                    <small class="text-muted d-block mt-1.5" style="font-size:0.72rem; line-height:1.3;">
                                        ShipMojo must send the <code>public-key</code> header, an HMAC-SHA256 signature in <code>x-shipmojo-signature</code>, and the order reference ID. Statuses will update automatically.
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="tab-pane fade" id="pane-whatsapp" role="tabpanel">
            <?php if(isset($settingsGrouped['whatsapp'])): ?>
                <?php
                    $waSettings = $settingsGrouped['whatsapp']->keyBy('key');
                    $credKeys = ['whatsapp_phone_number_id', 'whatsapp_waba_id', 'whatsapp_access_token'];
                    $autoReplyKeys = [
                        'whatsapp_bot_auto_reply_enabled',
                        'whatsapp_auto_welcome_enabled',
                        'whatsapp_welcome_template_name',
                        'whatsapp_away_message_enabled',
                        'whatsapp_away_message_text',
                    ];
                    $timingKeys = [
                        'whatsapp_away_timing_mode',
                        'whatsapp_business_hours_start',
                        'whatsapp_business_hours_end',
                        'whatsapp_business_days',
                        'whatsapp_timezone',
                    ];
                    $commerceKeys = [
                        'whatsapp_otp_enabled',
                        'whatsapp_template_name',
                        'whatsapp_orders_enabled',
                        'whatsapp_order_template_name',
                        'whatsapp_delivery_eta_days',
                        'whatsapp_shipping_notifications_enabled',
                        'whatsapp_dispatch_template_name',
                        'whatsapp_out_for_delivery_template_name',
                        'whatsapp_delivered_template_name',
                        'whatsapp_recovery_enabled',
                        'whatsapp_recovery_template_name',
                        'whatsapp_recovery_delay_hours',
                    ];
                    $handledKeys = array_merge($credKeys, $autoReplyKeys, $timingKeys, $commerceKeys);
                ?>

                
                <div class="card table-card mb-3">
                    <div class="card-header d-flex align-items-center justify-content-between py-2.5">
                        <div class="d-flex align-items-center gap-2">
                            <i class="bi bi-shield-lock text-success"></i>
                            <span class="fw-semibold">1. Meta Cloud API Credentials &amp; Connection</span>
                        </div>
                        <a href="<?php echo e(route('admin.whatsapp.profile')); ?>" class="btn btn-xs btn-outline-success btn-sm py-0.5 px-2 text-decoration-none">
                            <i class="bi bi-activity me-1"></i>Check Connection Health
                        </a>
                    </div>
                    <div class="card-body p-3">
                        <div class="row g-3">
                            <?php $__currentLoopData = $credKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($waSettings[$k])): ?>
                                    <div class="col-12 col-md-4">
                                        <?php $renderSettingField($waSettings[$k]); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                
                <div class="card table-card mb-3 border-success-subtle shadow-sm">
                    <div class="card-header bg-success-subtle text-success-emphasis d-flex align-items-center justify-content-between py-2.5">
                        <div class="d-flex align-items-center gap-2">
                            <i class="bi bi-robot fs-5"></i>
                            <span class="fw-bold">2. Chatbot Auto-Replies, Welcome Message &amp; Away Responder</span>
                        </div>
                        <span class="badge bg-success text-white px-2.5 py-1">Admin Controlled Safeguards</span>
                    </div>
                    <div class="card-body p-3">
                        <div class="alert alert-light border small py-2 px-3 mb-3 rounded-3 text-muted">
                            <i class="bi bi-info-circle-fill text-success me-1"></i>
                            To prevent sending unwanted messages to customers, automated replies only send when their individual switch below is turned <strong>ON</strong>.
                        </div>
                        <div class="row g-3">
                            <?php $__currentLoopData = $autoReplyKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($waSettings[$k])): ?>
                                    <div class="<?php echo e($waSettings[$k]->type === 'boolean' ? 'col-12 col-md-6' : ($waSettings[$k]->type === 'textarea' ? 'col-12' : 'col-12 col-md-6')); ?>">
                                        <?php $renderSettingField($waSettings[$k]); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                
                <div class="card table-card mb-3">
                    <div class="card-header d-flex align-items-center gap-2 py-2.5">
                        <i class="bi bi-clock-history text-primary"></i>
                        <span class="fw-semibold">3. Away Timings &amp; Business Hours Schedule</span>
                    </div>
                    <div class="card-body p-3">
                        <div class="row g-3">
                            <?php $__currentLoopData = $timingKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($waSettings[$k])): ?>
                                    <div class="col-12 col-md-4">
                                        <?php $renderSettingField($waSettings[$k]); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                
                <div class="card table-card mb-3">
                    <div class="card-header d-flex align-items-center gap-2 py-2.5">
                        <i class="bi bi-bag-check text-secondary"></i>
                        <span class="fw-semibold">4. Automated E-Commerce Customer Journeys (OTP, Orders &amp; Tracking)</span>
                    </div>
                    <div class="card-body p-3">
                        <div class="row g-3">
                            <?php $__currentLoopData = $commerceKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($waSettings[$k])): ?>
                                    <div class="<?php echo e($waSettings[$k]->type === 'boolean' ? 'col-12 col-md-6' : 'col-12 col-md-4'); ?>">
                                        <?php $renderSettingField($waSettings[$k]); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $waSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!in_array($key, $handledKeys, true)): ?>
                                    <div class="<?php echo e($setting->type === 'boolean' ? 'col-12 col-md-6' : 'col-12 col-md-4'); ?>">
                                        <?php $renderSettingField($setting); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <?php if($otherGroups->isNotEmpty()): ?>
            <div class="tab-pane fade" id="pane-other" role="tabpanel">
                <?php $__currentLoopData = $otherGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card table-card mb-3">
                        <div class="card-header fw-bold"><?php echo e(ucfirst($grp)); ?> Settings</div>
                        <div class="card-body p-3">
                            <div class="row g-3">
                                <?php $__currentLoopData = $settingsGrouped[$grp]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 col-md-6">
                                        <?php $renderSettingField($setting); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>

    
    <div class="card p-3 border-0 bg-transparent text-end mt-2">
        <button type="submit" class="btn btn-primary d-inline-flex align-items-center gap-1.5 shadow-sm px-4">
            <i class="bi bi-check2"></i><span>Save All Settings</span>
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script nonce="<?php echo e($cspNonce); ?>">
function testShipMojo(btn) {
    const orig = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Testing…';

    const pubInput = document.querySelector('input[name="shipmojo_public_key"]');
    const privInput = document.querySelector('input[name="shipmojo_private_key"]');

    let url = '<?php echo e(route('admin.shipmojo.ping')); ?>';
    const params = new URLSearchParams();
    if (pubInput && pubInput.value.trim()) {
        params.append('public_key', pubInput.value.trim());
    }
    if (privInput && privInput.value.trim()) {
        params.append('private_key', privInput.value.trim());
    }
    if (params.toString()) {
        url += '?' + params.toString();
    }

    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        }
    })
    .then(r => r.json())
    .then(data => {
        if (data.result === '1' || data.success) {
            btn.innerHTML = '<i class="bi bi-check-circle-fill text-success me-1"></i>Connected!';
            btn.classList.replace('btn-outline-success', 'btn-success');
            if (typeof showToast === 'function') {
                showToast(data.message || 'Connected to ShipMojo successfully!', 'success');
            }
        } else {
            const msg = data.message || 'Connection failed';
            btn.innerHTML = '<i class="bi bi-x-circle-fill text-danger me-1"></i>Failed';
            btn.classList.replace('btn-outline-success', 'btn-outline-danger');
            if (typeof vrAlert === 'function') {
                vrAlert(msg, { title: 'ShipMojo Connection Failed', type: 'danger' });
            } else {
                alert('ShipMojo Connection Failed:\n\n' + msg);
            }
        }
        setTimeout(() => {
            btn.innerHTML = orig;
            btn.disabled = false;
            btn.className = btn.className.replace('btn-outline-danger','btn-outline-success').replace('btn-success','btn-outline-success');
        }, 3500);
    })
    .catch(err => {
        btn.innerHTML = '<i class="bi bi-x-circle-fill text-danger me-1"></i>Network Error';
        if (typeof showToast === 'function') {
            showToast('Network error while testing ShipMojo connection: ' + err.message, 'error');
        }
        setTimeout(() => {
            btn.innerHTML = orig;
            btn.disabled = false;
        }, 3500);
    });
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>