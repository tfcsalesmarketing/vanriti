<?php $__env->startSection('title', 'Inventory'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Inventory</h5>
        <small class="text-muted"><?php echo e($products->total()); ?> products listed</small>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon bg-cream text-green"><i class="bi bi-box-seam"></i></div>
                <div>
                    <div class="text-muted small fw-semibold">Total SKUs</div>
                    <div class="stat-value"><?php echo e($totalSkus); ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon bg-light text-danger"><i class="bi bi-x-circle"></i></div>
                <div>
                    <div class="text-muted small fw-semibold">Out of Stock SKUs</div>
                    <div class="stat-value"><?php echo e($outOfStock); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.inventory.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search name or SKU..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-2">
                <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" name="low_only" value="1" id="lowOnly" <?php echo e(request('low_only') ? 'checked' : ''); ?>>
                    <label class="form-check-label small fw-semibold" for="lowOnly">Low stock only</label>
                </div>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.inventory.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>SKU</th>
                    <th class="text-center">Type</th>
                    <th class="text-end">Available Stock</th>
                    <th class="text-end">Threshold</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $hasVariants = $product->variants->isNotEmpty();
                        $stock = $hasVariants ? (int) $product->variants->sum('stock') : (int) $product->stock;
                        $threshold = $product->low_stock_threshold ?: 0;
                        if ($stock <= 0):
                            $statusBadge = '<span class="badge badge-soft-danger">Out of stock</span>';
                        elseif ($stock <= $threshold):
                            $statusBadge = '<span class="badge badge-soft-warning">Low</span>';
                        else:
                            $statusBadge = '<span class="badge badge-soft-success">In stock</span>';
                        endif;
                    ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php $img = $product->images->first(); ?>
                                <?php if($img): ?>
                                    <img src="<?php echo e(image_url($img->image_path)); ?>" alt="" class="img-thumb">
                                <?php else: ?>
                                    <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                        <i class="bi bi-image text-muted"></i>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-semibold small text-truncate" style="max-width:220px;">
                                        <a href="<?php echo e(route('admin.products.show', $product->slug)); ?>" class="text-decoration-none text-dark"><?php echo e($product->name); ?></a>
                                    </div>
                                    <div class="text-muted" style="font-size:0.75rem;"><?php echo e($product->slug); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="small"><?php echo e($hasVariants ? ($product->variants->first()->sku ?: $product->sku ?: '—') : ($product->sku ?: '—')); ?></td>
                        <td class="text-center">
                            <span class="badge <?php echo e($hasVariants ? 'badge-soft-info' : 'badge-soft-secondary'); ?>"><?php echo e($hasVariants ? 'Variant' : 'Simple'); ?></span>
                        </td>
                        <td class="text-end">
                            <span class="fw-semibold small"><?php echo e($stock); ?></span>
                        </td>
                        <td class="text-end small"><?php echo e($threshold); ?></td>
                        <td><?php echo $statusBadge; ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('admin.products.show', $product->slug)); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="bi bi-eye"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No products found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\inventory\index.blade.php ENDPATH**/ ?>