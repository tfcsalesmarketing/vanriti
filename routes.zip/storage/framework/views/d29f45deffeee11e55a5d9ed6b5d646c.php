<?php $__env->startSection('title', 'Method Not Allowed'); ?>
<?php $__env->startSection('code', '405'); ?>
<?php $__env->startSection('icon', 'bi bi-sign-stop'); ?>
<?php $__env->startSection('message', 'This HTTP method is not allowed for the admin endpoint you requested.'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="ad-btn-back"><i class="bi bi-speedometer2"></i> Back to Dashboard</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\errors\405.blade.php ENDPATH**/ ?>