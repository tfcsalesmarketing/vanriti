<?php $__env->startSection('title', 'Page Expired'); ?>
<?php $__env->startSection('code', '419'); ?>
<?php $__env->startSection('icon', 'bi bi-hourglass-split'); ?>
<?php $__env->startSection('message', 'Your session has expired. Please try again.'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="#" class="btn btn-vr-outline" onclick="history.back(); return false;">Try again</a>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-vr">Go back home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/errors/419.blade.php ENDPATH**/ ?>