<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Customers</h5>
        <small class="text-muted"><?php echo e($customers->total()); ?> customers total</small>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.customers.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search name, email or phone..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-sm btn-dark"><i class="bi bi-search me-1"></i>Search</button>
            </div>
            <div class="col-auto">
                <a href="<?php echo e(route('admin.customers.index')); ?>" class="btn btn-sm btn-outline-secondary">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th class="text-center">Orders</th>
                    <th class="text-end">Total Spent</th>
                    <th>Joined</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <span class="avatar-circle bg-primary text-white"><?php echo e(strtoupper(substr($customer->name, 0, 1))); ?></span>
                                <div>
                                    <div class="fw-semibold small">
                                        <a href="<?php echo e(route('admin.customers.show', $customer->id)); ?>" class="text-decoration-none text-dark"><?php echo e($customer->name); ?></a>
                                    </div>
                                    <div class="text-muted" style="font-size:0.75rem;"><?php echo e($customer->email); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="small"><?php echo e($customer->phone ?: '—'); ?></td>
                        <td>
                            <span class="badge <?php echo e($customer->status === 'active' ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e(ucfirst($customer->status)); ?></span>
                        </td>
                        <td class="text-center"><?php echo e($customer->orders_count); ?></td>
                        <td class="text-end fw-semibold small"><?php echo e(format_price($customer->total_spent ?? 0)); ?></td>
                        <td class="small text-muted"><?php echo e($customer->created_at->format('d M Y')); ?></td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <a href="<?php echo e(route('admin.customers.show', $customer->id)); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="bi bi-eye"></i></a>
                                <form method="POST" action="<?php echo e(route('admin.customers.toggle', $customer->id)); ?>" data-confirm="<?php echo e($customer->status === 'active' ? 'Deactivate' : 'Activate'); ?> this customer?">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-<?php echo e($customer->status === 'active' ? 'warning' : 'success'); ?>" title="<?php echo e($customer->status === 'active' ? 'Deactivate' : 'Activate'); ?>">
                                        <i class="bi <?php echo e($customer->status === 'active' ? 'bi-person-x' : 'bi-person-check'); ?>"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No customers found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($customers->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\customers\index.blade.php ENDPATH**/ ?>