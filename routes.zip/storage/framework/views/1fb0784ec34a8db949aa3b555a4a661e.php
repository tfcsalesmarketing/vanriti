<?php $__env->startSection('title', 'Track Order'); ?>

<?php $__env->startSection('content'); ?>
<div class="vr-section">
    <div class="container">
        <h1 class="vr-section-title mb-4">Track Order</h1>

        <div class="row justify-content-center mb-4">
            <div class="col-md-6 col-lg-5">
                <div class="vr-cart-item p-4">
                    <form action="<?php echo e(route('track.lookup')); ?>" method="POST" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Order Number</label>
                            <input type="text" name="order_number" class="form-control"
                                   placeholder="e.g. VAN-2026-000001"
                                   value="<?php echo e(old('order_number')); ?>">
                            <div class="invalid-feedback"></div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Mobile Number</label>
                            <input type="text" name="mobile" class="form-control"
                                   placeholder="Used during checkout"
                                   value="<?php echo e(old('mobile')); ?>">
                            <div class="invalid-feedback"></div>
                        </div>
                        <button type="submit" class="btn btn-vr w-100">
                            <i class="bi bi-search me-1"></i>Track
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <?php if($orders !== null && $orders->count() > 0): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row justify-content-center mb-4">
                    <div class="col-lg-8">
                        <div class="vr-cart-item p-4">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <span class="fw-bold"><?php echo e($order->order_number); ?></span>
                                    <span class="vr-pill-badge os-<?php echo e($order->order_status); ?> ms-2"><?php echo e(ucfirst(str_replace('_', ' ', $order->order_status))); ?></span>
                                </div>
                                <span class="small text-muted"><?php echo e($order->created_at->format('d M Y')); ?></span>
                            </div>

                            <div class="small text-muted mb-3">
                                Total: <strong><?php echo e(format_price($order->grand_total)); ?></strong>
                                &middot; <?php echo e($order->items->count()); ?> item(s)
                            </div>

                            <?php echo $__env->make('storefront.partials.order-status-steps', ['order' => $order], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                            <div class="d-flex flex-wrap gap-2 mb-3 mt-3">
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex align-items-center gap-2 p-2 border rounded" style="font-size:0.82rem;">
                                        <?php if($item->image): ?>
                                            <img src="<?php echo e(image_url($item->image)); ?>" alt="" style="width:32px;height:32px;object-fit:cover;border-radius:6px;">
                                        <?php endif; ?>
                                        <span><?php echo e($item->product_name); ?></span>
                                        <span class="text-muted">x<?php echo e($item->quantity); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <?php if($order->shipments->count() > 0): ?>
                                <h6 class="fw-bold mt-3 mb-2">Tracking Updates</h6>
                                <?php $__currentLoopData = $order->shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($shipment->trackingEvents->count() > 0): ?>
                                        <div class="border-start ps-3 mb-3" style="border-color:var(--vr-green) !important;">
                                            <div class="small text-muted mb-2">
                                                <?php echo e($shipment->courier ?? 'Shipment'); ?>

                                                <?php if($shipment->tracking_number): ?>
                                                    &middot; <?php echo e($shipment->tracking_number); ?>

                                                <?php endif; ?>
                                            </div>
                                            <?php $__currentLoopData = $shipment->trackingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="d-flex align-items-start gap-2 mb-2">
                                                    <div style="width:8px;height:8px;border-radius:50%;background:var(--vr-green);margin-top:6px;" class="flex-shrink-0"></div>
                                                    <div>
                                                        <div class="fw-semibold" style="font-size:0.82rem;"><?php echo e($event->status); ?></div>
                                                        <?php if($event->description): ?>
                                                            <div class="text-muted" style="font-size:0.78rem;"><?php echo e($event->description); ?></div>
                                                        <?php endif; ?>
                                                        <div class="text-muted" style="font-size:0.72rem;">
                                                            <?php echo e($event->event_date ? $event->event_date->format('d M Y, h:i A') : ''); ?>

                                                            <?php if($event->location): ?>
                                                                &middot; <?php echo e($event->location); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="small text-muted border rounded p-2 mb-2">
                                            No tracking events yet for this shipment.
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="small text-muted border rounded p-2">
                                    Shipment information will be updated once your order is dispatched.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif($orders !== null && $orders->isEmpty()): ?>
            <div class="text-center text-muted py-3">
                <p>No orders found. Please check your order number and mobile number.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/track/index.blade.php ENDPATH**/ ?>