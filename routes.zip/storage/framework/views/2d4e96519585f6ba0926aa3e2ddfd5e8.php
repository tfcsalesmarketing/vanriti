<?php $__env->startSection('title', 'Page Expired'); ?>
<?php $__env->startSection('code', '419'); ?>
<?php $__env->startSection('icon', 'bi bi-hourglass-split'); ?>
<?php $__env->startSection('message', 'Your admin session has expired. Please sign in again.'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('admin.login')); ?>" class="ad-btn-back"><i class="bi bi-box-arrow-in-right"></i> Sign in to Admin</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\errors\419.blade.php ENDPATH**/ ?>