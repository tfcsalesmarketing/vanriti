<?php $__env->startSection('title', $blog->seo_title ?: $blog->title); ?>
<?php $__env->startSection('meta_description', $blog->meta_description ?: setting('meta_description')); ?>
<?php $__env->startSection('meta_keywords', setting('meta_keywords')); ?>
<?php $__env->startSection('og_title', $blog->seo_title ?: $blog->title); ?>
<?php $__env->startSection('og_description', $blog->meta_description ?: setting('meta_description')); ?>

<?php $__env->startSection('content'); ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
        {
            "@type": "ListItem",
            "position": 1,
            "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('home'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        {
            "@type": "ListItem",
            "position": 2,
            "name": "Journal",
            "item": <?php echo json_encode(route('blog.index'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        {
            "@type": "ListItem",
            "position": 3,
            "name": <?php echo json_encode($blog->title, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('blog.show', $blog), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }
    ]
}
</script>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "headline": <?php echo json_encode($blog->title, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    <?php if($blog->excerpt): ?>"description": <?php echo json_encode(strip_tags($blog->excerpt), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,<?php endif; ?>
    "image": <?php echo json_encode($blog->featured_image ? image_url($blog->featured_image) : image_url(null, 'favicon.ico'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "datePublished": <?php echo json_encode($blog->published_at?->toAtomString(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "dateModified": <?php echo json_encode($blog->updated_at?->toAtomString(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
    "author": {
        "@type": "Person",
        "name": <?php echo json_encode($blog->author?->name ?? store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

    },
    "publisher": {
        "@type": "Organization",
        "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
        "logo": {
            "@type": "ImageObject",
            "url": <?php echo json_encode(image_url(setting('store_logo'), 'favicon.ico'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }
    },
    "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": <?php echo json_encode(route('blog.show', $blog), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

    }
}
</script>
<div class="vr-section" style="background:var(--vr-cream);">
    <div class="container">
        <nav class="vr-breadcrumb">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <span class="mx-1">/</span>
            <a href="<?php echo e(route('blog.index')); ?>">Journal</a>
            <span class="mx-1">/</span>
            <span><?php echo e(Str::limit($blog->title, 50)); ?></span>
        </nav>
    </div>
</div>

<div class="vr-section">
    <div class="container">
        <div class="mb-4">
            <?php if($blog->category): ?>
                <span class="vr-pill-badge" style="background:var(--vr-green-soft);color:var(--vr-green);"><?php echo e($blog->category->name); ?></span>
            <?php endif; ?>
            <h1 class="mt-2 mb-3" style="font-weight:800;color:var(--vr-green-dark);"><?php echo e($blog->title); ?></h1>
            <div class="small text-muted">
                <?php echo e($blog->published_at->format('F d, Y')); ?>

                <?php if($blog->author): ?>
                    &middot; By <?php echo e($blog->author->name); ?>

                <?php endif; ?>
            </div>
        </div>

        <?php if($blog->featured_image): ?>
            <div style="border-radius:var(--vr-radius);overflow:hidden;margin-bottom:2rem;">
                <img src="<?php echo e(image_url($blog->featured_image)); ?>" alt="<?php echo e($blog->title); ?>" style="width:100%;height:auto;">
            </div>
        <?php endif; ?>

        <div class="blog-content" style="line-height:1.8;font-size:1.05rem;">
            <?php echo clean_html($blog->content); ?>

        </div>

        <div class="mt-5 pt-4 border-top">
            <p class="small text-muted">
                <i class="bi bi-share me-1"></i> Share this post with someone who might find it useful.
            </p>
        </div>
    </div>
</div>

<?php if($related->count()): ?>
    <div class="vr-section" style="background:var(--vr-cream);">
        <div class="container">
            <h3 class="vr-section-title mb-4">Related Posts</h3>
            <div class="row g-4">
                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <a href="<?php echo e(route('blog.show', $rel->slug)); ?>" class="text-decoration-none">
                            <div class="vr-card">
                                <?php if($rel->featured_image): ?>
                                    <div class="img-wrap" style="aspect-ratio:16/10;">
                                        <img src="<?php echo e(image_url($rel->featured_image)); ?>" alt="<?php echo e($rel->title); ?>">
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <?php if($rel->category): ?>
                                        <span class="cat-name"><?php echo e($rel->category->name); ?></span>
                                    <?php endif; ?>
                                    <h6 class="mt-1 mb-0" style="font-weight:700;color:var(--vr-green-dark);"><?php echo e(Str::limit($rel->title, 60)); ?></h6>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\blog\show.blade.php ENDPATH**/ ?>