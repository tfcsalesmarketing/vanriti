<?php $__env->startSection('title', 'Edit Dadi Product Profile'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $statusColors = [
        'draft' => 'secondary', 'pending_review' => 'warning', 'approved' => 'success', 'rejected' => 'danger',
    ];
    $productStatusColors = ['draft' => 'secondary', 'active' => 'success', 'inactive' => 'secondary'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Dadi Product Profile</h5>
        <small class="text-muted">
            Product: <strong><?php echo e($profile->product?->name ?: 'Product #'.$profile->product_id); ?></strong>
            <span class="badge bg-<?php echo e($productStatusColors[$profile->product?->status] ?? 'secondary'); ?>"><?php echo e(ucfirst($profile->product?->status ?: 'missing')); ?></span>
        </small>
    </div>
    <a href="<?php echo e(route('admin.dadi.product-profiles.index')); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-3">
                <div class="text-muted small">SKU</div>
                <div class="fw-semibold"><?php echo e($profile->product?->sku ?: '—'); ?></div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Selling Price (live)</div>
                <div class="fw-semibold">₹<?php echo e(number_format((float) $profile->product?->selling_price, 2)); ?></div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Stock (live)</div>
                <div class="fw-semibold"><?php echo e($profile->product?->getAvailableStock()); ?> units</div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Approval Status</div>
                <span class="badge bg-<?php echo e($statusColors[$profile->status->value] ?? 'secondary'); ?>"><?php echo e($profile->status->label()); ?></span>
            </div>
        </div>
        <hr>
        <div class="row g-3 text-muted small">
            <div class="col-md-4">
                Created by <strong><?php echo e($profile->creator?->name ?: '—'); ?></strong> on <?php echo e($profile->created_at?->format('d M Y H:i')); ?>

            </div>
            <div class="col-md-4">
                Reviewed by <strong><?php echo e($profile->reviewer?->name ?: '—'); ?></strong>
                <?php if($profile->reviewed_at): ?> on <?php echo e($profile->reviewed_at->format('d M Y H:i')); ?> <?php endif; ?>
            </div>
            <div class="col-md-4">
                Last modified: <?php echo e($profile->updated_at?->format('d M Y H:i')); ?>

            </div>
        </div>
    </div>
</div>

<?php if($errors->has('content')): ?>
    <div class="alert alert-danger"><strong>Please fix the following:</strong> <?php echo e($errors->first('content')); ?></div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.dadi.product-profiles.update', $profile->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php echo $__env->make('admin.dadi-product-profiles._form', ['profile' => $profile], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <button type="submit" class="btn btn-dark"><i class="bi bi-check-lg me-1"></i>Save Intelligence</button>
</form>

<?php if($profile->status->value === 'draft' || $profile->status->value === 'rejected'): ?>
    <form method="POST" action="<?php echo e(route('admin.dadi.product-profiles.submit-review', $profile->id)); ?>" class="d-inline">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline-primary mt-3"><i class="bi bi-send me-1"></i>Submit for Review</button>
    </form>
<?php endif; ?>

<?php if($profile->status->value === 'pending_review'): ?>
    <form method="POST" action="<?php echo e(route('admin.dadi.product-profiles.approve', $profile->id)); ?>" class="d-inline" data-confirm="Approve this Dadi profile?">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-success mt-3"><i class="bi bi-check-lg me-1"></i>Approve</button>
    </form>
    <form method="POST" action="<?php echo e(route('admin.dadi.product-profiles.reject', $profile->id)); ?>" class="d-inline" data-confirm="Reject this Dadi profile?">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline-danger mt-3"><i class="bi bi-x-lg me-1"></i>Reject</button>
    </form>
<?php endif; ?>

<?php if($profile->status->value === 'approved'): ?>
    <p class="text-muted small mt-3">
        <i class="bi bi-info-circle me-1"></i>
        Approved intelligence is usable by Dadi, but current availability always follows the live product status and stock above.
    </p>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\dadi-product-profiles\edit.blade.php ENDPATH**/ ?>