<?php
    $images = $product->images;
    $img = $product->getPrimaryImage()?->image_path;
    $secondaryImg = $images && $images->count() > 1 ? $images->where('image_path', '!=', $img)->first()?->image_path : null;
    $discount = $product->discountPercent();
    $reviewCount = $product->review_count;
    $reviewRating = $product->review_rating;
    $available = $product->getAvailableStock();
    $hasVariants = $product->activeVariants->isNotEmpty();
    $firstVariant = $hasVariants ? $product->activeVariants->first(fn ($v) => (int) $v->stock > 0) : null;
    $out = $available <= 0 || ($hasVariants && $firstVariant === null);
    $low = ! $out && $product->isLowStock();
    $category = $product->categories->first();
    $wishlistService = app(App\Services\WishlistService::class);
    $liked = $wishlistService->has($product);
    $isNew = $product->created_at && $product->created_at->gte(now()->subDays(30));
    $cartLineByProduct = $cartLineByProduct ?? collect();
    $cartLine = $cartLineByProduct->get($product->id);
    $cartQty = $cartLine?->quantity ?? 0;
?>

<div class="vr-card">
    <div class="img-wrap">
        <?php if($discount > 0): ?>
            <span class="vr-disc-badge"><?php echo e((int) round($discount)); ?>% OFF</span>
        <?php endif; ?>
        <?php if($isNew): ?>
            <span class="vr-new-badge">NEW</span>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('wishlist.toggle', $product)); ?>" class="m-0 js-wishlist-form">
            <?php echo csrf_field(); ?>
            <button type="submit" class="vr-wish-btn <?php echo e($liked ? 'liked' : ''); ?>" title="<?php echo e($liked ? 'Remove from wishlist' : 'Add to wishlist'); ?>" aria-label="Toggle wishlist">
                <i class="bi <?php echo e($liked ? 'bi-heart-fill' : 'bi-heart'); ?>"></i>
            </button>
        </form>

        <a href="<?php echo e(route('product.show', $product)); ?>" class="d-block h-100 w-100 position-relative overflow-hidden" aria-label="<?php echo e($product->name); ?>">
            <?php if($img): ?>
                <img src="<?php echo e(image_url($img)); ?>" alt="<?php echo e($product->name); ?>" class="img-primary" loading="lazy" decoding="async">
                <?php if($secondaryImg): ?>
                    <img src="<?php echo e(image_url($secondaryImg)); ?>" alt="<?php echo e($product->name); ?>" class="img-secondary" loading="lazy" decoding="async">
                <?php endif; ?>
            <?php else: ?>
                <div class="d-flex align-items-center justify-content-center h-100 w-100" style="background:var(--vr-green-soft);">
                    <i class="bi bi-image text-secondary display-4"></i>
                </div>
            <?php endif; ?>
        </a>
    </div>

    <div class="card-body">
        <?php if($category): ?>
            <div class="cat-name"><?php echo e($category->name); ?></div>
        <?php endif; ?>

        <a href="<?php echo e(route('product.show', $product)); ?>" class="p-name d-block mb-1" title="<?php echo e($product->name); ?>"><?php echo e(Str::limit($product->name, 100, '...')); ?></a>

        <div class="vr-card-tail mt-auto">
        <?php if($reviewCount > 0): ?>
            <div class="rating-stars small mb-1">
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <i class="bi bi-star<?php echo e($i <= (int) round($reviewRating) ? '-fill' : ''); ?> <?php echo e($i <= (int) round($reviewRating) ? 'filled' : ''); ?>"></i>
                <?php endfor; ?>
                <span class="text-muted ms-1">(<?php echo e($reviewCount); ?>)</span>
            </div>
        <?php else: ?>
            <div class="rating-stars small mb-1">
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <i class="bi bi-star"></i>
                <?php endfor; ?>
                <span class="text-muted ms-1">New</span>
            </div>
        <?php endif; ?>

        <div class="vr-price mt-1">
            <span class="now"><?php echo e(format_price($product->selling_price)); ?></span>
            <?php if($product->mrp > $product->selling_price): ?>
                <span class="mrp"><?php echo e(format_price($product->mrp)); ?></span>
            <?php endif; ?>
        </div>

        <?php if($out): ?>
            <span class="vr-stock-label out mt-1">Out of stock</span>
        <?php elseif($low): ?>
            <span class="vr-stock-label in mt-1">Only <?php echo e($available); ?> left</span>
        <?php endif; ?>

        <div class="js-add-wrap <?php echo e($cartQty > 0 ? 'd-none' : ''); ?>">
            <form method="POST" action="<?php echo e(route('cart.add', $product)); ?>" class="mt-2">
                <?php echo csrf_field(); ?>
                <?php if($firstVariant): ?>
                    <input type="hidden" name="variant_id" value="<?php echo e($firstVariant->id); ?>">
                <?php endif; ?>
                <input type="hidden" name="quantity" value="1">
                <button type="submit" class="btn btn-vr vr-quick-add d-block w-100 js-add-cart" <?php echo e($out ? 'disabled' : ''); ?>>
                    <i class="bi bi-bag-plus me-1"></i> Add to Cart
                </button>
            </form>
        </div>

        <div class="js-qty-wrap <?php echo e($cartQty > 0 ? '' : 'd-none'); ?>">
            <form method="POST" action="<?php echo e(route('cart.update', '__ITEM__')); ?>" class="mt-2 js-card-qty-form"
                  data-cart-item="<?php echo e($cartLine ? $cartLine->id : ''); ?>"
                  data-update-url="<?php echo e(route('cart.update', '__ITEM__')); ?>"
                  data-remove-url="<?php echo e(route('cart.remove', '__ITEM__')); ?>">
                <?php echo csrf_field(); ?>
                <div class="vr-card-qty">
                    <button type="button" class="vr-card-qty-btn vr-card-qty-minus" data-step="-1" aria-label="Decrease quantity"><i class="ri-subtract-line"></i></button>
                    <input type="number" name="quantity" value="<?php echo e($cartQty > 0 ? $cartQty : 1); ?>" min="1" max="5" readonly aria-label="Quantity">
                    <button type="button" class="vr-card-qty-btn vr-card-qty-plus" data-step="1" aria-label="Increase quantity"><i class="ri-add-line"></i></button>
                </div>
            </form>
        </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\partials\product-card.blade.php ENDPATH**/ ?>