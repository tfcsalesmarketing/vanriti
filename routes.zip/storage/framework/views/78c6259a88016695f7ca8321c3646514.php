<?php if($banner): ?>
    <?php
        $promoDesktop = image_url($banner->image);
        $promoMobile = $banner->mobile_image ? image_url($banner->mobile_image) : null;
        $promoAlt = $banner->title ?: store_name().' promotional banner';
    ?>
    <section class="vr-promo">
        <div class="container">
            <?php if($banner->link): ?>
                <a href="<?php echo e($banner->link); ?>" class="vr-promo-link">
                    <picture>
                        <?php if($promoMobile): ?>
                            <source media="(max-width: 767.98px)" srcset="<?php echo e($promoMobile); ?>">
                        <?php endif; ?>
                        <img src="<?php echo e($promoDesktop); ?>" alt="<?php echo e($promoAlt); ?>" class="vr-promo-img" loading="lazy" decoding="async">
                    </picture>
                </a>
            <?php else: ?>
                <picture>
                    <?php if($promoMobile): ?>
                        <source media="(max-width: 767.98px)" srcset="<?php echo e($promoMobile); ?>">
                    <?php endif; ?>
                    <img src="<?php echo e($promoDesktop); ?>" alt="<?php echo e($promoAlt); ?>" class="vr-promo-img" loading="lazy" decoding="async">
                </picture>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/partials/section-banner.blade.php ENDPATH**/ ?>