<?php $__env->startSection('title', 'Order '.$order->order_number); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $statusColors = [
        'pending' => 'ps-pending', 'confirmed' => 'os-processing', 'processing' => 'os-processing',
        'packed' => 'os-processing', 'shipped' => 'os-shipped', 'out_for_delivery' => 'os-shipped',
        'delivered' => 'os-delivered', 'cancelled' => 'os-cancelled', 'failed' => 'os-cancelled',
    ];
    $reviewed = $order->items->map(fn ($i) => $i->reviewExist)->all() ?? [];
    $alreadyReviewing = $order->items->filter(fn ($i) => ($i->reviewExist ?? false));
    $hasReturn = $order->returnRequests->isNotEmpty();
?>

<div class="container py-4">
    <nav class="vr-breadcrumb mb-3">
        <a href="<?php echo e(route('account.orders')); ?>">My Orders</a> &rsaquo;
        <span><?php echo e($order->order_number); ?></span>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h5 class="fw-bold mb-0">Order <?php echo e($order->order_number); ?></h5>
        <span class="vr-pill-badge <?php echo e($statusColors[$order->order_status] ?? 'ps-pending'); ?>">
            <?php echo e(ucwords(str_replace('_', ' ', $order->order_status))); ?>

        </span>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card border-0 shadow-sm mb-3" style="border-radius: 14px;">
                    <div class="card-body p-3 d-flex gap-3 align-items-start">
                        <?php if($item->image): ?>
                            <img src="<?php echo e(image_url($item->image)); ?>"
                                 alt="<?php echo e($item->product_name); ?>" class="rounded-3" style="width:70px;height:70px;object-fit:cover;background:var(--vr-cream);">
                        <?php else: ?>
                            <div class="rounded-3 d-flex align-items-center justify-content-center" style="width:70px;height:70px;background:var(--vr-cream);">
                                <i class="bi bi-box text-muted"></i>
                            </div>
                        <?php endif; ?>
                        <div class="flex-grow-1">
                            <div class="fw-semibold small"><?php echo e($item->product_name); ?></div>
                            <?php if($item->variant_name): ?>
                                <div class="small text-muted"><?php echo e($item->variant_name); ?> &middot; <?php echo e($item->sku); ?></div>
                            <?php endif; ?>
                            <div class="small text-muted mt-1">
                                Qty: <?php echo e($item->quantity); ?> &times; <?php echo e(format_price($item->unit_price)); ?>

                            </div>
                        </div>
                        <div class="text-end small">
                            <div class="fw-semibold"><?php echo e(format_price($item->total_price)); ?></div>

                            <?php if($order->order_status === 'delivered' && ! $alreadyReviewing->contains('order_item_id', $item->id) && ! $item->reviewExist): ?>
                                <button class="btn btn-sm btn-vr-outline mt-2" data-bs-toggle="collapse" data-bs-target="#review-<?php echo e($item->id); ?>">
                                    <i class="bi bi-star me-1"></i>Review
                                </button>
                                <div class="collapse mt-2" id="review-<?php echo e($item->id); ?>">
                                    <form method="POST" action="<?php echo e(route('account.order.review', $order)); ?>" class="text-start" novalidate>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="order_item_id" value="<?php echo e($item->id); ?>">
                                        <div class="mb-2">
                                            <select name="rating" class="form-select form-select-sm">
                                                <?php for($i = 5; $i >= 1; $i--): ?>
                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?> star<?php echo e($i > 1 ? 's' : ''); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="mb-2">
                                            <input type="text" name="title" class="form-control form-control-sm" placeholder="Review title (optional)">
                                        </div>
                                        <div class="mb-2">
                                            <textarea name="comment" class="form-control form-control-sm" rows="2" placeholder="Tell us what you thought..."></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-vr">Submit Review</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($order->isReturnable() && ! $hasReturn): ?>
                <div class="card border-0 shadow-sm mb-3" style="border-radius: 14px;">
                    <div class="card-body p-3">
                        <h6 class="fw-bold mb-1"><i class="bi bi-arrow-counterclockwise me-1"></i>Raise a Return</h6>
                        <p class="small text-muted mb-3">
                            Select items to return. Request must be raised within <?php echo e(setting('return_window_days', 7)); ?> days of delivery.
                        </p>
                        <form method="POST" action="<?php echo e(route('account.order.return', $order)); ?>" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check mb-1">
                                        <input class="form-check-input" type="checkbox" name="items[]" value="<?php echo e($item->id); ?>" id="ritem-<?php echo e($item->id); ?>">
                                        <label class="form-check-label small" for="ritem-<?php echo e($item->id); ?>">
                                            <?php echo e($item->product_name); ?> &times; <?php echo e($item->quantity); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="row g-2">
                                <div class="col-md-6">
                                    <select name="reason" class="form-select form-select-sm">
                                        <option value="">Select reason</option>
                                        <option>Damaged / broken item</option>
                                        <option>Wrong item delivered</option>
                                        <option>Item expired / nearing expiry</option>
                                        <option>Defective product</option>
                                        <option>Changed my mind</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" name="description" class="form-control form-control-sm" placeholder="Additional details (optional)">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-sm btn-vr mt-3">Submit Return Request</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($order->isCancellable()): ?>
                <div class="card border-0 shadow-sm mb-3" style="border-radius: 14px;">
                    <div class="card-body p-3 d-flex flex-wrap align-items-center gap-2">
                        <div class="flex-grow-1">
                            <h6 class="fw-bold mb-1">Cancel Order</h6>
                            <p class="small text-muted mb-0">Orders can be cancelled before shipping.</p>
                        </div>
                        <form method="POST" action="<?php echo e(route('account.order.cancel', $order)); ?>"
                              data-confirm="Are you sure you want to cancel this order?">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill">Cancel Order</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm mb-3" style="border-radius: 14px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-3"><i class="bi bi-clock-history me-1"></i>Order Progress</h6>
                    <?php echo $__env->make('storefront.partials.order-status-steps', ['order' => $order], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <hr class="my-3">
                    <h6 class="fw-bold mb-2 small text-muted text-uppercase">Updates</h6>
                    <ul class="list-unstyled small mb-0">
                        <?php $__empty_1 = true; $__currentLoopData = $order->statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="d-flex gap-2 mb-2">
                                <i class="bi bi-check-circle-fill" style="color:var(--vr-green);"></i>
                                <span>
                                    <span class="fw-semibold"><?php echo e(ucwords(str_replace('_', ' ', $history->status))); ?></span>
                                    <span class="text-muted">&middot; <?php echo e($history->created_at->format('d M Y, h:i A')); ?></span>
                                    <?php if($history->description): ?>
                                        <div class="text-muted mt-1"><?php echo e($history->description); ?></div>
                                    <?php endif; ?>
                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="text-muted">No updates yet.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-3" style="border-radius: 14px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-2">Order Summary</h6>
                    <div class="small d-grid gap-1">
                        <div class="d-flex justify-content-between"><span class="text-muted">Subtotal <span class="text-muted" style="font-size:0.85em;">(incl. GST)</span></span><span><?php echo e(format_price($order->subtotal)); ?></span></div>
                        <div class="d-flex justify-content-between"><span class="text-muted">Item Discounts</span><span class="text-success">- <?php echo e(format_price($order->discount_amount)); ?></span></div>
                        <?php if($order->coupon_discount > 0): ?>
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">
                                    Coupon<?php echo e($order->coupon_code ? ' ('.$order->coupon_code.')' : ''); ?>

                                    <?php if($order->coupon_type || $order->coupon_value !== null): ?>
                                        <span class="d-block" style="font-size:0.85em;"><?php echo e(ucfirst((string) $order->coupon_type)); ?><?php echo e($order->coupon_value !== null ? ' '.format_price($order->coupon_value) : ''); ?></span>
                                    <?php endif; ?>
                                </span>
                                <span class="text-success">- <?php echo e(format_price($order->coupon_discount)); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between"><span class="text-muted">Taxable Value</span><span><?php echo e(format_price($order->taxable_value)); ?></span></div>
                        <?php if($order->isIntraState()): ?>
                            <div class="d-flex justify-content-between"><span class="text-muted">CGST<?php echo e($order->uniformGstRate() !== null ? ' ('.number_format($order->uniformGstRate() / 2, 1, '.', '').'%)' : ''); ?></span><span><?php echo e(format_price($order->cgst_amount)); ?></span></div>
                            <div class="d-flex justify-content-between"><span class="text-muted">SGST<?php echo e($order->uniformGstRate() !== null ? ' ('.number_format($order->uniformGstRate() / 2, 1, '.', '').'%)' : ''); ?></span><span><?php echo e(format_price($order->sgst_amount)); ?></span></div>
                        <?php else: ?>
                            <div class="d-flex justify-content-between"><span class="text-muted">IGST<?php echo e($order->uniformGstRate() !== null ? ' ('.(float) $order->uniformGstRate().'%)' : ''); ?></span><span><?php echo e(format_price($order->igst_amount)); ?></span></div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between"><span class="text-muted">Shipping</span><span><?php echo e($order->shipping_charge > 0 ? format_price($order->shipping_charge) : 'FREE'); ?></span></div>
                        <hr class="my-2">
                        <div class="d-flex justify-content-between fs-6 fw-bold"><span>Total</span><span><?php echo e(format_price($order->grand_total)); ?></span></div>
                        <div class="text-muted" style="font-size:0.8em;">Total payable is inclusive of GST.</div>
                        <div class="d-flex justify-content-between mt-1"><span class="text-muted">Paid</span><span><?php echo e(format_price($order->amount_paid)); ?></span></div>
                        <div class="d-flex justify-content-between"><span class="text-muted">Due</span><span><?php echo e(format_price($order->amount_due)); ?></span></div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3" style="border-radius: 14px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-2"><i class="bi bi-geo-alt me-1"></i>Delivery Address</h6>
                    <p class="small mb-0">
                        <?php echo e($order->shipping_name); ?><br>
                        <?php echo e($order->shipping_address_line1); ?><?php echo e($order->shipping_address_line2 ? ', '.$order->shipping_address_line2 : ''); ?><br>
                        <?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?> - <?php echo e($order->shipping_pincode); ?><br>
                        Mobile: <?php echo e($order->shipping_mobile); ?>

                    </p>
                </div>
            </div>

            <?php if($order->shipments->isNotEmpty()): ?>
                <div class="card border-0 shadow-sm mb-3" style="border-radius: 14px;">
                    <div class="card-body p-3">
                        <h6 class="fw-bold mb-2"><i class="bi bi-truck me-1"></i>Shipment</h6>
                        <?php $__currentLoopData = $order->shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="small">
                                <div class="d-flex justify-content-between"><span class="text-muted">Courier</span><span><?php echo e($shipment->courier ?? '—'); ?></span></div>
                                <div class="d-flex justify-content-between"><span class="text-muted">Tracking</span><span class="fw-semibold"><?php echo e($shipment->tracking_number ?? '—'); ?></span></div>
                                <div class="d-flex justify-content-between"><span class="text-muted">Status</span><span><?php echo e(ucwords(str_replace('_', ' ', $shipment->status))); ?></span></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\account\order-detail.blade.php ENDPATH**/ ?>