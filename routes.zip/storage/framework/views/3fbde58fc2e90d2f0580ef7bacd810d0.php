<?php $__env->startSection('title', 'Reviews'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Reviews</h5>
        <small class="text-muted"><?php echo e($reviews->total()); ?> reviews total</small>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('admin.reviews.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search product, title or comment..." value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Status</option>
                    <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="approved" <?php echo e(request('status') === 'approved' ? 'selected' : ''); ?>>Approved</option>
                    <option value="rejected" <?php echo e(request('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                    <option value="hidden" <?php echo e(request('status') === 'hidden' ? 'selected' : ''); ?>>Hidden</option>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-sm btn-dark"><i class="bi bi-search me-1"></i>Filter</button>
            </div>
            <div class="col-auto">
                <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-sm btn-outline-secondary">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Customer</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $statusColors = [
                        'pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger', 'hidden' => 'secondary',
                    ];
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php $img = $review->product?->images->first(); ?>
                                <?php if($img): ?>
                                    <img src="<?php echo e(image_url($img->image_path)); ?>" alt="" class="rounded" width="40" height="40" style="object-fit:cover;">
                                <?php else: ?>
                                    <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:40px;height:40px;">
                                        <i class="bi bi-image text-muted"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="small fw-semibold" style="max-width:180px;">
                                    <span class="text-truncate d-block"><?php echo e($review->product?->name ?: 'Product #' . $review->product_id); ?></span>
                                </div>
                            </div>
                        </td>
                        <td class="small"><?php echo e($review->user?->name ?: '—'); ?></td>
                        <td>
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <i class="bi <?php echo e($i <= $review->rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'); ?>" style="font-size:0.7rem;"></i>
                            <?php endfor; ?>
                        </td>
                        <td>
                            <div class="small fw-semibold"><?php echo e($review->title ?: '—'); ?></div>
                            <?php if($review->comment): ?>
                                <div class="text-muted" style="font-size:0.75rem;"><?php echo e(Str::limit($review->comment, 80)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-<?php echo e($statusColors[$review->status] ?? 'secondary'); ?>"><?php echo e(ucfirst($review->status)); ?></span>
                        </td>
                        <td class="small text-muted"><?php echo e($review->created_at->format('d M Y')); ?></td>
                        <td class="text-end">
                            <div class="d-flex gap-1 justify-content-end">
                                <?php if($review->status !== 'approved'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.reviews.approve', $review->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-success" title="Approve"><i class="bi bi-check-lg"></i></button>
                                    </form>
                                <?php endif; ?>
                                <?php if($review->status !== 'rejected'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.reviews.reject', $review->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-warning" title="Reject"><i class="bi bi-x-lg"></i></button>
                                    </form>
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('admin.reviews.destroy', $review->id)); ?>" data-confirm="Delete this review?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No reviews found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($reviews->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\reviews\index.blade.php ENDPATH**/ ?>