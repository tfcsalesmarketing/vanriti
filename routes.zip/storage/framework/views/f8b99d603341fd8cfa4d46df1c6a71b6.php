<?php $__env->startSection('title', $page->meta_title ?: $page->title); ?>
<?php $__env->startSection('meta_description', $page->meta_description ?: setting('meta_description')); ?>
<?php $__env->startSection('meta_keywords', setting('meta_keywords')); ?>
<?php $__env->startSection('og_title', $page->meta_title ?: $page->title); ?>
<?php $__env->startSection('og_description', $page->meta_description ?: setting('meta_description')); ?>

<?php $__env->startSection('content'); ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
        {
            "@type": "ListItem",
            "position": 1,
            "name": <?php echo json_encode(store_name(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(route('home'), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        },
        {
            "@type": "ListItem",
            "position": 2,
            "name": <?php echo json_encode($page->title, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "item": <?php echo json_encode(request()->url(), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

        }
    ]
}
</script>
<div class="container py-5">
    <div style="background:#ffffff;border-radius:16px;box-shadow:0 8px 30px rgba(38,61,37,0.08);padding:2rem;">
        <?php echo clean_html($page->content); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\page.blade.php ENDPATH**/ ?>