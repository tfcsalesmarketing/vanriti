<?php $__env->startSection('title', 'Direct Referrals'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">

    <div class="member-card p-4 mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <h4 class="fw-bold mb-1 text-dark brand-font">Direct Referrals</h4>
                <div class="small text-muted">Members who registered using your unique Sponsor ID (<?php echo e($member->tfc_member_id); ?>)</div>
            </div>

            <form method="GET" action="<?php echo e(route('tfc.preview.member.team.direct')); ?>" class="d-flex gap-2">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Search by name, ID..." value="<?php echo e($search); ?>" style="width: 220px;">
                <button type="submit" class="btn btn-sm btn-primary">Search</button>
                <?php if($search): ?>
                    <a href="<?php echo e(route('tfc.preview.member.team.direct')); ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="member-card overflow-hidden">
        <?php if($directs->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small">
                        <tr>
                            <th>Member ID</th>
                            <th>Full Name</th>
                            <th>Mobile</th>
                            <th>Placement Parent</th>
                            <th>Leg</th>
                            <th>Joined Date</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php $__currentLoopData = $directs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="font-monospace fw-bold text-primary"><?php echo e($direct->tfc_member_id); ?></td>
                                <td class="fw-medium text-dark"><?php echo e($direct->full_name); ?></td>
                                <td class="text-muted font-monospace">•••• <?php echo e(substr($direct->mobile, -4)); ?></td>
                                <td>
                                    <?php if($direct->placementParent): ?>
                                        <span class="text-dark"><?php echo e($direct->placementParent->full_name); ?></span>
                                        <span class="text-muted font-monospace small">(<?php echo e($direct->placementParent->tfc_member_id); ?>)</span>
                                    <?php else: ?>
                                        <span class="text-muted">Direct</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($direct->placement_position === 'orange'): ?>
                                        <span class="badge leg-badge-orange">🟠 Orange</span>
                                    <?php elseif($direct->placement_position === 'blue'): ?>
                                        <span class="badge leg-badge-blue">🔵 Blue</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Root</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted"><?php echo e($direct->joined_at ? $direct->joined_at->format('d M Y') : '—'); ?></td>
                                <td>
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25">
                                        <?php echo e(ucfirst($direct->status)); ?>

                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('tfc.preview.member.team.tree', ['root' => $direct->tfc_member_id])); ?>" class="btn btn-xs btn-outline-primary py-1 px-2" style="font-size: 0.72rem;">
                                        <i class="bi bi-diagram-3"></i> View Tree
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if($directs->hasPages()): ?>
                <div class="p-3 border-top d-flex justify-content-end">
                    <?php echo e($directs->links()); ?>

                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <div class="rounded-circle bg-light d-inline-flex p-3 mb-2 text-secondary fs-3">
                    <i class="bi bi-person-x"></i>
                </div>
                <div class="fw-semibold">No direct members found</div>
                <p class="small text-muted">Start sharing your referral link to build your personal team.</p>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tfc.member.layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/tfc/member/team/table.blade.php ENDPATH**/ ?>