<?php $__env->startSection('title', 'Member Profile & Security'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">

    <div class="row g-4">
        
        <div class="col-lg-7">
            <div class="member-card p-4 p-md-5">
                <h5 class="fw-bold mb-3 text-dark border-bottom pb-2">
                    <i class="bi bi-person-circle text-primary me-1"></i> Personal Profile
                </h5>

                
                <div class="p-3 mb-4 rounded-3 bg-light border">
                    <div class="row g-3 small">
                        <div class="col-sm-6">
                            <span class="text-muted d-block">TFC Member ID:</span>
                            <span class="font-monospace fw-bold text-primary fs-6"><?php echo e($member->tfc_member_id); ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted d-block">Enrollment Date:</span>
                            <strong class="text-dark"><?php echo e($member->joined_at ? $member->joined_at->format('d M Y') : '—'); ?></strong>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted d-block">Direct Sponsor:</span>
                            <strong class="text-dark"><?php echo e($member->sponsor ? $member->sponsor->full_name . ' (' . $member->sponsor->tfc_member_id . ')' : 'Direct TFC'); ?></strong>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted d-block">Placement Parent &amp; Leg:</span>
                            <strong class="text-dark"><?php echo e($member->placementParent ? $member->placementParent->full_name : 'Root'); ?> (<?php echo e(ucfirst($member->placement_position ?? 'root')); ?>)</strong>
                        </div>
                    </div>
                </div>

                <form method="POST" action="<?php echo e(route('tfc.preview.member.profile.update')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="full_name" class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('full_name', $member->full_name)); ?>" required>
                        <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Registered Email</label>
                            <input type="email" class="form-control bg-light" value="<?php echo e($member->email); ?>" disabled readonly>
                            <div class="form-text" style="font-size: 0.72rem;">Email cannot be edited directly for security.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Registered Mobile</label>
                            <input type="text" class="form-control bg-light" value="<?php echo e($member->mobile); ?>" disabled readonly>
                            <div class="form-text" style="font-size: 0.72rem;">Mobile is bound to your account.</div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Address Line</label>
                        <input type="text" name="address_line" class="form-control <?php $__errorArgs = ['address_line'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('address_line', $member->address_line)); ?>" placeholder="House/Flat, Street name">
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">City</label>
                            <input type="text" name="city" class="form-control" value="<?php echo e(old('city', $member->city)); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">State</label>
                            <input type="text" name="state" class="form-control" value="<?php echo e(old('state', $member->state)); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Pincode</label>
                            <input type="text" name="pincode" class="form-control <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="6" value="<?php echo e(old('pincode', $member->pincode)); ?>">
                            <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="bi bi-save me-1"></i> Update Profile Information
                    </button>
                </form>
            </div>
        </div>

        
        <div class="col-lg-5">
            <div class="member-card p-4 p-md-5">
                <h5 class="fw-bold mb-3 text-dark border-bottom pb-2">
                    <i class="bi bi-shield-lock text-success me-1"></i> Change Password
                </h5>

                <form method="POST" action="<?php echo e(route('tfc.preview.member.profile.password')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Current Password <span class="text-danger">*</span></label>
                        <input type="password" name="current_password" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">New Password <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Confirm New Password <span class="text-danger">*</span></label>
                        <input type="password" name="password_confirmation" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-outline-dark w-100 fw-semibold">
                        <i class="bi bi-key me-1"></i> Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tfc.member.layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/tfc/member/profile.blade.php ENDPATH**/ ?>