<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0 fw-bold">Settings</h5>
</div>

<form method="POST" action="<?php echo e(route('admin.settings.update')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row g-3">
        <?php $__currentLoopData = $settingsGrouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $settings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="card h-100 d-flex flex-column mb-3">
                    <div class="card-header fw-semibold d-flex justify-content-between align-items-center">
                        <span><?php echo e(ucfirst($group)); ?></span>
                        <?php if($group === 'shipmojo'): ?>
                            <button type="button" class="btn btn-xs btn-outline-success btn-sm py-0 px-2"
                                onclick="testShipMojo(this)">
                                <i class="bi bi-wifi me-1"></i>Test Connection
                            </button>
                        <?php endif; ?>
                    </div>
                    <div class="card-body flex-grow-1">
                        <div class="row g-3">
                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12">
                                    <?php if($setting->type === 'boolean'): ?>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" class="form-check-input" name="<?php echo e($setting->key); ?>" id="setting_<?php echo e($setting->key); ?>" value="1"
                                                <?php echo e(setting($setting->key) === '1' || setting($setting->key) === true ? 'checked' : ''); ?>>
                                            <label class="form-check-label small fw-semibold" for="setting_<?php echo e($setting->key); ?>"><?php echo e($setting->label); ?></label>
                                        </div>
                                    <?php else: ?>
                                        <label class="form-label small fw-semibold"><?php echo e($setting->label); ?></label>
                                        <?php if($setting->type === 'textarea'): ?>
                                            <textarea name="<?php echo e($setting->key); ?>" class="form-control form-control-sm" rows="3"><?php echo e(setting($setting->key)); ?></textarea>
                                        <?php elseif($setting->type === 'select'): ?>
                                            <select name="<?php echo e($setting->key); ?>" class="form-select form-select-sm">
                                                <option value="inclusive" <?php echo e(setting($setting->key) === 'inclusive' ? 'selected' : ''); ?>>Inclusive</option>
                                                <option value="exclusive" <?php echo e(setting($setting->key) === 'exclusive' ? 'selected' : ''); ?>>Exclusive</option>
                                            </select>
                                        <?php elseif($setting->type === 'password'): ?>
                                            <input type="password" name="<?php echo e($setting->key); ?>" class="form-control form-control-sm" value="" autocomplete="new-password"
                                                placeholder="<?php echo e(blank(setting($setting->key)) ? '' : '•••••••• (leave blank to keep)'); ?>">
                                        <?php else: ?>
                                            <input type="<?php echo e($setting->type === 'number' ? 'number' : ($setting->type === 'email' ? 'email' : ($setting->type === 'url' ? 'url' : 'text'))); ?>" name="<?php echo e($setting->key); ?>" class="form-control form-control-sm" value="<?php echo e(setting($setting->key)); ?>" step="<?php echo e($setting->type === 'number' ? 'any' : null); ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($group === 'shipmojo'): ?>
                                <div class="col-12">
                                    <div class="alert alert-light border small mb-0">
                                        <div class="fw-semibold mb-1"><i class="bi bi-broadcast me-1"></i>ShipMojo Webhook</div>
                                        <span class="text-muted">Set this URL in your ShipMojo dashboard as the status callback:</span>
                                        <div class="d-flex align-items-center gap-2 mt-1">
                                            <code class="bg-white px-2 py-1 rounded border w-100" id="shipmojo-webhook-url"><?php echo e(url('/shipmojo/webhook')); ?></code>
                                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('shipmojo-webhook-url').textContent)"><i class="bi bi-clipboard"></i></button>
                                        </div>
                                        <small class="text-muted d-block mt-1">
                                            ShipMojo must send the <code>public-key</code> header (set above), an HMAC-SHA256
                                            signature in <code>x-shipmojo-signature</code> (body signed with the webhook secret),
                                            and the order/shipment reference id. Statuses update orders and AWB/courier automatically.
                                        </small>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="d-flex gap-2 mt-3">
        <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-check-lg me-1"></i>Save Settings</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function testShipMojo(btn) {
    const orig = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Testing…';

    fetch('<?php echo e(route('admin.shipmojo.ping')); ?>', {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.result === '1') {
            btn.innerHTML = '<i class="bi bi-check-circle-fill text-success me-1"></i>Connected!';
            btn.classList.replace('btn-outline-success', 'btn-success');
        } else {
            btn.innerHTML = '<i class="bi bi-x-circle-fill text-danger me-1"></i>Failed: ' + (data.message || 'Error');
            btn.classList.replace('btn-outline-success', 'btn-outline-danger');
        }
        setTimeout(() => { btn.innerHTML = orig; btn.disabled = false;
            btn.className = btn.className.replace('btn-outline-danger','btn-outline-success').replace('btn-success','btn-outline-success'); }, 3000);
    })
    .catch(() => {
        btn.innerHTML = '<i class="bi bi-x-circle-fill text-danger me-1"></i>Network Error';
        setTimeout(() => { btn.innerHTML = orig; btn.disabled = false; }, 3000);
    });
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\admin\settings\index.blade.php ENDPATH**/ ?>