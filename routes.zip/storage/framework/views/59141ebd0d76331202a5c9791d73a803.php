<?php $__env->startSection('title', 'Something Went Wrong'); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message', 'An unexpected error occurred on our end. Please try again in a few minutes.'); ?>
<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/errors/500.blade.php ENDPATH**/ ?>