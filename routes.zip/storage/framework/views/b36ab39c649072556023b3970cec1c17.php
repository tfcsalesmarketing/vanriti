<?php
    $_vrBrand = config('app.name', 'VANRITI');
    $_vrLogo = null;
    try {
        $_vrBrand = store_name();
        $_vrLogo = setting('store_logo');
        if (! $_vrLogo) {
            foreach (['svg', 'png', 'webp', 'jpg'] as $ext) {
                if (file_exists(public_path('images/logo.' . $ext))) {
                    $_vrLogo = 'images/logo.' . $ext;
                    break;
                }
            }
        }
    } catch (\Throwable $__e) {
        $_vrBrand = config('app.name', 'VANRITI');
        $_vrLogo = null;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <meta name="theme-color" content="#263D25">
    <title><?php echo $__env->yieldContent('code', 'Error'); ?> &middot; <?php echo $__env->yieldContent('title', 'Something went wrong'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/storefront.css')); ?>?v=<?php echo e(time()); ?>">
    <style>
        .vr-error-brand {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            margin-bottom: 1.75rem;
            font-weight: 800;
            letter-spacing: .16em;
            color: var(--vr-green-dark);
            text-decoration: none;
        }
        .vr-error-brand:hover { color: var(--vr-green-dark); }
        .vr-error-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 74px;
            height: 74px;
            border-radius: 50%;
            background: var(--vr-green-soft);
            color: var(--vr-green);
            font-size: 2rem;
            margin-bottom: 1.25rem;
        }
        .vr-error-code {
            font-size: clamp(3.5rem, 12vw, 6.5rem);
            line-height: 1;
            font-weight: 800;
            color: var(--vr-green-dark);
            letter-spacing: .02em;
        }
        .vr-error-msg {
            color: var(--vr-muted);
            max-width: 380px;
            margin-inline: auto;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <div class="vr-auth-shell">
        <div class="card vr-auth-card">
            <div class="card-body text-center px-4 py-5">
                <a class="vr-error-brand" href="<?php echo e(route('home')); ?>">
                    <?php if($_vrLogo): ?>
                        <img src="<?php echo e(image_url($_vrLogo, 'favicon.ico')); ?>" alt="<?php echo e(e($_vrBrand)); ?>" height="42" class="vr-logo">
                    <?php else: ?>
                        <span><?php echo e(strtoupper(e($_vrBrand))); ?><span class="dot">.</span></span>
                    <?php endif; ?>
                </a>

                <div class="vr-error-icon mx-auto"><i class="<?php echo $__env->yieldContent('icon', 'bi bi-exclamation-triangle'); ?>"></i></div>
                <div class="vr-error-code"><?php echo $__env->yieldContent('code', 'Error'); ?></div>
                <h1 class="h5 mt-3 mb-1 fw-bold"><?php echo $__env->yieldContent('title'); ?></h1>
                <p class="vr-error-msg mt-2 mb-4"><?php echo $__env->yieldContent('message'); ?></p>

                <div class="d-inline-flex flex-wrap gap-2 justify-content-center align-items-center">
                    <?php if (! empty(trim($__env->yieldContent('buttons')))): ?>
                        <?php echo $__env->yieldContent('buttons'); ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-vr">Go back home</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/errors/layout.blade.php ENDPATH**/ ?>