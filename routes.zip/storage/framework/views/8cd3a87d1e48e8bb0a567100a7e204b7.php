<?php
    $steps = ['pending', 'confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered'];
    $current = $order->order_status ?? 'pending';
    $terminal = in_array($current, ['cancelled', 'failed'], true);
    $currentIdx = $terminal ? -1 : array_search($current, $steps, true);
?>

<?php if($terminal): ?>
    <div class="vr-status-terminal">
        <i class="bi <?php echo e($current === 'cancelled' ? 'bi-x-octagon' : 'bi-exclamation-octagon'); ?>"></i>
        <div>
            <strong><?php echo e(ucwords(str_replace('_', ' ', $current))); ?></strong>
            <div class="small text-muted"><?php echo e($current === 'cancelled' ? 'This order has been cancelled.' : 'This order could not be completed.'); ?></div>
        </div>
    </div>
<?php elseif($currentIdx !== false): ?>
    <ol class="vr-status-steps">
        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php echo e($i < $currentIdx ? 'done' : ($i === $currentIdx ? 'active' : '')); ?>">
                <span class="dot">
                    <?php if($i < $currentIdx): ?>
                        <i class="bi bi-check"></i>
                    <?php elseif($i === $currentIdx): ?>
                        <i class="bi bi-circle-fill"></i>
                    <?php endif; ?>
                </span>
                <span class="label"><?php echo e(ucwords(str_replace('_', ' ', $s))); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/storefront/partials/order-status-steps.blade.php ENDPATH**/ ?>