<?php $__env->startSection('title', 'TFC Inquiries & Seller Applications'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h5 class="fw-bold mb-1">TFC Inquiries &amp; Seller Applications</h5>
        <p class="text-muted small mb-0">Review inbound prospective direct-seller registrations and corporate inquiries.</p>
    </div>
</div>


<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body p-3">
        <form method="GET" action="<?php echo e(route('admin.tfc.inquiries.index')); ?>" class="row g-2 align-items-center">
            <div class="col-12 col-md-4">
                <select name="type" class="form-select form-select-sm">
                    <option value="">All Inquiry Types</option>
                    <option value="seller_application" <?php echo e(request('type') === 'seller_application' ? 'selected' : ''); ?>>Prospective Direct Seller Application</option>
                    <option value="general" <?php echo e(request('type') === 'general' ? 'selected' : ''); ?>>General Corporate Inquiry</option>
                </select>
            </div>
            <div class="col-12 col-md-4">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Statuses</option>
                    <option value="new" <?php echo e(request('status') === 'new' ? 'selected' : ''); ?>>New</option>
                    <option value="in_progress" <?php echo e(request('status') === 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                    <option value="resolved" <?php echo e(request('status') === 'resolved' ? 'selected' : ''); ?>>Resolved</option>
                </select>
            </div>
            <div class="col-12 col-md-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
                <a href="<?php echo e(route('admin.tfc.inquiries.index')); ?>" class="btn btn-light btn-sm">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Applicant / Inquirer</th>
                        <th>Type</th>
                        <th>Location</th>
                        <th>Date Received</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="fw-bold text-dark"><?php echo e($inquiry->name); ?></div>
                                <div class="text-muted small">
                                    <i class="bi bi-telephone me-1"></i><?php echo e($inquiry->phone); ?> |
                                    <i class="bi bi-envelope me-1"></i><?php echo e($inquiry->email); ?>

                                </div>
                            </td>
                            <td>
                                <span class="badge <?php echo e($inquiry->type === 'seller_application' ? 'bg-primary-subtle text-primary border border-primary-subtle' : 'bg-secondary-subtle text-secondary'); ?>">
                                    <?php echo e($inquiry->type === 'seller_application' ? 'Seller App' : 'General'); ?>

                                </span>
                            </td>
                            <td class="small"><?php echo e($inquiry->city ?: '—'); ?>, <?php echo e($inquiry->state ?: '—'); ?></td>
                            <td class="small text-muted"><?php echo e($inquiry->created_at->format('d M Y, h:i A')); ?></td>
                            <td>
                                <span class="badge <?php echo e($inquiry->status === 'new' ? 'bg-danger' : ($inquiry->status === 'in_progress' ? 'bg-warning text-dark' : 'bg-success')); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $inquiry->status))); ?>

                                </span>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.tfc.inquiries.show', $inquiry)); ?>" class="btn btn-sm btn-outline-primary" title="View Details">
                                    <i class="bi bi-eye"></i> View
                                </a>
                                <form action="<?php echo e(route('admin.tfc.inquiries.destroy', $inquiry)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this record?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">No inquiries found matching criteria.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($inquiries->hasPages()): ?>
        <div class="card-footer bg-white py-3">
            <?php echo e($inquiries->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/tfc/inquiries/index.blade.php ENDPATH**/ ?>