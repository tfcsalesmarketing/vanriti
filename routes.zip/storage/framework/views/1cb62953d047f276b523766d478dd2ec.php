<?php $__env->startSection('title', 'FAQs'); ?>

<?php $__env->startSection('content'); ?>
<?php if($faqs->count()): ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
<?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
            "@type": "Question",
            "name": <?php echo json_encode(strip_tags($faq->question), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>,
            "acceptedAnswer": {
                "@type": "Answer",
                "text": <?php echo json_encode(strip_tags($faq->answer), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>

            }
        }<?php if(! ($loop->parent->last && $loop->last)): ?>,<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
}
</script>
<?php endif; ?>
<div class="vr-section" style="background:var(--vr-cream);">
    <div class="container text-center">
        <h1 class="vr-section-title mb-2">Frequently Asked Questions</h1>
        <p class="vr-section-sub">Find quick answers to common questions</p>
    </div>
</div>

<div class="vr-section">
    <div class="container">
        <?php if($faqs->count()): ?>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 class="mb-3 mt-4" style="font-weight:700;color:var(--vr-green-dark);"><?php echo e($category); ?></h5>
                <div class="accordion mb-4" id="faq-<?php echo e(Str::slug($category)); ?>">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-<?php echo e($faq->id); ?>">
                                    <?php echo e($faq->question); ?>

                                </button>
                            </h2>
                            <div id="faq-item-<?php echo e($faq->id); ?>" class="accordion-collapse collapse" data-bs-parent="#faq-<?php echo e(Str::slug($category)); ?>">
                                <div class="accordion-body" style="line-height:1.7;color:var(--vr-text);">
                                    <?php echo nl2br(e($faq->answer)); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="vr-empty">
                <i class="bi bi-question-circle"></i>
                <h4 class="mt-3 fw-bold">No FAQs yet</h4>
                <p>Check back soon or reach out to us directly.</p>
            </div>
        <?php endif; ?>

        <div class="text-center mt-5">
            <p class="text-muted mb-3">Can't find what you're looking for?</p>
            <a href="<?php echo e(route('contact.index')); ?>" class="btn-vr">Contact Us</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\storefront\faq\index.blade.php ENDPATH**/ ?>