<?php $__env->startSection('title', 'Page Not Found'); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('icon', 'bi bi-emoji-frown'); ?>
<?php $__env->startSection('message', 'The page you\'re looking for doesn\'t exist or may have been moved.'); ?>
<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views\errors\404.blade.php ENDPATH**/ ?>