<?php $__env->startSection('title', 'Forbidden'); ?>
<?php $__env->startSection('code', '403'); ?>
<?php $__env->startSection('icon', 'bi bi-shield-x'); ?>
<?php $__env->startSection('message', "You don't have permission to access this admin page."); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="ad-btn-back"><i class="bi bi-speedometer2"></i> Back to Dashboard</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/admin/errors/403.blade.php ENDPATH**/ ?>