<?php $__env->startSection('title', 'Consumer Grievance Redressal | TFC Sales & Marketing'); ?>

<?php $__env->startSection('content'); ?>
<section class="tfc-page-header">
    <div class="container text-center">
        <span class="tfc-badge-gold mb-2 d-inline-block">Rule 7 Statutory Redressal</span>
        <h1 class="display-5 fw-bold text-white mb-2">Consumer Grievance Portal</h1>
        <p class="text-white-50 lead mb-0">Under Consumer Protection (Direct Selling) Rules, 2021 &bull; G.S.R. 889(E)</p>
    </div>
</section>

<section class="py-5">
    <div class="container" style="max-width: 900px;">
        
        <div class="card border-0 shadow-sm rounded-4 mb-5 p-4" style="background-color: var(--tfc-gold-light); border: 1px solid var(--tfc-gold-border) !important;">
            <div class="d-flex align-items-start gap-3">
                <i class="bi bi-shield-check text-warning fs-2 mt-1"></i>
                <div>
                    <h5 class="fw-bold text-dark mb-1">Our Statutory Commitment to Consumers</h5>
                    <p class="small text-muted mb-2">
                        Pursuant to <strong>Rule 7 of the Consumer Protection (Direct Selling) Rules, 2021</strong>, every consumer or direct-seller grievance lodged through this portal is guaranteed:
                    </p>
                    <ul class="small text-muted mb-0 ps-3">
                        <li><strong>48-Hour Acknowledgment:</strong> Immediate issuance of a unique Ticket Tracking ID within 48 hours.</li>
                        <li><strong>30-Day Resolution:</strong> Formal redressal, investigation, and written resolution within thirty (30) days of receipt.</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row g-5">
            
            <div class="col-12 col-lg-8">
                <div class="card p-4 p-md-5 border-0 shadow-sm rounded-4">
                    <h4 class="fw-bold text-dark mb-1">Submit a Grievance Ticket</h4>
                    <p class="text-muted small mb-4">Please provide detailed information to facilitate swift investigation.</p>

                    <form method="POST" action="<?php echo e(tfc_route('grievance.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-semibold">Consumer Name <span class="text-danger">*</span></label>
                                <input type="text" name="consumer_name" class="form-control" value="<?php echo e(old('consumer_name')); ?>" required placeholder="Your full name">
                                <?php $__errorArgs = ['consumer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-semibold">Email Address <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required placeholder="your.email@example.com">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-semibold">Phone Contact <span class="text-danger">*</span></label>
                                <input type="tel" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>" required placeholder="+91 98765 43210">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label small fw-semibold">Order / Invoice Number (Optional)</label>
                                <input type="text" name="order_number" class="form-control" value="<?php echo e(old('order_number')); ?>" placeholder="e.g. VAN-2026-000123">
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-semibold">Grievance Category <span class="text-danger">*</span></label>
                                <select name="category" class="form-select" required>
                                    <option value="product_defect" <?php echo e(old('category') === 'product_defect' ? 'selected' : ''); ?>>Product Quality or Defect</option>
                                    <option value="delivery_delay" <?php echo e(old('category') === 'delivery_delay' ? 'selected' : ''); ?>>Delivery or Shipment Delay</option>
                                    <option value="direct_seller_conduct" <?php echo e(old('category') === 'direct_seller_conduct' ? 'selected' : ''); ?>>Direct Seller Conduct or Representation</option>
                                    <option value="refund_issue" <?php echo e(old('category') === 'refund_issue' ? 'selected' : ''); ?>>Refund or Buy-Back Request</option>
                                    <option value="other" <?php echo e(old('category', 'other') === 'other' ? 'selected' : ''); ?>>Other Consumer Query</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-semibold">Complaint Particulars <span class="text-danger">*</span></label>
                                <textarea name="complaint_details" class="form-control" rows="5" required placeholder="Describe your grievance clearly, including dates, distributor names, or order details..."><?php echo e(old('complaint_details')); ?></textarea>
                                <?php $__errorArgs = ['complaint_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-tfc-primary btn-lg w-100 fw-bold">
                                    <i class="bi bi-shield-check me-2"></i>Submit Grievance &amp; Get Ticket Number
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            
            <div class="col-12 col-lg-4">
                
                <div class="card p-4 border-0 shadow-sm rounded-4 mb-4 text-center" style="background: linear-gradient(135deg, #0A1D37, #132D54); color: #FFFFFF;">
                    <i class="bi bi-search text-warning fs-1 mb-2"></i>
                    <h5 class="fw-bold text-white mb-2">Already Have a Ticket?</h5>
                    <p class="text-white-50 small mb-4">Track real-time status of your previously submitted complaint.</p>
                    <a href="<?php echo e(tfc_route('grievance.track')); ?>" class="btn btn-tfc-primary w-100">
                        Track Ticket Status
                    </a>
                </div>

                
                <div class="card p-4 border-0 shadow-sm rounded-4 bg-light">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-person-badge text-primary me-2"></i>Grievance Officer Designation</h6>
                    <?php if(tfc_setting('grievance_officer_name')): ?>
                        <div class="small text-muted mb-1"><strong>Officer:</strong> <?php echo e(tfc_setting('grievance_officer_name')); ?></div>
                        <div class="small text-muted mb-1"><strong>Email:</strong> <?php echo e(tfc_setting('grievance_officer_email')); ?></div>
                        <div class="small text-muted"><strong>Phone:</strong> <?php echo e(tfc_setting('grievance_officer_phone')); ?></div>
                    <?php else: ?>
                        <div class="alert alert-warning border-warning p-2 small mb-0">
                            <strong>Notice:</strong> Officer appointment notification is currently pending formal regulatory filing. Complaints are processed directly by the central compliance desk.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tfc.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vanriti\resources\views/tfc/grievance/index.blade.php ENDPATH**/ ?>