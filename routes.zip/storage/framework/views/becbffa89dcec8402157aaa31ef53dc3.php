<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', 'TFC Sales & Marketing | ' . tfc_setting('company_tagline', 'Connecting Products. Creating Possibilities.')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'TFC Sales & Marketing is a premier direct-selling enterprise empowering independent entrepreneurs across India with high-performance wellness, personal care, and lifestyle formulations.'); ?>">
    <link rel="canonical" href="<?php echo e(canonical_url()); ?>">

    <!-- Google Fonts: Poppins (Clean & Modern Aesthetic like Eduse Marketing) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap 5, Bootstrap Icons & Remixicon -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">

    <!-- TFC Brand Styling -->
    <link rel="stylesheet" href="<?php echo e(tfc_asset('css/tfc-style.css')); ?>?v=<?php echo e(file_exists(public_path('css/tfc-style.css')) ? filemtime(public_path('css/tfc-style.css')) : 1); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(tfc_logo_url()); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('tfc.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main>
        
        <?php if(session('success')): ?>
            <div class="container mt-4">
                <div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2 shadow-sm" role="alert">
                    <i class="bi bi-check-circle-fill fs-5"></i>
                    <div><?php echo e(session('success')); ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>

        
        <?php if(session('error')): ?>
            <div class="container mt-4">
                <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2 shadow-sm" role="alert">
                    <i class="bi bi-exclamation-triangle-fill fs-5 flex-shrink-0"></i>
                    <div class="fw-semibold"><?php echo e(session('error')); ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>

        
        <?php if(session('warning')): ?>
            <div class="container mt-4">
                <div class="alert alert-warning alert-dismissible fade show d-flex align-items-center gap-2 shadow-sm" role="alert">
                    <i class="bi bi-exclamation-circle-fill fs-5 flex-shrink-0"></i>
                    <div><?php echo e(session('warning')); ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>

        
        <?php if(session('info')): ?>
            <div class="container mt-4">
                <div class="alert alert-info alert-dismissible fade show d-flex align-items-center gap-2 shadow-sm" role="alert">
                    <i class="bi bi-info-circle-fill fs-5 flex-shrink-0"></i>
                    <div><?php echo e(session('info')); ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('tfc.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php
        $whatsappWidgetEnabled = (bool) tfc_setting('whatsapp_widget_enabled', true);
        $whatsappNumber = tfc_setting('whatsapp_phone_number') ?: tfc_setting('contact_phone', '919876543210');
        $whatsappCleanNumber = preg_replace('/[^0-9]/', '', (string) $whatsappNumber);
        $whatsappGreeting = tfc_setting('whatsapp_widget_greeting', 'Need help with our direct selling business or products? Chat with us on WhatsApp!');
        $whatsappDefaultMsg = tfc_setting('whatsapp_widget_default_msg', 'Hello TFC Sales & Marketing, I am interested in learning more about TFC products and the direct selling business opportunity.');
        $whatsappLink = 'https://wa.me/' . $whatsappCleanNumber . '?text=' . rawurlencode((string) $whatsappDefaultMsg);
    ?>

    <?php if($whatsappWidgetEnabled && ! empty($whatsappCleanNumber)): ?>
        <div class="tfc-whatsapp-widget" id="tfcWhatsappWidget">
            <div class="tfc-whatsapp-tooltip" id="tfcWhatsappTooltip">
                <div class="tfc-whatsapp-tooltip-header">
                    <span class="tfc-whatsapp-dot"></span>
                    <strong>TFC Support Team</strong>
                    <button type="button" class="btn-close btn-close-white ms-auto" style="font-size: 0.65rem;" onclick="document.getElementById('tfcWhatsappTooltip').style.display='none';" aria-label="Close"></button>
                </div>
                <div class="tfc-whatsapp-tooltip-body">
                    <?php echo e($whatsappGreeting); ?>

                </div>
            </div>
            <a href="<?php echo e($whatsappLink); ?>" target="_blank" rel="noopener noreferrer" class="tfc-whatsapp-btn" title="Chat on WhatsApp" aria-label="Chat with TFC Sales & Marketing on WhatsApp">
                <i class="bi bi-whatsapp"></i>
                <span class="tfc-whatsapp-ping"></span>
            </a>
        </div>
    <?php endif; ?>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\vanriti\resources\views/tfc/layouts/app.blade.php ENDPATH**/ ?>